package com.sist.eclass.jdbc;

import java.sql.DriverManager;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;

public class JdbcTestMain03_PROC {
//	JavaCode에서 DB연결														
//	1. JDBC 드라이버 로딩														
//	2. 데이터베이스 커넥션 구함														
//	3. 쿼리 실행 PreparedStatement														
//	4. 쿼리실행														
//	5. 쿼리 실행 결과 처리(select결과가 있으면 결과 처리,int)														
//	6. ResultSet ,PreparedStatement 자원반납														
//	7. 커넥션 자원반납	
	final static String DB_URL = "jdbc:oracle:thin:@211.238.142.124:1521:xe";
	final static String USER_ID = "hr";
	final static String USER_PASS = "hr";

	final static Logger LOG = Logger.getLogger(JdbcTestMain03_PROC.class);

	public static void main(String[] args) {

		JdbcTestMain03_PROC jtMain = new JdbcTestMain03_PROC();
		//jtMain.doInsert();
		//jtMain.doDelete();
		jtMain.upSal();

	}// --main

	public void upSal() {
		LOG.debug("upSal()");		
		Connection connection   = null;
		CallableStatement cstmt = null;
		try {
			connection = getConnection();
			LOG.debug("2.데이터베이스 커넥션 구함:" + connection);
			StringBuffer sb = new StringBuffer(50);
			//{call up_sal(?)}
			sb.append("{ call up_sal(?) } \n");
			
			cstmt = connection.prepareCall(sb.toString());
			cstmt.setInt(1, 100);
			LOG.debug("2.1. 쿼리 실행 CallableStatement	:\n" + sb.toString());
			LOG.debug("3. 쿼리 실행 CallableStatement	:" + cstmt);
			
			int flag = cstmt.executeUpdate();
			LOG.debug("4. 쿼리 실행 flag	:" + flag);
			
		} catch (SQLException e) {
			LOG.debug("SQLException:"+e.getMessage());
		} finally {
			if(null !=cstmt) {
				try {
					cstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
			if(null !=connection) {
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
			
		}
		
	}
	
	
	
	public int doDelete() {
		int flag = 0;
		LOG.debug("doDelete()");

		Connection connection = null;
		PreparedStatement pstmt = null;

		

		try {
			connection = getConnection();
			// Transaction user가 제어.
			connection.setAutoCommit(false);
			LOG.debug("2.데이터베이스 커넥션 구함:" + connection);
			StringBuffer sb = new StringBuffer(50);
			sb.append(" DELETE FROM board  \n");
			sb.append(" WHERE seq = ?      \n");
			pstmt = connection.prepareStatement(sb.toString());

			LOG.debug("2.1. 쿼리 실행 PreparedStatement	:\n" + sb.toString());
			LOG.debug("3. 쿼리 실행 PreparedStatement	:" + pstmt);

			// param set
			pstmt.setInt(1, 102);
			// 4. 쿼리실행:
			/*
			 * Executes the SQL statement in this PreparedStatement object, which must be an
			 * SQL Data Manipulation Language (DML) statement, such as INSERT, UPDATE or
			 * DELETE
			 */
			flag = pstmt.executeUpdate();
			LOG.debug("4. 쿼리실행	flag:" + flag);

			connection.commit();
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				LOG.debug("SQLException:" + e1.getMessage());
				e1.printStackTrace();
			}
			LOG.debug("SQLException:" + e.getMessage());
			e.printStackTrace();
		} finally {
			if (null != pstmt) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					LOG.debug("SQLException:" + e.getMessage());
					e.printStackTrace();
				}
			}

			if (null != connection) {
				try {
					connection.close();
				} catch (SQLException e) {
					LOG.debug("SQLException:" + e.getMessage());
					e.printStackTrace();
				}
			}
		}

		return flag;
	}

	public int doInsert() {
		int flag = 0;
		// -------------------------
		Connection connection = null;
		PreparedStatement pstmt = null;
		

		try {
			connection = getConnection();
			LOG.debug("2.데이터베이스 커넥션 구함:" + connection);
//			3. 쿼리 실행 PreparedStatement	
			StringBuffer sb = new StringBuffer(1000);

			sb.append(" INSERT INTO BOARD ( \n");
			sb.append(" 	seq,            \n");
			sb.append(" 	title,          \n");
			sb.append(" 	contents,       \n");
			sb.append(" 	div,            \n");
			sb.append(" 	reg_id,         \n");
			sb.append(" 	mod_id          \n");
			sb.append(" )VALUES (           \n");
			sb.append(" 	?,              \n");
			sb.append(" 	?,              \n");
			sb.append(" 	?,              \n");
			sb.append(" 	?,              \n");
			sb.append(" 	?,              \n");
			sb.append(" 	?               \n");
			sb.append(" )                   \n");
			// Statement
			// PreparedStatement : binding sql Statement보다 sql수행 속도가 우수.
			pstmt = connection.prepareStatement(sb.toString());
			// --doInsert():div 10(공지사항), 20(자유게시판)
			// --102 ,title_102 ,contents_102 ,'eclass_102','eclass_102'
			// param set
			pstmt.setInt(1, 102);// NUMBER
			pstmt.setString(2, "title_102"); // VARCHAR2
			pstmt.setString(3, "contents_102"); // VARCHAR2
			pstmt.setString(4, "10"); // VARCHAR2
			pstmt.setString(5, "eclass_102"); // VARCHAR2
			pstmt.setString(6, "eclass_102"); // VARCHAR2
			LOG.debug("2.1. 쿼리 실행 PreparedStatement	:\n" + sb.toString());
			LOG.debug("3. 쿼리 실행 PreparedStatement	:" + connection);

			// 4. 쿼리실행:
			/*
			 * Executes the SQL statement in this PreparedStatement object, which must be an
			 * SQL Data Manipulation Language (DML) statement, such as INSERT, UPDATE or
			 * DELETE
			 */
			flag = pstmt.executeUpdate();
			LOG.debug("4. 쿼리실행	flag:" + flag);

		} catch (SQLException e) {
			LOG.debug("SQLException:" + e.getMessage());
			e.printStackTrace();
		} finally {
			// 6.PreparedStatement 자원반납
			if (null != pstmt) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			// 7.Connection 반납
			if (null != connection) {
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

		}
		// -------------------------

		return flag;
	}

	/**
	 * Driver로딩,
	 * 
	 * @return Connection
	 * @throws SQLException 
	 */
	public Connection getConnection() throws SQLException {
		Connection con = null;

		try {
			//클래스 로더를 통해 해당 데이터베이스 드라이버를 로드
			//JVM에게 해당 클래스의 정보를 로드한다
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			LOG.debug("ClassNotFoundException:" + e.getMessage());
			e.printStackTrace();
		}
		
		LOG.debug("1.JDBC 드라이버 로딩 성공");
		con = DriverManager.getConnection(DB_URL, USER_ID, USER_PASS);
		LOG.debug("2.데이터베이스 커넥션 구함:" + con);
		return con;
	}

}// --class
