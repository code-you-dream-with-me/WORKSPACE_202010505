/**
* <pre>
* com.sist.eclass.member.test
* Class Name : MemberDaoJdbcTestmain.java
* Description:
* Author: sist
* Since: 2021/03/11
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2021/03/11 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.member.test;

import java.util.List;

import org.apache.log4j.Logger;

import com.sist.eclass.board.test.BoardJdbcTestMain;
import com.sist.eclass.cmn.DTO;
import com.sist.eclass.cmn.search.domain.SearchVO;
import com.sist.eclass.member.dao.MemberDao;
import com.sist.eclass.member.domain.MemberVO;
import com.sist.eclass.member.domain.SexsualVO;

/**
 * @author sist
 *
 */
public class MemberDaoJdbcTestmain {
	final static Logger LOG = Logger.getLogger(MemberDaoJdbcTestmain.class);
	
	private MemberVO member01;
	private MemberVO member02;
	private MemberVO member03;
	
	private SearchVO  searchVO;
	
	private MemberDao  memberDao;
	
	public MemberDaoJdbcTestmain() {
		//	1234_U
		member01 = new MemberVO("J_124", "이상무", "1234_U", "jamesol@paran.com", "M", "01012345678", "9"
				, "Admin", "", "Admin", "");
		member02 = new MemberVO("J_124_01", "이상무_01", "1234", "jamesol_01@paran.com", "M", "01012345678", "9"
				, "Admin", "", "Admin", "");	
		member03 = new MemberVO("J_124_02", "이상무_02", "1234", "jamesol_02@paran.com", "M", "01012345678", "9"
				, "Admin", "", "Admin", "");
		
		searchVO = new SearchVO();
		
		memberDao = new MemberDao();
	}
	public void sexsualRatio(){
		LOG.debug("=====================");
		LOG.debug("==sexsualRatio()=");
		LOG.debug("=====================");	
		
		List<SexsualVO> list=this.memberDao.sexsualRatio();
		
	}
	
	
	
	
	public void idCheck() {
		LOG.debug("=====================");
		LOG.debug("==idCheck()=");
		LOG.debug("=====================");
		//member01.setMemberId("없음");
		int flag = memberDao.idCheck(member01);
		if(1==flag) {
			LOG.debug("=사용자 ID가 있습니다.");
		}else {
			LOG.debug("=사용자 ID가 없습니다.");
		}
	}
	
	public void passwordCheck() {
		LOG.debug("=====================");
		LOG.debug("==passwordCheck()=");
		LOG.debug("=====================");
		member01.setPasswd("비번없음");
		int flag = memberDao.passwordCheck(member01);
		if(1==flag) {
			LOG.debug("=사용자 ID PASSWORD가 있습니다.");
		}else {
			LOG.debug("=사용자 ID가 PASSWORD없습니다.");
		}	
	}
	
	public void doSelectOne() {
		LOG.debug("=====================");
		LOG.debug("==doSelectOne()=");
		LOG.debug("=====================");	
		//cellPhone=AMDIN_U
		//name=1234_U
		MemberVO outVO = (MemberVO) memberDao.doSelectOne(member01);
		LOG.debug("==outVO="+outVO);
	}
	
	public void doDelete() {
		LOG.debug("=====================");
		LOG.debug("==doDelete()=");
		LOG.debug("=====================");	
		int flag = memberDao.doDelete(member01);
		if(1==flag) {
			LOG.debug("==삭제성공=");
		}
	}
	
	public void doInsert() {
		LOG.debug("=====================");
		LOG.debug("==doInsert()=");
		LOG.debug("=====================");		
		
		int flag = memberDao.doInsert(member01);
		if(1==flag) {
			//MemberVO [memberId=J_124, name=이상무, passwd=1234_U, email=jamesol@paran.com, sex=M, cellPhone=01012345678, auth=9, regId=Admin, regDt=, modId=Admin, modDt=, toString()=DTO [num=0, totalCnt=0, msgFlag=0, msg=null]]
			//MemberVO [memberId=J_124, name=이상무, passwd=1234_U, email=jamesol@paran.com, sex=M, cellPhone=01012345678, auth=9, regId=Admin, regDt=2021/03/12 11:26:23, modId=Admin, modDt=2021/03/12 11:26:23, toString()=DTO [num=0, totalCnt=0, msgFlag=0, msg=null]]
			
			MemberVO getMember = (MemberVO) memberDao.doSelectOne(member01);
			if(getMember.equals(member01)) {
				LOG.debug("==등록성공=");
				LOG.debug("==입력데이터와 등록데이터 동일!=");
			}
			
		}
	}
	
	public void doUpdate() {
		member01 = new MemberVO("J_124", "이상무_99", "1234_U_99", "jamesol_99@paran.com", "F", "01012345699", "1"
				, "Admin", "", "Admin_99", "");
		
		int flag = memberDao.doUpdate(member01);
		if(1==flag) {
			LOG.debug("==수정성공=");
			MemberVO getMember = (MemberVO) memberDao.doSelectOne(member01);
			if(getMember.equals(member01)) {
				LOG.debug("==수정데이터와 등록데이터 동일!=");
			}
			
		}
	}  
	
	public void doTotalCnt() {
		searchVO.setSearchDiv("40");
		searchVO.setSearchWord("010");
		
		MemberVO outVO = (MemberVO) memberDao.doTotalCnt(searchVO);
		
		LOG.debug("=outVO="+outVO.getTotalCnt());
		
	}
	
	public void doRetrieve() {
		LOG.debug("=====================");
		LOG.debug("==doRetrieve()=");
		LOG.debug("=====================");
		searchVO.setSearchDiv("40");
		searchVO.setSearchWord("010");
		
		searchVO.setPageSize(10);
		searchVO.setPageNum(1);         
		
		
		List<MemberVO> list = (List<MemberVO>) memberDao.doRetrieve(searchVO);
		
		LOG.debug("==list="+list);
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		MemberDaoJdbcTestmain main=new MemberDaoJdbcTestmain();
		//main.idCheck();
		//main.passwordCheck();
		//main.doSelectOne();
		//main.doDelete();
		//main.doInsert();
		//main.doUpdate();
		//main.doTotalCnt();
		//main.doRetrieve();
		main.sexsualRatio();
		
	}
	
	
	
	
	
	
	
	
	
	

}
