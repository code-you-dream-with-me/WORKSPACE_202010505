/**
* <pre>
* com.sist.eclass.member.domain
* Class Name : SexsualVO.java
* Description:
* Author: sist
* Since: 2021/03/18
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2021/03/18 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.member.domain;

import com.sist.eclass.cmn.DTO;

/**
 * @author sist
 *
 */
public class SexsualVO extends DTO {
	private String sex;
	private int cnt;
	
	public SexsualVO() {}

	public SexsualVO(String sex, int cnt) {
		super();
		this.sex = sex;
		this.cnt = cnt;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public int getCnt() {
		return cnt;
	}

	public void setCnt(int cnt) {
		this.cnt = cnt;
	}

	@Override
	public String toString() {
		return "SexsualVO [sex=" + sex + ", cnt=" + cnt + ", toString()=" + super.toString() + "]";
	}
	
	
}
