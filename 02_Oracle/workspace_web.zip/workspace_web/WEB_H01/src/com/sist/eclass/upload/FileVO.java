/**
* <pre>
* com.sist.eclass.upload
* Class Name : FileVO.java
* Description:
* Author: sist
* Since: 2021/03/15
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2021/03/15 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.upload;

import com.sist.eclass.cmn.DTO;

/**
 * @author sist
 *
 */
public class FileVO extends DTO {
	private String fileId ;	//파일ID
	private int seq;	//순번
	private String orgFileNm;	//원본파일명
	private String saveFileNm;	//저장파일명
	private String path;	//저장경로
	private long size;	//파일사이즈
	private String ext;	//확장자
	
	private String regId   ; //등록자
	private String regDt   ; //등록일
	private String modId   ; //수정자
	private String modDt   ; //수정일
	
	public FileVO() {
		
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public int getSeq() {
		return seq;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public String getOrgFileNm() {
		return orgFileNm;
	}

	public void setOrgFileNm(String orgFileNm) {
		this.orgFileNm = orgFileNm;
	}

	public String getSaveFileNm() {
		return saveFileNm;
	}

	public void setSaveFileNm(String saveFileNm) {
		this.saveFileNm = saveFileNm;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public long getSize() {
		return size;
	}

	public void setSize(long size) {
		this.size = size;
	}

	public String getExt() {
		return ext;
	}

	public void setExt(String ext) {
		this.ext = ext;
	}

	public String getRegId() {
		return regId;
	}

	public void setRegId(String regId) {
		this.regId = regId;
	}

	public String getRegDt() {
		return regDt;
	}

	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}

	public String getModId() {
		return modId;
	}

	public void setModId(String modId) {
		this.modId = modId;
	}

	public String getModDt() {
		return modDt;
	}

	public void setModDt(String modDt) {
		this.modDt = modDt;
	}

	@Override
	public String toString() {
		return "FileVO [fileId=" + fileId + ", seq=" + seq + ", orgFileNm=" + orgFileNm + ", saveFileNm=" + saveFileNm
				+ ", path=" + path + ", size=" + size + ", ext=" + ext + ", regId=" + regId + ", regDt=" + regDt
				+ ", modId=" + modId + ", modDt=" + modDt + ", toString()=" + super.toString() + "]";
	}
	
	
}
