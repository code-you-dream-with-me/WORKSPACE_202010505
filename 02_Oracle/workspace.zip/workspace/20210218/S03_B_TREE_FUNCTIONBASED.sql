--Function Based INDEX(FBI -함수 기반 인덱스)																
--																
--	함수처럼 연산을 해서 인덱스 생성.															
--	where pay+1000															
--																
--	*임시 방편이고 근본적인 해결책은 될수 없음.															
--																
--* 인덱스는 어느 컬럼에 생성해야 할까?																
--	조인컬럼, where조건 절에 오는 컬럼에 생성.															
--문법																
--	CREATE  INDEX 인덱명															
--	ON	테이블명 (  컬럼명+1000)														
--																
--*where pay+1000 = 2000 인덱스를 타지 않는다.																
--	where조건절을 절대로 다른 형태로 가공해서는 않된다.															
--																
--where ename !='FORD'																
--INDEX가 설정되어 있는 컬럼에 NOT을 사용하는 경우도 인덱스를 타지 않는다.	

--professor pay+100															
CREATE  INDEX idx_professor_pay
ON professor (pay + 1000);
