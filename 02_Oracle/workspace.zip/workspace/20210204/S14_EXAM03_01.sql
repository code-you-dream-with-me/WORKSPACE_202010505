--emp 테이블을 사용하여 사원 중에서 급여(sal)와 보너스(comm)를 합친 금액이 가장 많은 경우와 
--가장 적은 경우 , 평균 금액을 구하세요. 
--단 보너스가 없을 경우는 보너스를 0 으로 계산하고 출력 금액은 모두 
--소수점 첫째 자리까지만 나오게 하세요.

--SELEC * FROM (SELECT NVL(sal,0) + NVL(comm,0) FROM emp ) 

--SELECT MAX( NVL(sal,0) + NVL(comm,0) )
--      ,MIN( NVL(sal,0) + NVL(comm,0) )
--      ,ROUND(AVG( NVL(sal,0) + NVL(comm,0) ),2)
--FROM emp
--;
SELECT MAX(tot_sal) "MAX_SAL"
      ,MIN(tot_sal) "MIN_SAL"
	  ,ROUND(AVG(tot_sal),2) "AVG_SAL"
FROM (SELECT NVL(sal,0)+NVL(comm,0) AS tot_sal
      FROM emp
     );
	 
--   MAX_SAL    MIN_SAL    AVG_SAL
------------ ---------- ----------
--      5000        800    2260.42