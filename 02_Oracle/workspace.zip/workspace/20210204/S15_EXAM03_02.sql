-- student 테이블의 birthday 컬럼을 참조해서 아래와 같이 월별로 생일자수를 출력하세요.

col TOTAL for A5
col "JAN" for A5
col "FEB" for A5
col "MAR" for A5
col "APR" for A5
col "MAY" for A5
col "JUN" for A5
col "JUL" for A5
col "AUG" for A5
col "SEP" for A5
col "OCT" for A5
col "NOV" for A5
col "DEC" for A5
SELECT COUNT(E_MONTH)||'EA' "TOTAL"
      ,COUNT(DECODE(E_MONTH,'01',1,NULL)) ||'EA' "JAN"
      ,COUNT(DECODE(E_MONTH,'02',1,NULL)) ||'EA' "FEB"
      ,COUNT(DECODE(E_MONTH,'03',1,NULL)) ||'EA' "MAR"
      ,COUNT(DECODE(E_MONTH,'04',1,NULL)) ||'EA' "APR"
      ,COUNT(DECODE(E_MONTH,'05',1,NULL)) ||'EA' "MAY"
      ,COUNT(DECODE(E_MONTH,'06',1,NULL)) ||'EA' "JUN"
      ,COUNT(DECODE(E_MONTH,'07',1,NULL)) ||'EA' "JUL"
      ,COUNT(DECODE(E_MONTH,'08',1,NULL)) ||'EA' "AUG"
      ,COUNT(DECODE(E_MONTH,'09',1,NULL)) ||'EA' "SEP"
      ,COUNT(DECODE(E_MONTH,'10',1,NULL)) ||'EA' "OCT"
      ,COUNT(DECODE(E_MONTH,'11',1,NULL)) ||'EA' "NOV"
      ,COUNT(DECODE(E_MONTH,'12',1,NULL)) ||'EA' "DEC"  	  
FROM (
		SELECT TO_CHAR(birthday,'MM') "E_MONTH"
		FROM student
)
;
--TOTAL JAN   FEB   MAR   APR   MAY   JUN   JUL   AUG   SEP   OCT   NOV   DEC
------- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- -----
--20EA  3EA   3EA   2EA   2EA   0EA   1EA   0EA   2EA   2EA   2EA   1EA   2EA
