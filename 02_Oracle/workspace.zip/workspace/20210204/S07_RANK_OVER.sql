--SELECT empno
--      ,ename
--	  ,sal
--	  ,RANK() OVER(ORDER BY sal ASC) "RANK_ASC"
--FROM emp
--WHERE deptno = 10
--;
--     EMPNO ENAME                       SAL   RANK_ASC
------------ -------------------- ---------- ----------
--      7934 MILLER                     1300          1
--      7782 CLARK                      2450          2
--      7839 KING                       5000          3

SELECT empno
      ,ename
	  ,sal
	  ,deptno
	  ,RANK() OVER(PARTITION BY deptno ORDER BY sal ASC) "RANK_ASC"
FROM emp
;
--     EMPNO ENAME                       SAL     DEPTNO   RANK_ASC
------------ -------------------- ---------- ---------- ----------
--      7934 MILLER                     1300         10          1
--      7782 CLARK                      2450         10          2
--      7839 KING                       5000         10          3
--      7369 SMITH                       800         20          1
--      7566 JONES                      2975         20          2
--      7902 FORD                       3000         20          3
--      7900 JAMES                       950         30          1
--      7521 WARD                       1250         30          2
--      7654 MARTIN                     1250         30          2
--      7844 TURNER                     1500         30          4
--      7499 ALLEN                      1600         30          5
--      7698 BLAKE                      2850         30          6
--
--12 행이 선택되었습니다.