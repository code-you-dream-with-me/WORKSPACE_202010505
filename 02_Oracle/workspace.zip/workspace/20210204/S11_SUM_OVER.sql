SELECT p_date
      ,p_code
	  ,p_qty
	  ,p_total
	  ,SUM(p_total) OVER(PARTITION BY p_code ORDER BY p_total) "SUM_OBER"
FROM panmae
WHERE P_STORE = 1000;

--P_DATE               P_CODE      P_QTY    P_TOTAL   SUM_OBER
------------------ ---------- ---------- ---------- ----------
--20110103                100          2       1600       1600
--20110101                100          3       2400       4000
--20110102                102          2       2000       2000
--20110102                105          2       3000       3000