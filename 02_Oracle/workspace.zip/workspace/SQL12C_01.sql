--ORACLE 12C이후 부터 가능한 기능
--1.DEFAULT VALUE로 sequence의 next value지정 가능
--게시글 번호 자동증가:sequence


--1.1. sequence생성
--1.2. sequence를 이용한 table pk생성

--CREATE SEQUENCE t_seq
--START WITH 1
--INCREMENT BY 1
--MAXVALUE 20
--NOCYCLE;

--CREATE TABLE t_seq_test(
--	no NUMBER DEFAULT t_seq.NEXTVAL PRIMARY KEY,
--	name VARCHAR2(20)
--);

--DECLARE
--
--BEGIN
--		FOR i   IN 1..10 LOOP
--			INSERT INTO t_seq_test (name) VALUES (DBMS_RANDOM.STRING('A',10));
--		END LOOP;
--		COMMIT;
--END;
--/

SELECT *
FROM t_seq_test;







