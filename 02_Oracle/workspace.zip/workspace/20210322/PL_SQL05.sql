--DML 사용자에게 데이터 입력 받아 처리

--pl_test2

--CREATE TABLE pl_test2(
--	no NUMBER,
--	name VARCHAR2(10),
--	addr VARCHAR2(10)
--);

DECLARE
	v_no NUMBER := '&no';
	v_name VARCHAR2(10) := '&name';
	v_addr VARCHAR2(10) := '&addr';
BEGIN
	INSERT INTO pl_test2 VALUES (v_no,v_name,v_addr);
END;
/
--09:46:21 HR>@PL_SQL05.sql
--no의 값을 입력하십시오: 1
--구   2:         v_no NUMBER := '&no';
--신   2:         v_no NUMBER := '1';
--name의 값을 입력하십시오: JAMES
--구   3:         v_name VARCHAR2(10) := '&name';
--신   3:         v_name VARCHAR2(10) := 'JAMES';
--addr의 값을 입력하십시오: HONGDAE
--구   4:         v_addr VARCHAR2(10) := '&addr';
--신   4:         v_addr VARCHAR2(10) := 'HONGDAE';
--
--PL/SQL 처리가 정상적으로 완료되었습니다.
--
--경   과: 00:00:00.00
--09:49:05 HR>SELECT * FROM pl_test2;
--
--        NO NAME                 ADDR
------------ -------------------- --------------------
--         1 JAMES                HONGDAE
