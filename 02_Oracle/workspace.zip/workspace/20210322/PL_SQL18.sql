--pl/sql 제어문
--조건문,반목문
--1. 조건문 : IF, CASE
--2. 반복문 : FOR,WHILE,BASIC LOOP

--1.1. IF (조건) THEN
--       실행문장
--     ELSIF(조건) THEN
--       실행문장
--     ELSIF(조건) THEN
--       실행문장
--     ELSIF(조건) THEN
--       실행문장
--     END IF 

--유형 1번의 예: 
--      employees 테이블에서 employee_id 가 203 번인 사원의 employee_id , first_name , 
--      department_id , dname 을 출력하세요. 단 DNAME 의 값은 아래와 같습니다.
--      department_id 가 10 이면 ’Administration’ ,
--      department_id 가 20 이면 ‘Marketing’ ,
--      department_id 가 30 이면 ‘Purchasing’ ,
--      department_id 가 40 이면 'Human Resources’ 로 출력하세요.

DECLARE
	v_empid employees.employee_id%TYPE;
	v_fname employees.first_name%TYPE;
	v_deptid employees.department_id%TYPE;
	v_dname  VARCHAR2(30 BYTE);
BEGIN
	SELECT employee_id,first_name,department_id
	INTO   v_empid,v_fname,v_deptid
	FROM employees
	WHERE employee_id = 203;
	
	IF (v_deptid = 10) THEN
		v_dname := 'Administration';
	ELSIF(v_deptid = 20) THEN
	    v_dname := 'Marketing';
	ELSIF(v_deptid = 30) THEN
		v_dname := 'Purchasing';
	ELSIF(v_deptid = 40) THEN
		v_dname := 'Human Resources';
	END IF;	
	
	DBMS_OUTPUT.PUT_LINE(v_empid ||','|| v_fname||','|| v_deptid||','|| v_dname);
	
END;
/
--203,수잔,40,Human Resources
