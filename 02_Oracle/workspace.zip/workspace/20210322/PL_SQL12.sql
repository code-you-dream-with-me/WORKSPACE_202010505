--JOIN에 참조타입 
DECLARE
    v_empid employees.employee_id%TYPE;
	v_name  employees.first_name%TYPE;
	v_deptno employees.department_id%TYPE;
	v_deptnm departments.department_name%TYPE;
BEGIN
	SELECT t1.employee_id, t1.first_name,  t1.department_id,  t2.department_name
	  INTO v_empid,v_name,v_deptno,v_deptnm
	FROM employees t1, departments t2
	WHERE  t1.department_id = t2.department_id
	AND    t1.employee_id = 180;
	
	DBMS_OUTPUT.PUT_LINE(v_empid ||','|| v_name ||','|| v_deptno ||','|| v_deptnm);
END;
/
--11:33:43 HR>@PL_SQL12.sql
--180,윈스턴,50,물류(Shipping)