--PL/SQL에서 SELECT로 데이터 조회하기
--문법] : 반듯이 한건의 데이터만 출력되어야 한다.
--SELECT selectlist
--INTO   {VARIABLE NAME,VARIABLE NAME,,,,}
--FROM table명
--[WHERE 조건절]

--employees 테이블에서 employee id 197번인 사원의 이름과 사번을 출력.
--
--employees 테이블에서 employee id 197번인 사원의 이름과 사번을 출력.
--employees.employee_id%TYPE,
--employees.salary%TYPE,

--화면에 출력기능 켜기.
--SET SERVEROUTPUT ON;
DECLARE
	v_empid  employees.employee_id%TYPE ;
	v_salary  employees.salary%TYPE;
BEGIN
	SELECT employee_id,salary
	       INTO v_empid,v_salary
	FROM employees
	WHERE employee_id =197;
    DBMS_OUTPUT.PUT_LINE(v_empid||','||v_salary);
END;
/