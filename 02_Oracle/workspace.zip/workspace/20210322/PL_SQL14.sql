--복합 변수: 레코드 TYPE, TABLE TYPE

--동일한 데이터 타입의 여러 건의 데이터를 저장하는 경우 TABLE TYPE(COLLECTION TYPE),이 것 이외는 레코드 TYPE
--레코드 TYPE
--TYPE TYPE_NAME IS RECORD
--(filed declaration, filed declaration,,,)

--선언부:type선언
--TYPE emp_record_type IS RECORD
--( emp_id employees.employee_id%TYPE,
--  emp_name employees.first_name%TYPE,
--  emp_sal employees.salary%TYPE
--);
--
----변수 선언
--v_record emp_record_type;

DECLARE
    --RECORD TYPE변수 선언
	TYPE emp_record_type IS RECORD
	( 
		emp_id   employees.employee_id%TYPE,
		emp_name employees.first_name%TYPE,
		emp_sal employees.salary%TYPE
	);
	--emp_record_type를 v_record01변수 선언
	
	v_record01 emp_record_type;
	
BEGIN
	SELECT employee_id,first_name,salary
	INTO   v_record01
	FROM  employees
	WHERE employee_id =180;
	
	DBMS_OUTPUT.PUT_LINE(v_record01.emp_id || ',' || v_record01.emp_name || ',' || v_record01.emp_sal);
	
	

END;
/
--180,윈스턴,3200
















