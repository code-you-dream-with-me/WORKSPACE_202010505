--MERGE 작업 수행
--pl_merge1,pl_merge2
--CREATE TABLE pl_merge1(
--	no NUMBER,
--	name VARCHAR2(10)
--);

--CTAS pl_merge2생성
--CREATE TABLE pl_merge2
--AS
--SELECT * FROM pl_merge1;


--INSERT INTO pl_merge1 VALUES (1,'AAA');
--INSERT INTO pl_merge1 VALUES (2,'BBB');
--INSERT INTO pl_merge2 VALUES (1,'CCC');
--INSERT INTO pl_merge2 VALUES (3,'DDD');

--SELECT *
--FROM pl_merge1;
--        NO NAME
------------ --------------------
--         1 AAA
--         2 BBB
--SELECT *
--FROM pl_merge2;
--        NO NAME
------------ --------------------
--         1 CCC
--         3 DDD

--commit;


--DECLARE
--	
--BEGIN
--	MERGE INTO pl_merge2 m2
--	USING pl_merge1 m1
--	ON (m1.no = m2.no)
--	WHEN MATCHED THEN
--		UPDATE SET m2.name = m1.name
--	WHEN NOT MATCHED THEN
--	    INSERT VALUES (m1.no,m1.name)
--	;
--END;
--/


--SELECT * FROM pl_merge2;
--        NO NAME
------------ --------------------
--         1 AAA
--         3 DDD
--         2 BBB

SELECT * FROM pl_merge1;






















