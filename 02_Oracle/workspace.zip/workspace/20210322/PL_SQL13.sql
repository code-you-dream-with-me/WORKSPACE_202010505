--숫자 2개 입력 받아 더하기 처리
DECLARE
	v_no1 NUMBER := &NO1;
	v_no2 NUMBER := &NO2;
	v_sum NUMBER;
BEGIN
	v_sum := v_no1 + v_no2;

	DBMS_OUTPUT.PUT_LINE(v_sum ||':='|| v_no1 ||'+'|| v_no2);

END;
/
--22:=10+12