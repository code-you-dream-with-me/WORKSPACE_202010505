--INSERT�� ���� �ٰ� �Է�
--CREATE TABLE professor3
--AS
--SELECT * FROM professor
--WHERE 1=2
--;
--
--SELECT COUNT(*) FROM professor3;


--ITAS
INSERT INTO professor3
SELECT * FROM professor;

COMMIT;

SELECT COUNT(*) FROM professor3;