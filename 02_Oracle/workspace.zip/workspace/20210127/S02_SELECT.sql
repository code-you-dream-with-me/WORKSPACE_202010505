--table구조

--테이블 구조 보기
--DESC dept;

--scott소유에 모든 테이블
--SELECT * FROM tab;

--특정 컬럼만 조회
--DESC emp;
SELECT empno
      ,ename
	  ,job
	  ,sal
FROM emp
;
