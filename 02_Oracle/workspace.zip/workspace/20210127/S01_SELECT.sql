--COMMENT
--SELECT 명령을 이용하여 데이터를 조회한다.
--SELECT [컬럼명 또는 표현식] FROM [테이블,뷰명]

--SELECT,FROM : keyword(대문자)
--[컬럼명 ,테이블,뷰명]: 소문자

SELECT empno
FROM emp
;

