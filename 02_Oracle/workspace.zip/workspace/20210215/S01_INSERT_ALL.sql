--TABLE prof_3, prof_4

--CREATE TABLE prof_3(
--	profno  NUMBER,
--	name    VARCHAR2(25)
--);

--CREATE TABLE prof_4(
--	profno  NUMBER,
--	name    VARCHAR2(25)
--);
--INSERT ALL: 여러 테이블에 여러 행 입력		

--여러 테이블에 서로 다른 데이터 입력						
--INSERT ALL
--WHEN profno BETWEEN 1000 AND 1999 THEN
--	INTO prof_3 VALUES (profno,name)
--WHEN profno BETWEEN 2000 AND 2999 THEN
--	INTO prof_4 VALUES (profno,name)
--SELECT profno
--      ,name
--FROM professor;

--SELECT *
--FROM prof_3;
--
--SELECT *
--FROM prof_4;

--여러 테이블에 같은 데이터 입력	

--TRUNCATE  TABLE prof_3;
--TRUNCATE  TABLE prof_4;

--INSERT ALL
--	INTO prof_3 VALUES (profno,name)
--	INTO prof_4 VALUES (profno,name)
--SELECT profno
--      ,name
--FROM professor
--WHERE profno BETWEEN 3000  AND 3999;

--SELECT *
--FROM prof_3;
--
--SELECT *
--FROM prof_4;















