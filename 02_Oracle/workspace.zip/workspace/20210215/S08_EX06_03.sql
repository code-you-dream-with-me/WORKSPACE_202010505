--3. professor 테이블에서 profno 가 3000 번 이하의 교수들의 profno , name , pay 를 가져와서  
--   professor4 테이블에 한꺼번에 입력하는 쿼리를 쓰세요. ( ITAS 방법을 사용하세요 )

--TABLE삭제
DROP TABLE professor4;

--TABLE생성(데이터 미포함)
CREATE TABLE professor4
AS
SELECT profno , name , pay
FROM professor
WHERE 1=2;

--데이터 입력
INSERT INTO professor4
SELECT profno , name , pay
FROM professor
WHERE profno<= 3000;

SELECT *
FROM professor4;
--    PROFNO NAME                                            PAY
------------ ---------------------------------------- ----------
--      1001 Audie Murphy                                    550
--      1002 Angela Bassett                                  380
--      1003 Jessica Lange                                   270
--      2001 Winona Ryder                                    250
--      2002 Michelle Pfeiffer                               350
--      2003 Whoopi Goldberg                                 490
--
--6 행이 선택되었습니다.