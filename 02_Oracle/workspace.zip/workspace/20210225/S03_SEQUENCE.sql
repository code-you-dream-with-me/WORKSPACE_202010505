--SEQUENCE는 연속적인 번호를 자동으로 생성하는 번호 생성기.													
--단점: DML이 rollback되어도 sequence는 rollback되지 않는다.													
--													
--생성방법													
--CREATE SEUENCE sequence_name													
--increment by n : 시퀀스 번호의 증가 값 default 1													
--start with n : 시퀀스 번호의 시작값 default 1													
--maxvalue n: 시퀀스 최대값													
--minvalue n: 시퀀스 최소값													
--CYCLE|NOCYCLE: 시퀀스 번호의 순환 여부													
--CACHE|NOCACHE: 시퀀스 생성 속도 개선													
--													
--게시판에 KEY로 사용.					

--sequence_name : jno_seq
--시작번호: 100
--끝번호:110
--최소:90
--증가값:1
--반복되고 캐싱은 2

--CREATE SEQUENCE jno_seq
--INCREMENT BY 1
--START WITH 100
--MAXVALUE 110
--MINVALUE 90
--CYCLE
--CACHE 2;


--CURRVAL함수 NEXTVAR							
--	CURRVAL: 현재 시퀀스 값						
--	NEXTVAR: 다음 시퀀스 값						


--1 SEQUENCE 사용
--CREATE TABLE s_order(
--	ord_no NUMBER(4),
--	ord_name VARCHAR2(10),
--	p_name VARCHAR(20),
--	p_qty NUMBER
--);

--SEQUENCE를 s_order테이블에 ord_no컬럼에 입력


--INSERT INTO s_order (
--    ord_no,
--    ord_name,
--    p_name,
--    p_qty
--) VALUES (
--    JNO_SEQ.nextval,
--    'james',
--    'MAC',
--    2
--);

--COMMIT;

--SELECT *
--FROM s_order;
--    ORD_NO ORD_NAME             P_NAME                                        P_QTY
------------ -------------------- ---------------------------------------- ----------
--       100 james                MAC                                               2
--       101 james                MAC                                               2
--
--SELECT  JNO_SEQ.CURRVAL
--FROM dual;
--11:33:11 SCOTT>@S03_SEQUENCE.sql
--
--   CURRVAL
------------
--       101


--MAX/MIN VALUE TEST

--BEGIN
--	FOR i IN 1..9 LOOP
--		INSERT INTO s_order (
--			ord_no,
--			ord_name,
--			p_name,
--			p_qty
--		) VALUES (
--			JNO_SEQ.nextval,
--			'james',
--			'MAC',
--			1
--		);		
--	END LOOP;
--	COMMIT;
--	
--END;
--/
--PL/SQL 처리가 정상적으로 완료되었습니다.




--SELECT *
--FROM s_order;



--INSERT INTO s_order (
--	ord_no,
--	ord_name,
--	p_name,
--	p_qty
--) VALUES (
--	JNO_SEQ.nextval,
--	'james',
--	'MAC',
--	1
--);		
--
--COMMIT;


--SELECT *
--FROM s_order;

--    ORD_NO ORD_NAME             P_NAME                                        P_QTY
------------ -------------------- ---------------------------------------- ----------
--       100 james                MAC                                               2
--       101 james                MAC                                               2
--       102 james                MAC                                               1
--       103 james                MAC                                               1
--       104 james                MAC                                               1
--       105 james                MAC                                               1
--       106 james                MAC                                               1
--       107 james                MAC                                               1
--       108 james                MAC                                               1
--       109 james                MAC                                               1
--       110 james                MAC                                               1
--        90 james                MAC                                               1
--
--12 행이 선택되었습니다.
--
--경   과: 00:00:00.03













								
