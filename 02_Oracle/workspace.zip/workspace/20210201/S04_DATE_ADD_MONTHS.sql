--ADD_MONTHS:주어진 날짜에 개월수 더하기(빼기)
SELECT SYSDATE
      ,ADD_MONTHS(SYSDATE, 1) "ADD_MONTHS"
	  ,ADD_MONTHS(SYSDATE,-2) "ADD_MONTHS_01"
FROM dual
;
--SYSDATE             ADD_MONTHS          ADD_MONTHS_01
--------------------- ------------------- -------------------
--2021-02-01:09:34:11 2021-03-01:09:34:11 2020-12-01:09:34:11

