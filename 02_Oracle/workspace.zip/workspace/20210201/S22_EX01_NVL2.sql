SELECT ename
      ,empno
	  ,comm
	  ,NVL2(comm,'Exist','NULL') "NVL2"
FROM emp
WHERE deptno =30
;
--ENAME                     EMPNO       COMM NVL2
---------------------- ---------- ---------- ----------
--ALLEN                      7499        300 Exist
--WARD                       7521        500 Exist
--MARTIN                     7654       1400 Exist
--BLAKE                      7698            NULL
--TURNER                     7844          0 Exist
--JAMES                      7900            NULL
--
--6 행이 선택되었습니다.