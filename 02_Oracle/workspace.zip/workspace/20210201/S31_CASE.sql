--CASE VS DECODE 
--DECODE는 == 조건인 경우 사용
--CASE는 == 조건이 아닌경우 사용
--
--CASE 조건  WHEN 결과1 THEN 출력1
--         WHEN 결과2 THEN 출력2
--         WHEN 결과3 THEN 출력3
--		 ELSE 출력4
--END  "컬럼명"	

--IF (조건==결과1){
--}ELSE IF(조건==결과2){
--}ELSE IF(조건==결과3){
--}ELSE{
--}
--	  ,DECODE(SUBSTR(tel,1,INSTR(tel,')')-1 ),'02','SEOUL'
--                                             ,'031','GYEONGGI'
--											 ,'051','BUSAN'
--											 ,'052','ULSAN'
--											 ,'055','GYEONGNAM') "LOC"

SELECT name    
	  ,tel 
      ,CASE (SUBSTR(tel,1,INSTR(tel,')')-1)) WHEN '02'  THEN 'SEOUL'
	                                         WHEN '031' THEN 'GYEONGGI'
											 WHEN '051' THEN 'BUSAN'
											 WHEN '052' THEN 'ULSAN'
											 WHEN '055' THEN 'GYEONGNAM'
											 ELSE 'ETC'
	   END "LOC"									
FROM student
WHERE deptno1=201
;
--NAME                 TEL                            LOC
---------------------- ------------------------------ ------------------
--Demi Moore           02)6255-9875                   SEOUL
--Macaulay Culkin      02)312-9838                    SEOUL
--Wesley Snipes        053)736-4981                   ETC
--Steve Martin         02)6175-3945                   SEOUL
--Sean Connery         02)381-5440                    SEOUL
--Christian Slater     031)345-5677                   GYEONGGI
--
--6 행이 선택되었습니다.











		