SELECT MONTHS_BETWEEN('150201','151201') "MONTHS_BETWEEN"
FROM dual
;
--1행에 오류:
--ORA-01861: 리터럴이 형식 문자열과 일치하지 않음