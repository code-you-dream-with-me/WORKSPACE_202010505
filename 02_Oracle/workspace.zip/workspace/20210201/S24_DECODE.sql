--DECODE(A,B,1,2) : IF ELSE
SELECT name     
      ,deptno   
	  ,DECODE(deptno,101,'Computer Engineering','ETC') "DNAME"
FROM professor
;
--NAME                                         DEPTNO DNAME
------------------------------------------ ---------- ----------------------------------------
--Audie Murphy                                    101 Computer Engineering
--Angela Bassett                                  101 Computer Engineering
--Jessica Lange                                   101 Computer Engineering
--Winona Ryder                                    102 ETC
--Michelle Pfeiffer                               102 ETC
--Whoopi Goldberg                                 102 ETC
--Emma Thompson                                   103 ETC
--Julia Roberts                                   103 ETC
--Sharon Stone                                    103 ETC
--Meryl Streep                                    201 ETC
--Susan Sarandon                                  201 ETC
--Nicole Kidman                                   202 ETC
--Holly Hunter                                    202 ETC
--Meg Ryan                                        203 ETC
--Andie Macdowell                                 301 ETC
--Jodie Foster                                    301 ETC
--
--16 행이 선택되었습니다.