--묵시적(자동) 형변환
--숫자+문자 -> 숫자+숫자
--SELECT 11+TO_NUMBER('13')
SELECT 11+'13'
FROM dual;