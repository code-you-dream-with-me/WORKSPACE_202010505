SELECT profno   
      ,name     
      ,pay      
      ,bonus 
      ,(pay*12+NVL(bonus,0)) "TOTAL"
FROM professor
WHERE deptno  =201
;
--    PROFNO NAME                        PAY      BONUS      TOTAL
------------ -------------------- ---------- ---------- ----------
--      4001 Meryl Streep                570        130       6970
--      4002 Susan Sarandon              330                  3960