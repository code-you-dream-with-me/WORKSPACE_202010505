SELECT t2.dname, T1.max_weight,t1.max_height
FROM (SELECT deptno1,max(weight) max_weight,max(height) max_height
	  FROM student
	  GROUP BY deptno1)T1, department t2
WHERE t1.deptno1 = t2.deptno
;