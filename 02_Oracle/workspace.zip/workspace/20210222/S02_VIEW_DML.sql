--CREATE [OR REPLACE] [FORCE|NOFORCE] VIEW view이름 [ (alias,alias...)]													
--AS SUB_QUERY													
--[WITH CHECK OPTION [CONSTRAINT 제약조건]]													
--[WITH READ ONLY]													
--													
--REPLACE : 같은 이름의 VIEW가 있을 경우 삭제 후 다시 생성													
--FORCE: 기본 테이블의 존재 여부와 상관 없이 VIEW생성													
--NOFORCE: 기본 테이블이 존재 할경우 VIEW생성													
--ALIAS : 기본 테이블의 컬럼이름과 다르게 지정한 VIEW 컬럼													
--WITH CHECK OPTION: 주어진 제약 조건에 맞는 데이터만 입력 수정을 허요													
--WITH READ ONLY: SELECT만 가능한 VIEW	

--VIEW를 통한 DML수행
--1. o_table 테이블 생성
--	CREATE TABLE o_table(
--		a NUMBER,
--		b NUMBER
--	);
	
--2. dml이 가능한 view 
--CREATE VIEW view1
--as
--SELECT a,b
--FROM o_table;


--3. view1 data입력
--INSERT INTO view1 VALUES (1,2);

--4. view1 데이터 조회
--SELECT *
--FROM view1;

--4.1 o_table 데이터 조회
--SELECT *
--FROM o_table;

--ROLLBACK;
SELECT *
FROM o_table;





