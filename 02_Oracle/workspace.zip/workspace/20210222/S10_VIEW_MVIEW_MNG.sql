--MVIEW조회
--SELECT mview_name,
--       query
--FROM user_mviews	   
--WHERE mview_name = 'M_PROF';

--MVIEW삭제
DROP MATERIALIZED VIEW M_PROF;
