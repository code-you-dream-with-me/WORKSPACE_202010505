--09:21:40 SCOTT>conn / as sysdba

--GRANT CREATE VIEW TO scott;
--
--09:23:25 SYS>CONN SCOTT/sist
--연결되었습니다.
--09:29:37 SCOTT>
--문법사항													
--CREATE [OR REPLACE] [FORCE|NOFORCE] VIEW view이름 [ (alias,alias...)]													
--AS SUB_QUERY													
--[WITH CHECK OPTION [CONSTRAINT 제약조건]]													
--[WITH READ ONLY]													
--													
--REPLACE : 같은 이름의 VIEW가 있을 경우 삭제 후 다시 생성													
--FORCE: 기본 테이블의 존재 여부와 상관 없이 VIEW생성													
--NOFORCE: 기본 테이블이 존재 할경우 VIEW생성													
--ALIAS : 기본 테이블의 컬럼이름과 다르게 지정한 VIEW 컬럼													
--WITH CHECK OPTION: 주어진 제약 조건에 맞는 데이터만 입력 수정을 허요													
--WITH READ ONLY: SELECT만 가능한 VIEW													

--view생성
--CREATE OR REPLACE  VIEW v_emp1
--AS 
--SELECT empno,
--       ename,
--	   hiredate
--FROM emp
--;

--view 사용
--SELECT *
--FROM v_emp1
--WHERE ename ='SMITH';


--데이터 없음 확인
--CREATE INDEX IDX_V_EMP_ENAME
--ON v_emp1 (ename );
--
--ON v_emp1 (ename )
--   *
--2행에 오류:
--ORA-01702: 뷰가 여기에 적합하지 않습니다.











