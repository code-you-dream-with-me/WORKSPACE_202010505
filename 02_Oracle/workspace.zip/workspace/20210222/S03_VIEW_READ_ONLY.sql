--읽기 전용 VIEW생성: O_TABLE
--CREATE [OR REPLACE] [FORCE|NOFORCE] VIEW view이름 [ (alias,alias...)]													
--AS SUB_QUERY													
--[WITH CHECK OPTION [CONSTRAINT 제약조건]]													
--[WITH READ ONLY]													
--													
--REPLACE : 같은 이름의 VIEW가 있을 경우 삭제 후 다시 생성													
--FORCE: 기본 테이블의 존재 여부와 상관 없이 VIEW생성													
--NOFORCE: 기본 테이블이 존재 할경우 VIEW생성													
--ALIAS : 기본 테이블의 컬럼이름과 다르게 지정한 VIEW 컬럼													
--WITH CHECK OPTION: 주어진 제약 조건에 맞는 데이터만 입력 수정을 허용													
--WITH READ ONLY: SELECT만 가능한 VIEW	

--1.읽기 전용  view생성
--CREATE OR REPLACE VIEW view2
--AS
--	SELECT a,b
--	FROM o_table
--	WITH READ ONLY;
	
--2. view에 데이터 입력

--INSERT INTO view2 VALUES (1,2);	
---INSERT INTO view2 VALUES (1,2)
---*
---1행에 오류:
---ORA-42399: 읽기 전용 뷰에서는 DML 작업을 수행할 수 없습니다.

--DML 가능 VIEW에서 입력 
--INSERT INTO view1 VALUES (1,2);


--
SELECT *
FROM VIEW2;







