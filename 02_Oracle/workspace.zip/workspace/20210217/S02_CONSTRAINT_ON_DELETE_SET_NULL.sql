--FK를 생성시 OPTION 
--자식테이블의 데이터 추가시, 아버지 FK컬럼에 있는 데이터만 추가 가능
--부모테이블의 데이터 삭제시, 자식테이블의 FK컬럼에 데이터 부터 삭제 되어야 한다.
--1. ON DELETE CASCADE : 부모테이블에 데이터가 지워지면,자식 테이블의 테이터도 함께 지우라.
--2. ON DELETE SET NULL: 부모테이블에 데이터가 지워지면,자식 테이블의 테이터를 NULL로 만든다.

--A.FK DROP

--ALTER TABLE c_test1
--DROP CONSTRAINT c_test1_deptno_fk;


--B.ON DELETE SET NULL

--ALTER TABLE c_test1
--ADD CONSTRAINT c_test1_deptno_fk FOREIGN KEY(deptno)
--REFERENCES c_test2(no)
--ON DELETE SET NULL;


--c_test2 no =20삭제
--DELETE FROM c_test2 
--WHERE no = 20;
--
--SELECT * FROM c_test1;
--        NO NAME                                         DEPTNO
------------ ---------------------------------------- ----------
--         2 banana
--         3 cherry                                           30