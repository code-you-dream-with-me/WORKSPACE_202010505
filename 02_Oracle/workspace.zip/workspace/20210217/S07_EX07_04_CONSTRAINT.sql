--4. 위 3번 문제에서 "사용안함"으로 설정한 제약조건 TCONS_JUMIN_UK 을 사용함으로 변경하되 
--기존에 있던 내용과 새로 들어올 내용 모두를 체크하는 옵션으로 변경하세요.그리고 문제가 되는 
--데이터들은 execptions 테이블에 저장하도록 설정하세요.

--EXCEPTION TABLE생성
--@C:\app\sist\product\18.0.0\dbhomeXE\rdbms\admin\utlexcpt.sql

ALTER TABLE t_cons
ENABLE VALIDATE CONSTRAINT TCONS_JUMIN_UK
EXCEPTIONS  INTO exceptions
;