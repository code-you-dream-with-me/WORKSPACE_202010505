--new_emp2 테이블의 no 컬럼이 emp2 테이블의 empno 컬럼의 값을 참조하도록 참조키 제약 조건을 설정 하세요.
--(child table new_emp2)

ALTER TABLE new_emp2
ADD CONSTRAINT emp2_no_fk FOREIGN KEY(no)
REFERENCES emp2(empno);
 
