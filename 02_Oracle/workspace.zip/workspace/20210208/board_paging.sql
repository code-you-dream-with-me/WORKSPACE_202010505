--ANSI PAGING : ���+��ü�Ǽ�
col CNT for 99999
col rnum for 99999
col seq  for 99999
col read_cnt  for 99999
col title  for a20
col contents  for a20
col mod_dt  for a13
col mod_id  for a13

SELECT a.seq
      ,a.rnum
	  ,a.title
	  ,a.read_cnt
	  ,TO_CHAR(a.mod_dt,'YYYY/MM/DD') MOD_DT
	  ,a.mod_id
      ,b.cnt
FROM (
		SELECT TT1.*
		FROM (
				SELECT rownum rnum,T1.*
				FROM (
						SELECT *   
						FROM board
						--WHERE title like '����_1'||'%'
						--WHERE constents like '����_1'||'%'
						ORDER BY mod_dt DESC
				)T1  
		) TT1
		--WHERE rnum BETWEEN 1 AND 10
		WHERE rnum BETWEEN &PAGE_SIZE*(&PAGE_NUM-1)+1 AND &PAGE_SIZE*(&PAGE_NUM-1)+&PAGE_SIZE
)A CROSS JOIN (
--�ѰǼ�
SELECT COUNT(*) CNT   
FROM board
--WHERE title like '����_1'||'%'
--WHERE constents like '����_1'||'%'
)B
;
