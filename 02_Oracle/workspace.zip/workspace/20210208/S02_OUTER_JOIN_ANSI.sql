-- LEFT OUTER JOIN : 데이터가 존재하는 쪽이 왼쪽 
-- 데이터가 존재하는 쪽에 표시.
col "STU_NAME" for a20
col "PROF_NAME" for a20
SELECT t1.name "STU_NAME"
      ,t2.name "PROF_NAME"
--FROM student t1 LEFT OUTER JOIN professor t2
FROM professor t2 RIGHT OUTER JOIN student t1
ON t1.profno = t2.profno;