col name for  a18
col dname for  a32
--ORACLE
--SELECT t1.name
--      ,t1.deptno1
--	  ,t2.dname
--FROM student t1,department t2
--WHERE t1.deptno1 = t2.deptno
--;

--ANSI
SELECT t1.name
      ,t1.deptno1
	  ,t2.dname
FROM student t1 INNER JOIN department t2
ON t1.deptno1 = t2.deptno
;
--NAME                  DEPTNO1 DNAME
-------------------- ---------- --------------------------------
--James Seo                 101 Computer Engineering
--Danny Devito              101 Computer Engineering
--Richard Dreyfus           101 Computer Engineering
--Billy Crystal             101 Computer Engineering
--Rene Russo                102 Multimedia Engineering
--Charlie Sheen             102 Multimedia Engineering
--Tim Robbins               102 Multimedia Engineering
--Nicholas Cage             102 Multimedia Engineering
--Sandra Bullock            103 Software Engineering
--Anthony Hopkins           103 Software Engineering
--Wesley Snipes             201 Electronic Engineering
--Christian Slater          201 Electronic Engineering
--Macaulay Culkin           201 Electronic Engineering
--Steve Martin              201 Electronic Engineering
--Demi Moore                201 Electronic Engineering
--Sean Connery              201 Electronic Engineering
--Micheal Keaton            202 Mechanical Engineering
--Danny Glover              202 Mechanical Engineering
--Bill Murray               301 Library and Information science
--Daniel Day-Lewis          301 Library and Information science
--
--20 행이 선택되었습니다.