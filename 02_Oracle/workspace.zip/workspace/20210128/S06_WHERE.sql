--문자와 날짜는 반드시 작은 따옴표를 붙여야 한다.
--문자는 대소문자를 구분한다.
SELECT empno
      ,ename
      ,sal
FROM emp
WHERE ename = 'smith'
;

--     EMPNO ENAME                       SAL
------------ -------------------- ----------
--      7369 SMITH                       800