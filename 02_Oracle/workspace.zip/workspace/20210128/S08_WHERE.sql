--입사일:80/12/17
--숫자 외에는 꼭 작은 따옴표를 사용!
--문자는 대소문자를 구분하고, 날짜에는 대소문자 구분이 없다.
SELECT empno
      ,ename
	  ,sal
FROM emp
WHERE hiredate = '80/12/17'
;
--     EMPNO ENAME                       SAL
------------ -------------------- ----------
--      7369 SMITH                       800