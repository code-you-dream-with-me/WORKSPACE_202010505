SELECT ename
      ,sal
FROM emp
WHERE sal < 1000
;
--ENAME                       SAL
---------------------- ----------
--SMITH                       800
--JAMES                       950