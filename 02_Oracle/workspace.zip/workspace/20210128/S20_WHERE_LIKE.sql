--LIKE date
--절대로 %나_를 먼저 쓰면 않된다.
--조회 속도가 저하 된다.
SELECT empno
      ,ename
	  ,hiredate
	  ,sal
FROM emp
WHERE hiredate LIKE '___12%'
;
--     EMPNO ENAME                HIREDATE        SAL
------------ -------------------- -------- ----------
--      7369 SMITH                80/12/17        800
--      7900 JAMES                81/12/03        950
--      7902 FORD                 81/12/03       3000
--
--3 행이 선택되었습니다.