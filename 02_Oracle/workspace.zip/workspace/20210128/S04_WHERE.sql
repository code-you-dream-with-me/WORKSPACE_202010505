--원하는 조건만 골라 내기: WHERE															
--															
--	문법	SELECT [Column or Expression]													
--	   	FROM [Table or View]													
--		WHERE 원하는 조건;													
SELECT empno
      ,ename
FROM emp
WHERE empno =7900
;
--     EMPNO ENAME
------------ --------------------
--      7900 JAMES