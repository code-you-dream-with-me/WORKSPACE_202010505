--비교연산자:>=,<,>,<=		
--숫자 비교 연산			
SELECT empno
      ,ename
	  ,sal
FROM emp
WHERE sal >=1400
;
--     EMPNO ENAME                       SAL
------------ -------------------- ----------
--      7499 ALLEN                      1600
--      7566 JONES                      2975
--      7698 BLAKE                      2850
--      7782 CLARK                      2450
--      7839 KING                       5000
--      7844 TURNER                     1500
--      7902 FORD                       3000
--
--7 행이 선택되었습니다.