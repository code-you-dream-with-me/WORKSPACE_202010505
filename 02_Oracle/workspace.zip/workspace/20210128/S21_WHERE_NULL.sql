--NULL: 값이 무엇인지 모를 경우: IS NULL/IS NOT NULL

--SELECT empno
--      ,ename
--	  ,comm
--	  ,deptno
--FROM emp
--WHERE comm = NULL
--;
--선택된 레코드가 없습니다.

SELECT empno
      ,ename
	  ,comm
	  ,deptno
FROM emp
WHERE comm IS NOT NULL
;
--     EMPNO ENAME                      COMM     DEPTNO
------------ -------------------- ---------- ----------
--      7499 ALLEN                       300         30
--      7521 WARD                        500         30
--      7654 MARTIN                     1400         30
--      7844 TURNER                        0         30

--15:02:19 SCOTT>SELECT 1+NULL FROM DUAL;
--
--    1+NULL
------------
--
--
--1개의 행이 선택되었습니다.