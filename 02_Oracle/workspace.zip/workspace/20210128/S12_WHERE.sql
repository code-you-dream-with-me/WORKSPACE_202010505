--비교연산자:>=,<,>,<=		
--문자 비교 연산	:ename >='W' 문자 W보다 크거나 같은 ename을 찾아라
SELECT empno
      ,ename
	  ,sal
FROM emp
WHERE ename >='W'
;
--     EMPNO ENAME                       SAL
------------ -------------------- ----------
--      7521 WARD                       1250