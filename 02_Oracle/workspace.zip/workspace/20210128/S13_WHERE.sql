--비교연산자:>=,<,>,<=		
--날짜 비교 연산	
SELECT ename
      ,hiredate
FROM emp
WHERE hiredate >= '81/12/25'
;
--ENAME                HIREDATE
---------------------- --------
--MILLER               82/01/23