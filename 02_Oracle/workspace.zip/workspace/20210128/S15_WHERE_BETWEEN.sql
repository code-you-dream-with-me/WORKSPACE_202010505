--비교 컬럼 BETWEEN A AND B: A<=컬럼<=B
--A가 작은 값, B가 큰값
--A<=컬럼  AND 컬럼<=B
--문자
SELECT ename
FROM emp
WHERE ename BETWEEN 'JAMES' AND 'MARTIN'
ORDER BY ename
;
--ENAME
----------------------
--JAMES
--JONES
--KING
--MARTIN