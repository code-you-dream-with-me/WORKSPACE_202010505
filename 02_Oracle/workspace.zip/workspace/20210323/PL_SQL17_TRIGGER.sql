--TRIGGER 생성,수정,삭제 to HR
--관리자 접근
--16:04:36 HR>conn / as sysdba

--TRIGGER 생성,수정,삭제 to HR
GRANT CREATE TRIGGER TO HR;--생성
GRANT ALTER ANY TRIGGER TO HR;--수정
GRANT DROP ANY TRIGGER TO HR;--수정

--데이터베이스에서 TRIGGER를 생성 할수 있는 권한
GRANT ADMINISTER DATABASE TRIGGER TO HR;
