--FUNCTION(함수)
--정해진 작업을 수행하고 결과를 돌려 준다.(RETURN)

--생성 CREATE FUNCTION
--삭제 DROP FUNCTION
--수정 ALTER FUNCTION
--CREATE [OR REPLACE] FUNCTION function_name
--[(
--	parameter1 datatype1,
--	parameter2 datatype2,
--	parameter3 datatype3
--)]
--RETURN DATATYPE;
--IS|AS
--PL/SQL BLOCK

--SELECT MAX(salary) 
--FROM employees
--WHERE department_id = 10;

--MAX(SALARY)
-------------
--       4400

--CREATE OR REPLACE FUNCTION max_sal
--(s_deptno employees.department_id%TYPE)
--RETURN NUMBER
--IS
--	max_sal employees.salary%TYPE;
--BEGIN
--	SELECT MAX(salary) 
--	INTO max_sal
--	FROM employees
--	WHERE department_id = s_deptno;
--	
--	RETURN max_sal;
--END;
--/


--SELECT max_sal(10)
--FROM dual;


SELECT name,
       text
FROM USER_SOURCE
WHERE type ='FUNCTION'
AND name ='MAX_SAL';










