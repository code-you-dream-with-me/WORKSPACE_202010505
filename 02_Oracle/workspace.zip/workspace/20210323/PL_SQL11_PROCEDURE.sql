--사원번호를 입력 받아 해당 사원의 급여를 5000 UPDATE처리

--SELECT employee_id,salary
--FROM employees
--WHERE employee_id = 206;

--CREATE OR REPLACE PROCEDURE up_sal
--( vempid  employees.employee_id%TYPE)
--IS
--	BEGIN
--		UPDATE employees
--		SET salary = 10000
--		WHERE 	employee_id = vempid;
--	END;
--/	

--EXEC up_sal(206);

--SELECT employee_id,salary
--FROM employees
--WHERE employee_id = 206;
--
--EMPLOYEE_ID     SALARY
------------- ----------
--        206      10000

--프로시저 생성 내용 확인
--DESC USER_SOURCE;


SELECT name,
       text
FROM USER_SOURCE
WHERE name = 'UP_SAL';

