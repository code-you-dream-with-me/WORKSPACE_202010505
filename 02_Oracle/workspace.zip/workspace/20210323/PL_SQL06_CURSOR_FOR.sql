--Cursor FOR Loop 문 활용하기: OPEN,FETCH,CLOSE 오라클이 자동으로 수행
--FOR  record_name  IN  cursor_name  LOOP
--  -- 명시적 커서의 OPEN, FETCH 가 자동적으로 수행됨.
--   statement1 ;
--   statement2 ;
--....
--END LOOP ; -- 루프문을 빠져 나갈 때 자동적으로 커서가 CLOSE 됨.



DECLARE
	CURSOR emp_cur IS
	SELECT employee_id,first_name
	FROM employees
	WHERE department_id =100;	
BEGIN
	FOR emp_rec IN emp_cur LOOP
		
		DBMS_OUTPUT.PUT_LINE(emp_rec.employee_id||','||emp_rec.first_name);
	END LOOP;

END;
/
--108,낸시
--109,다니엘
--110,존
--111,이스마엘
--112,호세 마누엘
--113,루이스








