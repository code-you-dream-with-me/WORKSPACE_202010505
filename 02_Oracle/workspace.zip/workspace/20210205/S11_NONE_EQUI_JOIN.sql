--NON-EQUI JOIN(비등가 조인)
--
--CUSTOMER테이블과, GIFT테이블을 조회하여
--고객별로 마일리지 포인트를 조회하여, 마일리지별 받을 수있는 상품을 조회 하여라.

--SELECT gname
--      ,point
--FROM customer
--;
--
--SELECT *
--FROM gift;
--G_START      G_END
col gname for a20
col point for 99999999
col "GIFT_NAME" for a20
SELECT t1.gname
      ,t1.point
	  ,t2.gname "GIFT_NAME"
FROM customer t1, gift t2
WHERE t1.point BETWEEN t2.g_start AND t2.g_end
;

--GNAME                    POINT GIFT_NAME
---------------------- --------- --------------------
--Bill Pullman             65000 Tuna Set
--Mel Gibson               73000 Tuna Set
--Michael Douglas          99000 Tuna Set
--Brad Pitt               110000 Shampoo Set
--Samuel Jackson          153000 Shampoo Set
--Liam Neeson             180000 Shampoo Set
--Arnold Scharz           265000 Car wash Set
--Ahnjihye                273000 Car wash Set
--Tom Hanks               298000 Car wash Set
--Jim Carrey              315000 Kitchen Supplies Set
--Bruce Willis            320000 Kitchen Supplies Set
--Angela Bassett          420000 Mountain bike
--Robin Williams          470000 Mountain bike
--Morgan Freeman          542000 LCD Monitor
--Jessica Lange           598000 LCD Monitor
--Winona Ryder            625000 Notebook
--Michelle Pfeiffer       670000 Notebook
--James Seo               980000 Refrigerator
--
--18 행이 선택되었습니다.