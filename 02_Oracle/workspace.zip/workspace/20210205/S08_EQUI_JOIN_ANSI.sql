--학생의 이름,학과 이름,학생의 지도교수이름
COL "STU" FOR A25
COL "PROF" FOR A25
COL "DEPT_NAME" FOR A35  
SELECT t1.name "STU"
      ,t2.name "PROF"
      ,t3.dname "DEPT_NAME"	  
FROM student t1 JOIN professor t2
ON t1.profno = t2.profno
JOIN department t3
ON t1.deptno1= t3.deptno
;