--LOWER(),UPPER()
--LOWER(문자열 또는 컬럼) : 함수에 입력된 값을 전부 소문자로 변환
--UPPER(문자열 또는 컬럼) : 함수에 입력된 값을 전부 대문자로 변환

SELECT ename
      ,LOWER(ename)
	  ,UPPER(ename)
FROM emp
WHERE deptno =10
;
--ENAME                LOWER(ENAME)         UPPER(ENAME)
---------------------- -------------------- --------------------
--CLARK                clark                CLARK
--KING                 king                 KING
--MILLER               miller               MILLER