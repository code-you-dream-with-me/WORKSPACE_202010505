SELECT name
      ,tel
	  ,REPLACE(tel,SUBSTR(tel,INSTR(tel,')')+1,3),'***') "SUBSTR"
FROM student
WHERE deptno1 =102
;

NAME             TEL            SUBSTR
---------------- -------------- -------------
Rene Russo       051)426-1700   051)***-1700
Nicholas Cage    051)418-9627   051)***-9627
Tim Robbins      055)488-2998   055)***-2998
Charlie Sheen    055)423-9870   055)***-9870