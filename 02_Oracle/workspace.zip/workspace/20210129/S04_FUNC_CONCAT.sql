--CONCAT() : ||연산자와 동일

SELECT CONCAT(ename,job),
       ename || job
FROM emp
WHERE deptno = 10
;

--CONCAT(ENAME,JOB)                      ENAME||JOB
---------------------------------------- --------------------------------------
--CLARKMANAGER                           CLARKMANAGER
--KINGPRESIDENT                          KINGPRESIDENT
--MILLERCLERK                            MILLERCLERK