--** SUBSTR() : 주어진 문자열에서 특정 길이에 문자를 잘라 낼때 사용.
--SUBSTR('문자열 또는 컬럼',1,4)
--양수 이면 왼쪽에서 오른쪽
--음수 이면 오른쪽에서 왼쪽
COL  "3,2"  FOR a6
COL  "-3,2"  FOR a6
COL  "-3,4"  FOR a6
SELECT SUBSTR('ABCDE',3,2) "3,2"
      ,SUBSTR('ABCDE',-3,2) "-3,2"
	  ,SUBSTR('ABCDE',-3,4) "-3,4"
FROM dual;