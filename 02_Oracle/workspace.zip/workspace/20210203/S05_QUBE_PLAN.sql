explain plan for

SELECT deptno
      ,job
      ,ROUND(AVG(NVL(sal,0)),1) "AVG_SAL"
	  ,COUNT(*)
FROM emp
GROUP BY CUBE( deptno,job )
ORDER BY deptno,job
;


col plan_table_output format a80
SELECT * FROM table(dbms_xplan.display);


--PLAN_TABLE_OUTPUT
----------------------------------------------------------------------------------
--Plan hash value: 3627207636
--
-------------------------------------------------------------------------------
--| Id  | Operation            | Name | Rows  | Bytes | Cost (%CPU)| Time     |
-------------------------------------------------------------------------------
--|   0 | SELECT STATEMENT     |      |    11 |   165 |     4  (25)| 00:00:01 |
--|   1 |  SORT GROUP BY       |      |    11 |   165 |     4  (25)| 00:00:01 |
--|   2 |   GENERATE CUBE      |      |    11 |   165 |     4  (25)| 00:00:01 |
--|   3 |    SORT GROUP BY     |      |    11 |   165 |     4  (25)| 00:00:01 |
--|   4 |     TABLE ACCESS FULL| EMP  |    12 |   180 |     3   (0)| 00:00:01 |
-------------------------------------------------------------------------------
--
--11 행이 선택되었습니다.