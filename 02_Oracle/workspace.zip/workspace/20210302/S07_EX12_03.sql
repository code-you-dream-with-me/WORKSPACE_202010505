--emp2 테이블에서 Kevin Coster 사원의 상사들을 계층 쿼리로 아래와 같이 출력 하세요.
col "Name and Position" for a120
SELECT LPAD(t1.name||'-'||t2.dname ||'-'|| NVL(t1.position,'Team Worker')
       ,LEVEL*37,'-') "Name and Position"
FROM emp2 t1,dept2 t2
WHERE t1.deptno = t2.dcode
START WITH t1.empno = (SELECT empno 
                       FROM emp2 
                       WHERE name ='Kevin Costner')
CONNECT BY  t1.empno = PRIOR t1.pempno;
--Name and Position
--------------------------------------------------------------------------------------------------------------------------
--Kevin Costner-Sales4 Team-Team Worker
-------------------------Chris O'Donnell-Business Planning Team-Section head
-------------------------------------------------------------------Val Kilmer-Business Department-Department head
------------------------------------------------------------------------------------------------Kurt Russell-President-Boss
