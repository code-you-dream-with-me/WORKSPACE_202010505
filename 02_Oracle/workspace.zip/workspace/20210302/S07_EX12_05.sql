--아래와 같이 emp2테이블과 dept2 테이블을 join하여 사번과,사원명-부서-직급,부하직원수를 출력 하세요.

SELECT t1.empno, 
       t1.name||'-'||t2.dname ||'-'|| NVL(t1.position,'Team Worker')"ENAME",
	   (SELECT COUNT(*)
	    FROM emp2 t3
		START WITH t3.empno = t1.empno
		CONNECT BY PRIOR t3.empno = t3.pempno)-1 "COUNT"
FROM emp2 t1,dept2 t2
WHERE t1.deptno = t2.dcode
ORDER BY 3 DESC