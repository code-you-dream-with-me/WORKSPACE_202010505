--ROLLUP(소그룹,,,,,) : N+1 LEVEL에 소계 출력
--ROLLUP()에 지정된 컬럼들은 소계의 기준이 되는 컬럼이다.
--만약에  OLLUP()에 지정된 컬럼이 N개 라면 N+1의 소계가 생성
--1. 부서와 직급별 평균 급여 및 사원, 부서별 평균 급여와 사원수, 전체 사원의 평균 급여와 사원수

--부서와 직급별 평균 급여 및 사원
--UNION ALL
--부서별 평균 급여와 사원수
--UNION ALL
--전체 사원의 평균 급여와 사원수

--1.부서와 직급별 평균 급여 및 사원
--SELECT deptno
--      ,job
--	  ,AVG( NVL(sal,0)) "AVG"
--	  ,COUNT(*) "COUNT"
--FROM emp
--GROUP BY deptno,job
--;

--2.부서별 평균 급여와 사원수
--SELECT deptno
--      ,NULL job
--	  ,AVG( NVL(sal,0)) "AVG"
--	  ,COUNT(*) "COUNT"
--FROM emp
--GROUP BY deptno
--;

--3.전체 사원의 평균 급여와 사원수
--SELECT NULL deptno
--      ,NULL job
--	  ,AVG( NVL(sal,0)) "AVG"
--	  ,COUNT(*) "COUNT"
--FROM emp
--;


--SELECT deptno,job,AVG( NVL(sal,0)) "AVG",COUNT(*) "COUNT"
--FROM emp
--GROUP BY deptno,job
--UNION ALL
--SELECT deptno,NULL job,AVG( NVL(sal,0)) "AVG",COUNT(*) "COUNT"
--FROM emp
--GROUP BY deptno
--UNION ALL
--SELECT NULL deptno,NULL job,AVG( NVL(sal,0)) "AVG",COUNT(*) "COUNT"
--FROM emp
--ORDER BY deptno,job
--;
--    DEPTNO JOB                       AVG      COUNT
------------ ------------------ ---------- ----------
--        10 CLERK                    1300          1
--        10 MANAGER                  2450          1
--        10 PRESIDENT                5000          1
--        10                    2916.66667          3
--        20 ANALYST                  3000          1
--        20 CLERK                     800          1
--        20 MANAGER                  2975          1
--        20                    2258.33333          3
--        30 CLERK                     950          1
--        30 MANAGER                  2850          1
--        30 SALESMAN                 1400          4
--        30                    1566.66667          6
--                              2077.08333         12
--
--13 행이 선택되었습니다.

--*ROLLUP:  ROLLUP(deptno,job) 순서도 중요한 의미를 가진다.
--GROUP BY ROLLUP(deptno,job) ,1.deptno 그룹집계
--                            ,2.deptno,job 그룹집계
--                            ,3.전체 그룹집계
SELECT  deptno
		,job
		,AVG( NVL(sal,0)) "AVG",COUNT(*) "COUNT"
FROM emp
GROUP BY ROLLUP(deptno,job)
;
--    DEPTNO JOB                       AVG      COUNT
------------ ------------------ ---------- ----------
--        10 CLERK                    1300          1
--        10 MANAGER                  2450          1
--        10 PRESIDENT                5000          1
--        10                    2916.66667          3
--        20 CLERK                     800          1
--        20 ANALYST                  3000          1
--        20 MANAGER                  2975          1
--        20                    2258.33333          3
--        30 CLERK                     950          1
--        30 MANAGER                  2850          1
--        30 SALESMAN                 1400          4
--        30                    1566.66667          6
--                              2077.08333         12
--
--13 행이 선택되었습니다.































