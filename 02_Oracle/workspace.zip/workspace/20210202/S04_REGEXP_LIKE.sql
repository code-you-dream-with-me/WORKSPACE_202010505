--{}: 횟수 또는 범위를 나타냅니다.
--[]:해당 문자에 해당하는 한 문자

-- 연속적인 대문자 3글자
SELECT *
FROM t_reg
WHERE REGEXP_LIKE(text,'[A-Z]{3}');

