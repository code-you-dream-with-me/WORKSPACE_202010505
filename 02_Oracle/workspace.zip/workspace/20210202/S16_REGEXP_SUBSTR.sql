--REGEXP_SUBSTR: 정규식을 검색하여 문자추출
--REGEXP_SUBSTR(source_char, pattern
--              [, position
--                 [, occurrence
--                    [, match_param
--                       [, subexpr
--                       ]
--                    ]
--                 ]
--              ]
--             )
--* : 모든 이라는 뜻. 글자수가 0 일수도 있음.
--[ ]:해당 문자에 해당하는 한 문자
--[^]:해당 문자에 해당하지 않는 한 문자
--^ : 해당 문자로 시작하는 line 출력
--$ (달러):해당 문자로 끝나는 line 출력
--| : 패턴을 OR 연산을 수행할 때 사용합니다.
--():괄호안의 문자를 하나의 문자로 인식합니다.

--\:역슬러쉬 뒤 문자는 문자 그대로 해석.
--.:임의의 문자 [단 ‘'는 넣을 수 없습니다.]
--?:앞 문자가 없거나 하나 있을 수 있습니다.
--+:앞 문자가 1개 이상의 개수가 존재할 수 있습니다.
--REGEXP_SUBSTR: 정규식을 검색하여 문자추출
SELECT 'ABC* *DEF $GHI%KJL'
      ,REGEXP_SUBSTR('ABC* *DEF $GHI%KJL','[^ ]+[DEF]')
FROM dual;













