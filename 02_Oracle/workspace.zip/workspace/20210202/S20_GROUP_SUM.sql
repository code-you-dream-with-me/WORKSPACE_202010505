--SUM:입력 데이터의 합계
SELECT SUM(comm) "SUM_COMM"
      ,COUNT(comm) "COUNT_COMM"
FROM emp
;
--  SUM_COMM COUNT_COMM
------------ ----------
--      2200          4