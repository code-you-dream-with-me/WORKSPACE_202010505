--STDDEV:입력 데이터의 표준편차
--VARIANCE:입력 데이터의 분산

--분산(variance)
--분산은 평균에 대한 편차 제곱의 평균을 구한 값이다.
--
--표준편차(standard deviation)
--표준편차는 분산의 양의 제곱근으로 정의 된다.

SELECT VARIANCE(sal)
      ,STDDEV(sal)
      ,AVG(NVL(sal,0))
FROM emp;

--VARIANCE(SAL) STDDEV(SAL) AVG(NVL(SAL,0))
--------------- ----------- ---------------
--   1488347.54   1219.9785      2077.08333