--*MAX,MIN 순서대로 정렬후 최대 최소를 구한다.
--MAX:입력 데이터의 최대값
--MIN:입력 데이터의 최소값
--SELECT sal
--FROM emp
--ORDER BY sal 
--;

SELECT MAX(sal)
      ,MIN(sal)
FROM emp
;