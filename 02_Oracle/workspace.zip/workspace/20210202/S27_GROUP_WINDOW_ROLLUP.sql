--
--SELECT position 
--      ,pay      
--      ,deptno   
--FROM professor
--;
--POSITION                                                            PAY     DEPTNO
-------------------------------------------------------------- ---------- ----------
--a full professor                                                    550        101
--assistant professor                                                 380        101
--instructor                                                          270        101
--instructor                                                          250        102
--assistant professor                                                 350        102
--a full professor                                                    490        102
--a full professor                                                    530        103
--assistant professor                                                 330        103
--instructor                                                          290        103
--a full professor                                                    570        201
--assistant professor                                                 330        201
--assistant professor                                                 310        202
--instructor                                                          260        202
--a full professor                                                    500        203
--instructor                                                          220        301
--assistant professor                                                 290        301
--
--16 행이 선택되었습니다.

--SELECT position 
--      ,SUM(pay)  
--FROM professor
--GROUP BY position
--;
--POSITION                                                       SUM(PAY)
-------------------------------------------------------------- ----------
--assistant professor                                                1990
--a full professor                                                   2640
--instructor                                                         1290
--COL  position FOR A20
--SELECT deptno
--      ,position
--	  ,COUNT(*)	  
--      ,SUM(pay)
--FROM professor
--GROUP BY position,ROLLUP(deptno)
--;
--    DEPTNO POSITION               COUNT(*)   SUM(PAY)
------------ -------------------- ---------- ----------
--       101 instructor                    1        270
--       102 instructor                    1        250
--       103 instructor                    1        290
--       202 instructor                    1        260
--       301 instructor                    1        220
--           instructor                    5       1290
--       101 a full professor              1        550
--       102 a full professor              1        490
--       103 a full professor              1        530
--       201 a full professor              1        570
--       203 a full professor              1        500
--           a full professor              5       2640
--       101 assistant professor           1        380
--       102 assistant professor           1        350
--       103 assistant professor           1        330
--       201 assistant professor           1        330
--       202 assistant professor           1        310
--       301 assistant professor           1        290
--           assistant professor           6       1990
--
--19 행이 선택되었습니다.

--deptno 그룹핑한 후 position별로 rollup
COL  position FOR A20
SELECT deptno
      ,position
	  ,COUNT(*)	  
      ,SUM(pay)
FROM professor
GROUP BY deptno ,ROLLUP(position)
;

--15:31:58 SCOTT>@S27_GROUP_WINDOW_ROLLUP.sql
--
--    DEPTNO POSITION               COUNT(*)   SUM(PAY)
------------ -------------------- ---------- ----------
--       101 instructor                    1        270
--       101 a full professor              1        550
--       101 assistant professor           1        380
--       101                               3       1200
--       102 instructor                    1        250
--       102 a full professor              1        490
--       102 assistant professor           1        350
--       102                               3       1090
--       103 instructor                    1        290
--       103 a full professor              1        530
--       103 assistant professor           1        330
--       103                               3       1150
--       201 a full professor              1        570
--       201 assistant professor           1        330
--       201                               2        900
--       202 instructor                    1        260
--       202 assistant professor           1        310
--       202                               2        570
--       203 a full professor              1        500
--       203                               1        500
--       301 instructor                    1        220
--       301 assistant professor           1        290
--       301                               2        510
--
--23 행이 선택되었습니다.








