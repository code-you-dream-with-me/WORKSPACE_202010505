--emp2테이블과 dept2 테이블을 참조 해서
--근무지역이 Pohang Main Office인 모든 사원들의 이름, 부서번호를 출력 하세요.
SELECT t1.name,
       t1.empno,
	   t1.deptno
FROM emp2 t1 
WHERE t1.deptno IN (SELECT dcode
                   FROM dept2
                   WHERE area = 'Pohang Main Office'
);

NAME                  EMPNO DEPTNO
---------------- ---------- ------------
Kurt Russell       19900101 0001
Kevin Bacon        19966102 1003
Val Kilmer         19970112 1006
Chris O'Donnell    19960212 1007