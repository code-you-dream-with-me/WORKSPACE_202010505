--3.다중 컬럼 Sub query																	
--		1. sub query의 수행 결과가 여러 컬럼인 경우															
--		2. pk를 여러 컬럼에 잡은 경우 한꺼번에 비교하기 위해 사용.															


--student 테이블에서 각 학년별로, 최대 몸무게를 가진 학생들의
--학년,이름,몸무게를 출력 하세요.
SELECT t2.grade,
       t2.weight,
	   t2.name
FROM student t2
WHERE (t2.grade,t2.weight) IN (SELECT grade,MAX(t1.weight) "max_weight"
						       FROM student t1
                               GROUP BY grade
)
ORDER BY 1
;
--     GRADE     WEIGHT NAME
------------ ---------- -------------------------
--         1         81 Charlie Sheen
--         2         82 Wesley Snipes
--         3         58 Bill Murray
--         4         83 Demi Moore