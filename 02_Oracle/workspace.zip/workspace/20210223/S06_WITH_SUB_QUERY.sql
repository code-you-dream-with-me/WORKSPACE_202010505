--반복적인 테이블을 한 번만 수행하도록 하고 소요 시간 측정.
--PAY중에 제일 작은 값과, 제일 큰 값, 그리고 제일 큰 값과 제일 작은 값 차일를 구하세요.

--PAY에 만들어 두었던 인덱스(idx_with_pay) 삭제.
--DROP INDEX idx_with_pay;

--UNION ALL
--explain plan for
SELECT 'MAX_PAY' C1, MAX(pay) max_pay FROM with_test1
UNION ALL
SELECT 'MIN_PAY' C1, MIN(pay) min_pay FROM with_test1
UNION ALL
SELECT 'MAX_PAY - MIN_PAY' C1, MAX(pay) - MIN(pay) diff_pay FROM with_test1
;

--C1                                    MAX_PAY
------------------------------------ ----------
--MAX_PAY                                999999
--MIN_PAY                                     6
--MAX_PAY - MIN_PAY                      999993

--col plan_table_output format a150;
--select * from table(dbms_xplan.display);

--PLAN_TABLE_OUTPUT
--------------------------------------------------------------------------------------------------------------------------------------------------------
--Plan hash value: 3726690553
--
------------------------------------------------------------------------------------
--| Id  | Operation           | Name       | Rows  | Bytes | Cost (%CPU)| Time   |
------------------------------------------------------------------------------------
--|   0 | SELECT STATEMENT    |            |     3 |    39 | 12482   (2)| 00:00:01 |
--|   1 |  UNION-ALL          |            |       |       |            |        |
--|   2 |   SORT AGGREGATE    |            |     1 |    13 |            |        |
--|   3 |    TABLE ACCESS FULL| WITH_TEST1 |  4691K|    58M|  4161   (2)| 00:00:01 |
--|   4 |   SORT AGGREGATE    |            |     1 |    13 |            |        |
--|   5 |    TABLE ACCESS FULL| WITH_TEST1 |  4691K|    58M|  4161   (2)| 00:00:01 |
--|   6 |   SORT AGGREGATE    |            |     1 |    13 |            |        |
--|   7 |    TABLE ACCESS FULL| WITH_TEST1 |  4691K|    58M|  4161   (2)| 00:00:01 |
------------------------------------------------------------------------------------
--
--Note
-------
--   - dynamic statistics used: dynamic sampling (level=2)
--
--18 행이 선택되었습니다.
--
--경   과: 00:00:00.43
--explain plan for
WITH sub_pay AS (
	SELECT MAX(pay) max_pay,
		   MIN(pay) min_pay
	FROM with_test1
)
SELECT 'MAX_PAY' C1, max_pay FROM sub_pay 
UNION ALL
SELECT 'MIN_PAY' C1, min_pay FROM sub_pay 
UNION ALL
SELECT 'MAX_PAY - MIN_PAY' C1, (max_pay - min_pay) diff_pay FROM sub_pay
;
--C1                                    MAX_PAY
------------------------------------ ----------
--MAX_PAY                                999999
--MIN_PAY                                     6
--MAX_PAY - MIN_PAY                      999993

col plan_table_output format a150;
select * from table(dbms_xplan.display);

PLAN_TABLE_OUTPUT
------------------------------------------------------------------------------------------------------------------------------------------------------
Plan hash value: 4008546313

----------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                | Name
             | Rows  | Bytes | Cost (%CPU)| Time     |
----------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                         |            |     3 |    52 |     6   (0)| 00:00:01 |
|   1 |  TEMP TABLE TRANSFORMATION               |            |       |       |            |          |
|   2 |   LOAD AS SELECT (CURSOR DURATION MEMORY)| SYS_TEMP_0FD9D6D72_373813 |             |       |            |          |
|   3 |    SORT AGGREGATE                        |            |     1 |    13 |            |          |
|   4 |     TABLE ACCESS FULL                    | WITH_TEST1 |  4691K|    58M|  4161   (2)| 00:00:01 |
|   5 |   UNION-ALL                              |            |       |       |            |          |
|   6 |    VIEW                                  |            |     1 |    13 |     2   (0)| 00:00:01 |
|   7 |     TABLE ACCESS FULL                    | SYS_TEMP_0FD9D6D72_373813 |           1 |    13 |     2   (0)| 00:00:01 |
|   8 |    VIEW                                  |            |     1 |    13 |     2   (0)| 00:00:01 |
|   9 |     TABLE ACCESS FULL                    | SYS_TEMP_0FD9D6D72_373813 |           1 |    13 |     2   (0)| 00:00:01 |
|  10 |    VIEW                                  |            |     1 |    26 |     2   (0)| 00:00:01 |
|  11 |     TABLE ACCESS FULL                    | SYS_TEMP_0FD9D6D72_373813 |           1 |    13 |     2   (0)| 00:00:01 |
----------------------------------------------------------------------------------------------------------------------

Note
-----
   - dynamic statistics used: dynamic sampling (level=2)

22 행이 선택되었습니다.
