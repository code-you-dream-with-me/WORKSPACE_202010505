col "STUD_NAME" for a20
col "DEPT_NAME" for a20

SELECT name "STUD_NAME",t2.dname "DEPT_NAME"
FROM student t1,department t2
WHERE t1.deptno1 = t2.deptno
AND t1.deptno1 = (SELECT deptno1
                  FROM student
                  WHERE name ='Anthony Hopkins')
;
--STUD_NAME            DEPT_NAME
---------------------- --------------------
--Anthony Hopkins      Software Engineering
--Sandra Bullock       Software Engineering