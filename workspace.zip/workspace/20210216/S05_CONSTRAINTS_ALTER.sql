--new_emp2 HIREDATE 컬럼에 NOT NULL을 추가(변경).
--ALTER TABLE 테이블이름
--MODIFY (hiredate CONSTRAINT emp2_hiredate_nn NOT NULL );

ALTER TABLE new_emp2
MODIFY (hiredate CONSTRAINT emp2_hiredate_nn NOT NULL );