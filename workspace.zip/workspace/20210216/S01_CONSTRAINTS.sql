--테이블 생성시 제약 조건 지정.
--PRIMARY KEY :NOT NULL + UNIQUE
--column CONSTRAINT 이름1 제약조건1
--column CONSTRAINT 이름2 제약조건2

--fk
--column CONSTRAINT 이름2 REFERENCES 테이블(컬럼)
CREATE TABLE new_emp1(
	no NUMBER(4)           CONSTRAINT new_emp1_pk PRIMARY KEY,
    name VARCHAR2(20 BYTE) CONSTRAINT emp1_name_nn NOT NULL,
	jumin VARCHAR2(13 BYTE) 
	  CONSTRAINT emp1_jumin_nn NOT NULL
	  CONSTRAINT emp1_jumin_uk UNIQUE,
	loc_code NUMBER(1)      CONSTRAINT emp1_loc_code_ck  CHECK(loc_code<5),
	deptno VARCHAR2(6 BYTE) CONSTRAINT emp1_deptno_fk  REFERENCES dept2(DCODE)
);