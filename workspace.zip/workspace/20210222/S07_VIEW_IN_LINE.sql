--professor테이블에서 lag와 inline view를 활용해서 중복된 항목을 제거해서 보여주기
--SELECT deptno, profno,name
--FROM professor;

----중복된 deptno 제거하고 출력
--  DEPTNO     PROFNO NAME
------------ ---------- ----------------------------------------
--       101       1001 Audie Murphy
--                 1002 Angela Bassett
--                 1003 Jessica Lange
--       102       2001 Winona Ryder
--                 2002 Michelle Pfeiffer
--                 2003 Whoopi Goldberg
--       103       3001 Emma Thompson
--       103       3002 Julia Roberts
--       103       3003 Sharon Stone
--       201       4001 Meryl Streep
--       201       4002 Susan Sarandon
--       202       4003 Nicole Kidman
--       202       4004 Holly Hunter
--       203       4005 Meg Ryan
--       301       4006 Andie Macdowell
--       301       4007 Jodie Foster
--                 5001 James Bond

COL deptno FOR A10
COL profno FOR 9999
COL name   FOR A20
SELECT DECODE(deptno,ndeptno,null,deptno) deptno,profno,name
FROM( SELECT LAG(deptno) OVER(order by deptno) ndeptno,deptno, profno,name
	  FROM professor  
) t1;

--   NDEPTNO     DEPTNO     PROFNO NAME
------------ ---------- ---------- ----------------------------------------
--                  101       1002 Angela Bassett
--       101        101       1001 Audie Murphy
--       101        101       1003 Jessica Lange
--       101        102       2001 Winona Ryder
--       102        102       2002 Michelle Pfeiffer
--       102        102       2003 Whoopi Goldberg
--       102        103       3002 Julia Roberts
--       103        103       3001 Emma Thompson
--       103        103       3003 Sharon Stone
--       103        201       4001 Meryl Streep
--       201        201       4002 Susan Sarandon
--       201        202       4003 Nicole Kidman
--       202        202       4004 Holly Hunter
--       202        203       4005 Meg Ryan
--       203        301       4006 Andie Macdowell
--       301        301       4007 Jodie Foster
--       301                  5001 James Bond


--DEPTNO     PROFNO NAME
------------ ------ --------------------
--101          1002 Angela Bassett
--             1001 Audie Murphy
--             1003 Jessica Lange
--102          2001 Winona Ryder
--             2002 Michelle Pfeiffer
--             2003 Whoopi Goldberg
--103          3002 Julia Roberts
--             3001 Emma Thompson
--             3003 Sharon Stone
--201          4001 Meryl Streep
--             4002 Susan Sarandon
--202          4003 Nicole Kidman
--             4004 Holly Hunter
--203          4005 Meg Ryan
--301          4006 Andie Macdowell
--             4007 Jodie Foster
--             5001 James Bond