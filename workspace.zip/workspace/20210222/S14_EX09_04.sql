col grade for 99999
col avg_height for 9999.9
col name for a25
col height for 99999
SELECT t1.grade,
       t1.avg_height,
       t2.height,
       t2.name
FROM (
        SELECT grade,AVG(height) avg_height
        FROM student
        GROUP BY grade
)t1, student t2
WHERE t1.grade = t2.grade
AND   t1.avg_height <= t2.height
ORDER BY 1
;

--- GRADE AVG_HEIGHT HEIGHT NAME
--------- ---------- ------ -------------------------
---     1      170.4    175 Sean Connery
---     1      170.4    173 Christian Slater
---     1      170.4    179 Charlie Sheen
---     2      175.6    182 Richard Dreyfus
---     2      175.6    184 Daniel Day-Lewis
---     3      166.6    177 Micheal Keaton
---     3      166.6    171 Macaulay Culkin
---     4      175.8    180 James Seo
---     4      175.8    177 Demi Moore
---     4      175.8    182 Danny Glover
---
---10 행이 선택되었습니다.