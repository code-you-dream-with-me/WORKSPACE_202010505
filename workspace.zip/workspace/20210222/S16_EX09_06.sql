SELECT num,profno,name,pay,avg_pay
FROM (
	SELECT rownum num,
		   profno,
		   name,
		   pay,
		   pay avg_pay,
		   ceil(rownum/3) gnum
	FROM professor
	UNION ALL
    SELECT null num,
		   null profno,
		   null name,
           SUM(PAY),
		   ROUND(AVG(PAY),1),
           gnum
    FROM (
            SELECT pay,
                   ceil(rownum/3) gnum
            FROM professor
            ORDER BY profno
    ) GROUP BY gnum
)
ORDER BY gnum,num;
--       NUM PROFNO NAME                             PAY    AVG_PAY
------------ ------ ------------------------- ---------- ----------
--         1   1001 Audie Murphy                     550        550
--         2   1002 Angela Bassett                   380        380
--         3   1003 Jessica Lange                    270        270
--                                                  1200        400
--         4   2001 Winona Ryder                     250        250
--         5   2002 Michelle Pfeiffer                350        350
--         6   2003 Whoopi Goldberg                  490        490
--                                                  1090      363.3
--         7   3001 Emma Thompson                    530        530
--         8   3002 Julia Roberts                    330        330
--         9   3003 Sharon Stone                     290        290
--                                                  1150      383.3
--        10   4001 Meryl Streep                     570        570
--        11   4002 Susan Sarandon                   330        330
--        12   4003 Nicole Kidman                    310        310
--                                                  1210      403.3
--        13   4004 Holly Hunter                     260        260
--        14   4005 Meg Ryan                         500        500
--        15   4006 Andie Macdowell                  253        253
--                                                  1013      337.7
--        16   4007 Jodie Foster                     290        290
--                                                   290        290
--
--22 행이 선택되었습니다.