SELECT TT1.* 
FROM (
	SELECT RANK() OVER(ORDER BY pay desc)Ranking,t1.name,pay
	FROM professor t1
	ORDER BY pay desc
)TT1
WHERE Ranking<=5
;