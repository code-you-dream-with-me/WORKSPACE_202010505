--SYNONYM (시노님 - 동의어)
--1. 보안(다른 user의 객체를 참조할 때 많이 사용.)
--2. 사용자 편의성(긴 이름의 객체를 단축 이름으로 사용.)

--SYNONYM 생성권한 필요.

--문법
--CREATE [PUBLIC ] SYNONYM 시노님_이름
--FOR [SCOTT] 대삭객체;

--PUBLIC이 붙으면 모든 사람이 사용가능(단 권한 필요.)
--PUBLIC이 없으면 만든 사람만 사용가능

--SYS 전환
--16:03:35 SCOTT>conn /as sysdba
--연결되었습니다.
--16:03:54 SYS>

--PRIVATE SYNONYM
--GRANT CREATE SYNONYM TO SCOTT;
--
----PUBLIC SYNONYM
--GRANT CREATE PUBLIC SYNONYM TO SCOTT;
--
----미국철수
--16:05:02 SYS>conn scott/sist
--연결되었습니다.
--16:05:33 SCOTT>

--public SYNONYM생성
--CREATE PUBLIC SYNONYM d2
--FOR  dept;

--동의어가 생성되었습니다.
--
--경   과: 00:00:00.34

--SELECT *
--FROM d2;
--    DEPTNO DNAME                        LOC
------------ ---------------------------- --------------------------
--        10 ACCOUNTING                   NEW YORK
--        20 RESEARCH                     DALLAS
--        30 SALES                        CHICAGO
--        40 OPERATIONS                   BOSTON
--
--경   과: 00:00:00.01

--SYNONYM 조회 하기
--DESC user_synonyms;


--PRIVATE SYNONYM생성
--CREATE  SYNONYM e
--FOR  emp;
--
----private SYNONYM만 조회 가능.
--SELECT synonym_name
--	,table_name
--	,table_owner
--FROM user_synonyms
----WHERE table_name ='DEPT'
--;


--dba_synonyms
--계정전환 
--16:12:56 SCOTT>conn /as sysdba
--연결되었습니다.
--16:14:01 SYS>

COL synonym_name FOR A20
COL table_name FOR A20
COL table_owner FOR A15
SELECT synonym_name
	,table_name
	,table_owner
FROM dba_synonyms
WHERE table_name ='DEPT'
;

--SYNONYM_NAME         TABLE_NAME           TABLE_OWNER
---------------------- -------------------- ---------------
--D2                   DEPT                 SCOTT
--
--경   과: 00:00:00.02

--삭제 PUBLIC SYNONYM
DROP PUBLIC SYNONYM D2;

--계정전환 
16:16:39 SYS>conn scott/sist
연결되었습니다.
16:17:18 SCOTT>















