--1.�������̺� ����: Small(1000��)
--1.1. �ֹ����̺� ����: Big(1000000��)
--2.�ֹ����̺� �ε��� ����: exists 
--3.�����ȹ

--1.
--CREATE TABLE cust_t(
--	cust_no VARCHAR2(1000),
--	cust_nm VARCHAR2(1000)
--);

--1. ITAS�� 1000���Է�
--INSERT INTO cust_t
--SELECT level,
--       'SCOTT'||TO_CHAR(LEVEL,'000')
--FROM dual 
--CONNECT BY LEVEL<=1000;

--������ �Է� ����
--SELECT COUNT(*) 
--FROM cust_t;


--1.1. �ֹ����̺�
--CREATE TABLE order_t(
--	order_no   VARCHAR2(4000),
--	cust_no    VARCHAR2(1000),
--	orderdd    VARCHAR2(8),
--	product_nm VARCHAR2(4000)
--);

--append hint : insert�ӵ� ���
--(�����ͺ��̽��� noarchive mode�� ��� Ȥ�� table�� nologging���� ������ ���)
--INSERT /*+ append */ INTO order_t
--SELECT level order_no ,
--       mod(level,500) cust_no,
--	   TO_CHAR(sysdate - mod(level,30)) orderdd,
--	   'MAC'||TO_CHAR(LEVEL,'000000') product_nm
--FROM dual 
--CONNECT BY LEVEL<=1000000;
--commit;


--������ �Է� ����
--SELECT COUNT(*) 
--FROM order_t;


--col table_name for a20
--SELECT table_name,
--       num_rows,
--	   blocks,
--	   avg_row_len,
--	   sample_size
--FROM user_tables
--WHERE table_name IN ('ORDER_T','CUST_T');

--������� ������
--TABLE_NAME             NUM_ROWS     BLOCKS AVG_ROW_LEN SAMPLE_SIZE
---------------------- ---------- ---------- ----------- -----------
--CUST_T
--ORDER_T                 



--������� ����
--ANALYZE TABLE order_t COMPUTE STATISTICS;
--ANALYZE TABLE cust_t COMPUTE STATISTICS;
--
--col table_name for a20
--SELECT table_name,
--       num_rows,
--	   blocks,
--	   avg_row_len,
--	   sample_size
--FROM user_tables
--WHERE table_name IN ('ORDER_T','CUST_T');


--TABLE_NAME             NUM_ROWS     BLOCKS AVG_ROW_LEN SAMPLE_SIZE
---------------------- ---------- ---------- ----------- -----------
--CUST_T                     1000          5          18        1000
--ORDER_T                 1000000       5033          34     1000000
--
--��   ��: 00:00:00.02

--2.�ֹ����̺� �ε��� ����:ORDER_T ���̺��� cust_no�� �ε��� ����
--CREATE INDEX IDX_ORDER_T_01 
--ON ORDER_T (cust_no);

--exists
--SELECT COUNT(*)
--FROM cust_t t1
--WHERE EXISTS ( SELECT 1
--               FROM order_t t2
--			   WHERE t1.cust_no = t2.cust_no)
--;

--  COUNT(*)
------------
--       499
--
--��   ��: 00:00:00.12

--�����ȹ

--PLAN_TABLE_OUTPUT
--------------------------------------------------------------------------------------------------------------------------------------------------------
--Plan hash value: 1679909791
--
-------------------------------------------------------------------------------------------
--| Id  | Operation              | Name           | Rows  | Bytes | Cost (%CPU)| Time     |
-------------------------------------------------------------------------------------------
--|   0 | SELECT STATEMENT       |                |     1 |     6 |   581   (4)| 00:00:01 |
--|   1 |  SORT AGGREGATE        |                |     1 |     6 |            |          |
--|*  2 |   HASH JOIN SEMI       |                |   500 |  3000 |   581   (4)| 00:00:01 |
--|   3 |    TABLE ACCESS FULL   | CUST_T         |  1000 |  3000 |     3   (0)| 00:00:01 |
--|   4 |    INDEX FAST FULL SCAN| IDX_ORDER_T_01 |  1000K|  2929K|   570   (2)| 00:00:01 |
-------------------------------------------------------------------------------------------


----------------------------------------------------------
--IN

--���� �ε��� ����:ORDER_T �ε��� IDX_ORDER_T_01
--DROP INDEX IDX_ORDER_T_01;

--CUST_T���̺��� CUST_NO �ε��� ����
--CREATE INDEX IDX_CUST_T_01 
--ON  cust_t (cust_no ASC);

--leading: join�� �Ҷ� ���� �о� ���� ���̺��� ����
--use_nl: join�� nested loop join�� ���� �Ͻÿ�.
--SELECT /*+ leading(order_t) use_nl(order_t cust_t) */ 
--      COUNT(*)
--FROM cust_t 
--WHERE cust_no IN (SELECT cust_no FROM order_t);

--  COUNT(*)
------------
--       499


--�����ȹ

--PLAN_TABLE_OUTPUT
--------------------------------------------------------------------------------------------------------------------------------------------------------
--Plan hash value: 1465242419
--
------------------------------------------------------------------------------------------
--| Id  | Operation              | Name          | Rows  | Bytes | Cost (%CPU)| Time     |
------------------------------------------------------------------------------------------
--|   0 | SELECT STATEMENT       |               |     1 |     6 |  4516   (3)| 00:00:01 |
--|   1 |  SORT AGGREGATE        |               |     1 |     6 |            |          |
--|   2 |   NESTED LOOPS         |               |   500 |  3000 |  4516   (3)| 00:00:01 |
--|   3 |    SORT UNIQUE         |               |  1000K|  2929K|  1381   (2)| 00:00:01 |
--|   4 |     TABLE ACCESS FULL  | ORDER_T       |  1000K|  2929K|  1381   (2)| 00:00:01 |
--|*  5 |    INDEX FAST FULL SCAN| IDX_CUST_T_01 |     1 |     3 |     1   (0)| 00:00:01 |
------------------------------------------------------------------------------------------













