--CREATE OR REPLACE TRIGGER t_order3 
--  --t_order INSERT전에 수행하시오.
--  BEFORE INSERT ON t_order
--   FOR EACH ROW
--   WHEN( NEW.ord_code ='C500')
--  
--  BEGIN
--		IF( TO_CHAR(SYSDATE,'HH24:MI') NOT BETWEEN '16:30' AND '16:33' ) THEN
--			RAISE_APPLICATION_ERROR(-20300,'C500제품에 입력 허용시간 아닙니다.');
--		END IF;
--  END;
--/   

--INSERT INTO t_order VALUES (3,'C500',SYSDATE);
--1 개의 행이 만들어졌습니다.

---INSERT INTO t_order VALUES (5,'C500',SYSDATE);
---
---SELECT TO_CHAR(SYSDATE,'HH24:MI')
---FROM dual;