--조건을 먼저 확인 후 문장을 수행함

--While  조건  LOOP
--   PL/SQL 문장 
--   PL/SQL 문장 
--END LOOP ; 

DECLARE
	no01 NUMBER :=0;

BEGIN
	WHILE (no01 <21) LOOP
		DBMS_OUTPUT.PUT_LINE('no01='|| no01);
	    no01 := no01 +1;
	END LOOP;

END;
/