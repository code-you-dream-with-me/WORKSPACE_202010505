--리터럴 안에 작은 따옴표를 사용:''
--SELECT dname
--     ,'it''s  deptno: '
--	 ,deptno "DNAME AND DEPTNO"
--FROM dept
--;

SELECT dname
     ,q'[it's  deptno]'
	 ,deptno "DNAME AND DEPTNO"
FROM dept
;

--DNAME                        Q'[IT'SDEPTNO]'          DNAME AND DEPTNO
------------------------------ ------------------------ ----------------
--ACCOUNTING                   it's  deptno                           10
--RESEARCH                     it's  deptno                           20
--SALES                        it's  deptno                           30
--OPERATIONS                   it's  deptno                           40