--explain plan for
--SELECT t1.name,
--       t1.position,
--       TO_CHAR(t1.pay,'$999,999,999,999') "SALARY"
--FROM emp2 t1
--WHERE pay >ANY (SELECT pay
--                FROM emp2 
--                WHERE  position='Section head'
--);
--
--col plan_table_output format a150
--SELECT * FROM table(dbms_xplan.display);

--PLAN_TABLE_OUTPUT
--------------------------------------------------------------------------------------------------------------------------------------------------------
--Plan hash value: 76420084
--
------------------------------------------------------------------------------
--| Id  | Operation           | Name | Rows  | Bytes | Cost (%CPU)| Time     |
------------------------------------------------------------------------------
--|   0 | SELECT STATEMENT    |      |    18 |   648 |     8  (25)| 00:00:01 |
--|   1 |  MERGE JOIN SEMI    |      |    18 |   648 |     8  (25)| 00:00:01 |
--|   2 |   SORT JOIN         |      |    20 |   500 |     4  (25)| 00:00:01 |
--|   3 |    TABLE ACCESS FULL| EMP2 |    20 |   500 |     3   (0)| 00:00:01 |
--|*  4 |   SORT UNIQUE       |      |     4 |    44 |     4  (25)| 00:00:01 |
--|*  5 |    TABLE ACCESS FULL| EMP2 |     4 |    44 |     3   (0)| 00:00:01 |
------------------------------------------------------------------------------
--
--Predicate Information (identified by operation id):
-----------------------------------------------------
--
--   4 - access(INTERNAL_FUNCTION("PAY")>INTERNAL_FUNCTION("PAY"))
--       filter(INTERNAL_FUNCTION("PAY")>INTERNAL_FUNCTION("PAY"))
--   5 - filter("POSITION"='Section head')
--
--19 행이 선택되었습니다.

explain plan for
SELECT t1.name,
       t1.position,
       TO_CHAR(t1.pay,'$999,999,999,999') "SALARY"
FROM emp2 t1
WHERE pay >    (SELECT MIN(pay)
                FROM emp2 
                WHERE  position='Section head'
);

col plan_table_output format a150
SELECT * FROM table(dbms_xplan.display);

PLAN_TABLE_OUTPUT
------------------------------------------------------------------------------------------------------------------------------------------------------
Plan hash value: 2078153637

----------------------------------------------------------------------------
| Id  | Operation           | Name | Rows  | Bytes | Cost (%CPU)| Time     |
----------------------------------------------------------------------------
|   0 | SELECT STATEMENT    |      |     1 |    25 |     6   (0)| 00:00:01 |
|*  1 |  TABLE ACCESS FULL  | EMP2 |     1 |    25 |     3   (0)| 00:00:01 |
|   2 |   SORT AGGREGATE    |      |     1 |    11 |            |          |
|*  3 |    TABLE ACCESS FULL| EMP2 |     4 |    44 |     3   (0)| 00:00:01 |
----------------------------------------------------------------------------

Predicate Information (identified by operation id):
---------------------------------------------------

   1 - filter("PAY"> (SELECT MIN("PAY") FROM "EMP2" "EMP2" WHERE
              "POSITION"='Section head'))
   3 - filter("POSITION"='Section head')

17 행이 선택되었습니다.