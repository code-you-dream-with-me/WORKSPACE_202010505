--두건 이상의 데이터를 반환 하는 겨우 에러 발생.
--t3, t4테이블 생성
--t4 데이터가 두건 반환 되도록 입력.
--CREATE TABLE t3(
--	no NUMBER,
--	name VARCHAR2(10),
--	deptno NUMBER
--);
--
--
--CREATE TABLE t4(
--	deptno NUMBER,
--	dname VARCHAR2(10)
--);

--INSERT INTO t3 VALUES (1,'AAA',100);
--INSERT INTO t3 VALUES (2,'BBB',200);
--INSERT INTO t3 VALUES (3,'CCC',300);

--INSERT INTO t4 VALUES (100,'DDD');
--INSERT INTO t4 VALUES (100,'EEE');
--INSERT INTO t4 VALUES (200,'FFF');
--INSERT INTO t4 VALUES (300,'GGG');
--
--COMMIT;

--1건이 아닌 다건 데이터가 발생시 오류
--SELECT t3.no,
--       t3.name,
--	   (SELECT dname
--	    FROM t4
--		WHERE t4.deptno = t3.deptno
--		) "dname"
--FROM t3;

--3행에 오류:
--ORA-01427: 단일 행 하위 질의에 2개 이상의 행이 리턴되었습니다.

--t4에 'DDD' 100을 400으로 변경
--SELECT *
--FROM t4
--WHERE dname= 'DDD';

--UPDATE t4
--SET deptno = 400
--WHERE dname= 'DDD';

--commit;

--SELECT t3.no,
--       t3.name,
--	   (SELECT dname
--	    FROM t4
--		WHERE t4.deptno = t3.deptno
--		) "dname"
--FROM t3;
--        NO NAME                           dname
------------ ------------------------------ --------------------
--         1 AAA                            EEE
--         2 BBB                            FFF
--         3 CCC                            GGG

--2개 이상의 컬럼을 조회할 경우에도 오류 발생

SELECT t3.no,
       t3.name,
	   (SELECT dname,deptno
	    FROM t4
		WHERE t4.deptno = t3.deptno
		) "dname"
FROM t3;

--3행에 오류:
--ORA-00913: 값의 수가 너무 많습니다.

--스칼라 서브 쿼리는 일반적으로 데이터의 종류나 양이 적은 코드 성격의 테이블에서 적은 수의
--데이터를 가져와야 할 경우 join대신 사용하면 성능이 좋지만 그런 상황이 아닐 경우는
--join보다 성능이 더 저하될 수 있다.

















