--SELECT empno
--      ,ename
--	  ,job
--	  ,sal
--FROM emp
--WHERE deptno =10;

--SELECT LEVEL
--FROM dual 
--CONNECT BY level <=3;

--12:02:19 SCOTT>@S02_CATESIAN.sql
--
--     EMPNO ENAME                JOB                       SAL
------------ -------------------- ------------------ ----------
--      7782 CLARK                MANAGER                  2450
--      7839 KING                 PRESIDENT                5000
--      7934 MILLER               CLERK                    1300
--      1000 Tiger                                         3600
--      2000 Cat                                           3000
--
--12:03:03 SCOTT>@S02_CATESIAN.sql
--
--     LEVEL
------------
--         1
--         2
--         3
--조인 조건 누락해서 카티션 곱 발생!
SELECT *
FROM (  SELECT empno
			  ,ename
			  ,job
			  ,sal
		FROM emp
		WHERE deptno =10),
	(   SELECT LEVEL
		FROM dual 
		CONNECT BY level <=3);

--     EMPNO ENAME                JOB                       SAL      LEVEL
------------ -------------------- ------------------ ---------- ----------
--      7782 CLARK                MANAGER                  2450          1
--      7839 KING                 PRESIDENT                5000          1
--      7934 MILLER               CLERK                    1300          1
--      1000 Tiger                                         3600          1
--      2000 Cat                                           3000          1
--      7782 CLARK                MANAGER                  2450          2
--      7839 KING                 PRESIDENT                5000          2
--      7934 MILLER               CLERK                    1300          2
--      1000 Tiger                                         3600          2
--      2000 Cat                                           3000          2
--      7782 CLARK                MANAGER                  2450          3
--      7839 KING                 PRESIDENT                5000          3
--      7934 MILLER               CLERK                    1300          3
--      1000 Tiger                                         3600          3
--      2000 Cat                                           3000          3
--
--15 행이 선택되었습니다.


