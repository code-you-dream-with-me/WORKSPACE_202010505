--Catesian Product(카티션 곱) : join 조건이 없는 경우
--1. 데이터 복제해서 원본 테이블을 반복해서 읽는 것을 피하기위해
--2. 실수로 조인 조건 누락.(   table1(1000건)*table2(1000건)  ) = 1000000


--테스트용 테이블 CAT_A,CAT_B,CAT_C 생성
--데이터 각 2건씩 입력

--DROP TABLE CAT_A;
--
--CREATE TABLE CAT_A (
--   no NUMBER,
--   name VARCHAR2(1)
--);
--
--CREATE TABLE CAT_B (
--   no NUMBER,
--   name VARCHAR2(1)
--);
--
--
--CREATE TABLE CAT_C (
--   no NUMBER,
--   name VARCHAR2(1)
--);

--INSERT INTO CAT_A (no,name) VALUES(1,'A');	
--INSERT INTO CAT_A (no,name) VALUES(2,'B');	
--
--
--INSERT INTO CAT_B (no,name) VALUES(1,'C');	
--INSERT INTO CAT_B (no,name) VALUES(2,'D');	
--
--
--INSERT INTO CAT_C  VALUES(1,'E');	
--INSERT INTO CAT_C  VALUES(2,'F');	
--
--COMMIT;

--SELECT * 
--FROM cat_a;
--
--SELECT * 
--FROM cat_b;
--
--SELECT * 
--FROM cat_c;

--SELECT t1.no
--      ,t1.name
--      ,t2.name
--FROM cat_a t1, cat_b t2
----WHERE t1.no = t2.no --조인 조건
--;
--        NO NA NA
------------ -- --
--         1 A  C
--         2 B  D

--SELECT t1.no
--      ,t1.name
--      ,t2.name
--FROM cat_a t1, cat_b t2
--;
--        NO NA NA
------------ -- --
--         1 A  C
--         1 A  D
--         2 B  C
--         2 B  D

--cat_a,cat_b,cat_c 연결
--SELECT t1.no
--      ,t1.name
--	  ,t2.name
--	  ,t3.name
--FROM  cat_a t1,cat_b t2,cat_c t3
--WHERE t1.no = t2.no
--AND   t1.no = t3.no 
--;
--        NO NA NA NA
------------ -- -- --
--         1 A  C  E
--         2 B  D  F


SELECT t1.no
      ,t1.name
	  ,t2.name
	  ,t3.name
FROM  cat_a t1,cat_b t2,cat_c t3
WHERE t1.no = t2.no
--AND   t1.no = t3.no 
;
--        NO NA NA NA
------------ -- -- --
--         1 A  C  E
--         1 A  C  F
--         2 B  D  E
--         2 B  D  F




ㅉ






