--ANSI
SELECT t1.empno
      ,t1.ename
	  ,t1.deptno
	  ,t2.dname
FROM emp t1 INNER JOIN dept t2 
ON t1.deptno = t2.deptno
;
--     EMPNO ENAME                    DEPTNO DNAME
------------ -------------------- ---------- ----------------------------
--      7782 CLARK                        10 ACCOUNTING
--      1000 Tiger                        10 ACCOUNTING
--      7934 MILLER                       10 ACCOUNTING
--      7839 KING                         10 ACCOUNTING
--      2000 Cat                          10 ACCOUNTING
--      7369 SMITH                        20 RESEARCH
--      7902 FORD                         20 RESEARCH
--      7566 JONES                        20 RESEARCH
--      7521 WARD                         30 SALES
--      7499 ALLEN                        30 SALES
--      7844 TURNER                       30 SALES
--      7900 JAMES                        30 SALES
--      7698 BLAKE                        30 SALES
--      7654 MARTIN                       30 SALES
--
--14 행이 선택되었습니다.