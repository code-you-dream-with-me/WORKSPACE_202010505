--학생의 이름,학과 이름,학생의 지도교수이름
COL "STU" FOR A25
COL "PROF" FOR A25
COL "DEPT_NAME" FOR A35  
SELECT t1.name "STU"
      ,t2.name "PROF"
      ,t3.dname "DEPT_NAME"	  
FROM student t1, professor t2, department t3
WHERE t1.profno = t2.profno
AND   t1.deptno1= t3.deptno
;
--STU                       PROF                      DEPT_NAME
--------------------------- ------------------------- -----------------------------------
--James Seo                 Audie Murphy              Computer Engineering
--Richard Dreyfus           Angela Bassett            Computer Engineering
--Billy Crystal             Angela Bassett            Computer Engineering
--Rene Russo                Winona Ryder              Multimedia Engineering
--Tim Robbins               Winona Ryder              Multimedia Engineering
--Nicholas Cage             Michelle Pfeiffer         Multimedia Engineering
--Sandra Bullock            Julia Roberts             Software Engineering
--Demi Moore                Meryl Streep              Electronic Engineering
--Macaulay Culkin           Meryl Streep              Electronic Engineering
--Wesley Snipes             Susan Sarandon            Electronic Engineering
--Steve Martin              Nicole Kidman             Electronic Engineering
--Danny Glover              Nicole Kidman             Mechanical Engineering
--Micheal Keaton            Nicole Kidman             Mechanical Engineering
--Daniel Day-Lewis          Jodie Foster              Library and Information science
--Bill Murray               Jodie Foster              Library and Information science
--
--15 행이 선택되었습니다.

		
