col gname for a20
col point for 99999999
col "GIFT_NAME" for a20
SELECT t1.gname
      ,t1.point
	  ,t2.gname "GIFT_NAME"
FROM customer t1 JOIN gift t2
--ON t1.point BETWEEN t2.g_start AND t2.g_end
ON  t1.point >= t2.g_start 
AND t1.point <= t2.g_end
;