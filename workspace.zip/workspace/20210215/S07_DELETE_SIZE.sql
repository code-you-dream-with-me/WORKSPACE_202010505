--11:08:00 SCOTT>conn / as sysdba
--1. 테스트 테이블 생성한다.								
--1.1. 대량의 데이터 입력 								
--								
--2. 테이블의 크기 측정 								
--3. 데이터 삭제 후 테이블의 크기 확인. 		
--C:\app\sist\product\18.0.0\oradata\XE\USERS01.DBF

--USERS01.DBF 자동으로 증가 하도록 변경.
--ALTER DATABASE DATAFILE	'C:\app\sist\product\18.0.0\oradata\XE\USERS01.DBF'	AUTOEXTEND on;

--1. 테스트 테이블 생성한다.
--CREATE TABLE scott.reorg(
--	no NUMBER,
--	name VARCHAR2(20 BYTE),
--	addr VARCHAR2(20 BYTE)
--);	

--1.1. 대량의 데이터 입력 
--BEGIN
--	FOR i  IN 1..500000 LOOP
--		INSERT INTO scott.reorg VALUES(i,DBMS_RANDOM.STRING('U',19),DBMS_RANDOM.STRING('U',19));
--	END LOOP;
--	COMMIT;
--END;
--/		

	
--DBMS_RANDOM.STRING
--- 랜덤한 문자열을 생성한다.
--- Syntax : DBMS_RANDOM.STRING opt IN CHAR, len IN NUMBER)
--- opt (옵션)은 아래와 같다.
--'u', 'U' : 대문자
--'l', 'L' : 소문자
--'a', 'A' : 대소문자 구분없는 영문자
--'x', 'X' : 영문자와 숫자 혼합
--'p', 'P' : 문자 혼합

--2. 테이블의 크기 측정 
--2.1.dba_segments
--SELECT bytes/(1024*1024) "MB"
--FROM dba_segments
--WHERE owner = 'SCOTT'
--AND segment_name= 'REORG';


--2.1.dba_tables
--static dictionary 수동으로 정보 update
--ANALYZE TABLE scott.reorg COMPUTE STATISTICS;
--
--
--SELECT table_name,
--       num_rows,
--	   blocks
--FROM dba_tables
--WHERE owner = 'SCOTT'
--AND table_name= 'REORG';


--3. 데이터 삭제 후 테이블의 크기 확인. 	
--DELETE FROM scott.reorg;
--COMMIT;
--SELECT COUNT(*) FROM scott.reorg;


--ANALYZE TABLE scott.reorg COMPUTE STATISTICS;
--
--SELECT bytes/(1024*1024) "MB"
--FROM dba_segments
--WHERE owner = 'SCOTT'
--AND segment_name= 'REORG';





--실제 사용하고 있는 BLOCK조회
--SELECT COUNT( DISTINCT DBMS_ROWID.ROWID_BLOCK_NUMBER(rowid) 
--         || DBMS_ROWID.ROWID_RELATIVE_FNO(rowid)) "REAL_USED"
--FROM scott.reorg
--;

--reorg(재구성) 수행.

--tablespace_name 확인
--SELECT table_name,
--       tablespace_name
--FROM dba_tables
--WHERE owner = 'SCOTT'
--AND table_name= 'REORG';
--
--TABLE_NAME  TABLESPACE_NAME
------------  ----------------
--REORG       USERS
--

--reorg(재구성) 수행.
ALTER TABLE scott.reorg MOVE TABLESPACE USERS;

SELECT bytes 
FROM dba_segments
WHERE owner = 'SCOTT'
AND segment_name= 'REORG';

--     BYTES
------------
--     65536
























