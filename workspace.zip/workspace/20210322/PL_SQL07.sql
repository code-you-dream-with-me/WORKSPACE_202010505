--SELECT * FROM pl_test;
--
--        NO NAME
------------ --------------------
--         1 AAA
--         2 BBB

--NO=1인 데이터 DELETE

--DECLARE
--
--BEGIN
--	DELETE FROM pl_test
--	WHERE no=1;
--END;
--/

--SELECT * FROM pl_test;
--10:08:04 HR>@PL_SQL07.sql
--
--        NO NAME
------------ --------------------
--         2 BBB

COMMIT;