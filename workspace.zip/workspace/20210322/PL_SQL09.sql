--PL/SQL 식별자: pl/sql객체에서 부여되는 이름
--"" 사용

--권장하지 않음.
--1.식별자의 대소문 구분이 필요한 경우
--ex) "eClass"
--2.공백문자가 포함될 경우
--ex) "a col"
--3.예약어인 경우 
--ex) "table"

--리터럴: 변수에 할당되는 값
--1.문자 리터럴: CHAR, VARCHAR2 ex) abcd
--2.숫자 리터럴: 정수, 또는 실수 ex)1234,1.234
--3.부울 리터럴: TRUE,FALSE,NULL

--주석
--한줄: --
--여러줄 주석: /* */

--중첩된 PL/SQL 블럭

--DECLARE
--	
--BEGIN
--	DECLARE
--	
--	BEGIN
--		
--	END;
--END;
--/

DECLARE
	v_first VARCHAR2(10) :='FIRST';
BEGIN
	DECLARE
			v_second VARCHAR2(10) :='SECOND';
	BEGIN
		DBMS_OUTPUT.PUT_LINE(v_first);
		DBMS_OUTPUT.PUT_LINE(v_second);
	END;
		DBMS_OUTPUT.PUT_LINE(v_first);
		--DBMS_OUTPUT.PUT_LINE(v_second);
END;
/












