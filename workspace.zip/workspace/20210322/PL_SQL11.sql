--ROWTYPE 참조변수로 데이터 출력 
DECLARE
	v_row employees3%ROWTYPE;
BEGIN
	SELECT employee_id,first_name,salary
	       INTO  v_row
	FROM employees3
	WHERE employee_id = 180;
    
	DBMS_OUTPUT.PUT_LINE(v_row.employee_id ||'----'|| v_row.first_name  ||'----'|| v_row.salary);
END;
/
--11:19:07 HR>@PL_SQL11.sql
--180----윈스턴----3200