--NON-UNIQUE INDEX																		
--																		
--	중복된 데이터가 있는 컬럼일 경우 UNIQUE 인덱스를 사용할수 없으므로																	
--	 이럴 경우 NON UNIQUE INDEX사용.																	
--																		
--문법																		
--	CREATE  INDEX 인덱명																	
--	ON	테이블명 (  컬럼명1 ASC|DESC, 컬럼명2 ASC|DESC)																
--  CREATE UNIQUE INDEX "SCOTT"."IDX_DEPT2_DNAME" ON "SCOTT"."DEPT2" ("DNAME") 
--  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
--  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
--  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
--  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
--  TABLESPACE "USERS" ;


CREATE INDEX idx_dept2_area
ON dept2 ( area desc);