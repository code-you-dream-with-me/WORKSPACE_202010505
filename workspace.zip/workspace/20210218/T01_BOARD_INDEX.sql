--explain plan for
--
--COL seq FOR 999999
--COL title FOR A20
--COL read_cnt FOR 999999
--COL div FOR A5
--COL mod_id FOR A20
--COL mod_dt FOR A20
--SELECT /*+ INDEX_DESC(board_b PK_BOARD_B) */
--	   seq, 
--       title, 
--	   read_cnt, 
--	   div, 
--	   mod_id, 
--	   mod_dt 
--FROM board_b
--WHERE ROWNUM <=100;
--
--
----������,����,����,�����,SEQ
--
--
--����,������
--CREATE INDEX IDX_BOARD_B_COMP
--ON BOARD_B ( title ASC, mod_dt DESC);
--explain plan for
--
--SELECT seq, 
--       title, 
--	   read_cnt, 
--	   div, 
--	   mod_id, 
--	   mod_dt 
--FROM board_b 
--WHERE title > '0'
--AND ROWNUM <=10;
--
--col plan_table_output format a150;
--select * from table(dbms_xplan.display);
--PLAN_TABLE_OUTPUT
--------------------------------------------------------------------------------------------------------------------------------------------------------
--Plan hash value: 2835328148
--
-----------------------------------------------------------------------------------------------------------
--| Id  | Operation                            | Name             | Rows  | Bytes | Cost (%CPU)| Time     |
-----------------------------------------------------------------------------------------------------------
--|   0 | SELECT STATEMENT                     |                  |    10 |   390 |     4   (0)| 00:00:01 |
--|*  1 |  COUNT STOPKEY                       |                  |       |       |            |          |
--|   2 |   TABLE ACCESS BY INDEX ROWID BATCHED| BOARD_B          |    10 |   390 |     4   (0)| 00:00:01 |
--|*  3 |    INDEX RANGE SCAN                  | IDX_BOARD_B_COMP |       |       |     3   (0)| 00:00:01 |
-----------------------------------------------------------------------------------------------------------
--
--Predicate Information (identified by operation id):
-----------------------------------------------------
--
--   1 - filter(ROWNUM<=10)
--   3 - access("TITLE" LIKE '����%')
--       filter("TITLE" LIKE '����%')
--
--17 ���� ���õǾ����ϴ�.

--SELECT seq, 
--       title, 
--	   read_cnt, 
--	   div, 
--	   mod_id, 
--	   TO_CHAR(mod_dt,'yyyy-mm-dd HH24:MI:SS')  mod_dt
--FROM board_b 
--WHERE title>'0'
--AND title like '1%'
--AND ROWNUM <=10;

--PLAN_TABLE_OUTPUT
--------------------------------------------------------------------------------------------------------------------------------------------------------
--Plan hash value: 2835328148
--
-----------------------------------------------------------------------------------------------------------
--| Id  | Operation                            | Name             | Rows  | Bytes | Cost (%CPU)| Time     |
-----------------------------------------------------------------------------------------------------------
--|   0 | SELECT STATEMENT                     |                  |    10 |   390 |     6   (0)| 00:00:01 |
--|*  1 |  COUNT STOPKEY                       |                  |       |       |            |          |
--|   2 |   TABLE ACCESS BY INDEX ROWID BATCHED| BOARD_B          |    11 |   429 |     6   (0)| 00:00:01 |
--|*  3 |    INDEX RANGE SCAN                  | IDX_BOARD_B_COMP |       |       |     5   (0)| 00:00:01 |
-----------------------------------------------------------------------------------------------------------
--
--Predicate Information (identified by operation id):
-----------------------------------------------------
--
--   1 - filter(ROWNUM<=10)
--   3 - access("TITLE">'0' AND SYS_OP_DESCEND("MOD_DT")<HEXTORAW('8786FDEDFEF8FEFAFF'))
--       filter(SYS_OP_UNDESCEND(SYS_OP_DESCEND("MOD_DT"))>TO_DATE(' 2021-02-18 00:00:00',
--              'syyyy-mm-dd hh24:mi:ss'))
--
--18 ���� ���õǾ����ϴ�.

SELECT tt1.*
FROM (
	SELECT rownum rnum, t1.*
	FROM(
		SELECT *
		FROM board_b 
		WHERE title>'0'
		AND ROWNUM <=10
	)t1
	WHERE rnum >=1
)tt1

--       seq, 
--       title, 
--	   read_cnt, 
--	   div, 
--	   mod_id, 
--	   CASE WHEN TO_CHAR(mod_dt,'yyyy-mm-dd')=TO_CHAR(SYSDATE,'yyyy-mm-dd')  THEN TO_CHAR(mod_dt,'HH24:MI')
--	        ELSE TO_CHAR(mod_dt,'yyyy-mm-dd')
--	   END mod_dt




