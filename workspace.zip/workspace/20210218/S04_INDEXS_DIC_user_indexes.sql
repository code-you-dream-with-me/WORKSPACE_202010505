--�ε��� �����ϱ�: DICTIONARY												
												
--	user:user_indexes,user_ind_columns									
--	DBA:dba_indexes,dba_ind_columns	

SELECT t1.table_name,
       t1.index_name
FROM user_indexes t1
WHERE t1.table_name = 'DEPT2'
;
