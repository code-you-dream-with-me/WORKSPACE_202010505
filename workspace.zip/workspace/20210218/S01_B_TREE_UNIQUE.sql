--UNIQUE INDEX																			
--																			
--	KEY 값에 중복되는 데이터가 없다.																		
--	(UNIQUE인덱스는 성능은 아주 좋은데, 혹시 현재,미래에 중복된 값이 입력될 가능성이 있는 컬럼에는 사용할수 없다.)																		
--																			
--문법																			
--	CREATE  UNIQUE INDEX 인덱명																		
--	ON	테이블명 (  컬럼명1 ASC|DESC, 컬럼명2 ASC|DESC)		

--인덱명 : IX_테이블_컬럼,IDX															
--SELECT dname
--FROM dept2
--ORDER BY dname asc;

--CREATE UNIQUE INDEX idx_dept2_dname
--ON dept2 ( dname ASC);
--
--인덱스가 생성되었습니다.

--INSERT INTO dept2 VALUES (9100,'temp_02',1006,'Seoul Branch');
--commit;

--INSERT INTO dept2 VALUES (9101,'temp_02',1006,'Seoul Branch');1행에 오류:
--ORA-00001: 무결성 제약 조건(SCOTT.IDX_DEPT2_DNAME)에 위배됩 니다