�̸�                 ��? ����             
------------------ -- -------------- 
index_name            VARCHAR2(128)  
table_name            VARCHAR2(128)  
column_name           VARCHAR2(4000) 
column_position       NUMBER         
column_length         NUMBER         
char_length           NUMBER         
descend               VARCHAR2(4)    
collated_column_id    NUMBER         
