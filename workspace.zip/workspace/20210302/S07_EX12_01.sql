--exam01)emp2,dept2 ���̺��� ����Ͽ� �Ʒ��� ���� ������� �μ��� ������ ���ļ� ����ϵ�
--�μ��� ���޺��� ������ ������ ����Ͽ� ����ϼ���.�� ������ ���� ������� ������ Team Worker�� ����ϼ���.
col "Name and Position" for a150
SELECT LPAD(t1.name||'-'||t2.dname||'-'||NVL(t1.position,'Team Worker'),LEVEL*27,'-') "Name and Position"       
FROM emp2 t1,dept2 t2
WHERE t1.deptno = t2.dcode
START WITH t1.empno =19900101
CONNECT BY PRIOR t1.empno = t1.pempno
ORDER SIBLINGS BY t1.name
;


--Name and Position
--------------------------------------------------------------------------------------------------------------------------------------------------------
--Kurt Russell-President-Boss
-------AL Pacino-Management Support Team-Department head
------------------------------------------Gene Hackman-General affairs-Section head
-------------------Tommy Lee Jones-Financial Management Team-Deputy department head
-------------------------------Woody Harrelson-Management Support Team-Section head
--------Kevin Bacon-Engineering division-Department head
-------------------------------------------Hugh Grant-H/W Support Team-Section head
--------------------------------------------------------------------Harrison Ford-H/W Support Team-Team Worker
---------------------------------Keanu Reeves-S/W Support Team-Deputy Section chief
-------------------------------------------------------------------Clint Eastwood-S/W Support Team-Team Worker
----------Val Kilmer-Business Department-Department head
--------------------------------Chris O'Donnell-Business Planning Team-Section head
---------------------------------------------------------------------Denzel Washington-Sales2 Team-Team Worker
------------------------------------------------------------------------Jack Nicholson-Sales1 Team-Team Worker
--------------------------------------------------------------------------JohnTravolta-Sales1 Team-Team Worker
-------------------------------------------------------------------------Kevin Costner-Sales4 Team-Team Worker
--------------------------------------------------------------------------Richard Gere-Sales3 Team-Team Worker
------------------------------------------------------------------------Robert De Niro-Sales2 Team-Team Worker
--------------------------------------------------------------------------Sly Stallone-Sales3 Team-Team Worker
----------------------------------------------------------------------------Tom Cruise-Sales4 Team-Team Worker
--
--20 ���� ���õǾ����ϴ�.