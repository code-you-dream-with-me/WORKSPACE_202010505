col ename for a20
--SELECT ename
--FROM emp;

SELECT level,
       LPAD(ename,LEVEL*4,'*') "ENAME"
FROM emp
CONNECT BY PRIOR empno = mgr
START WITH empno = 7839;

