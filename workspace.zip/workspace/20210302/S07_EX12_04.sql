--emp2 아래와 같이 사원의 이름과 상상의 이름이 함께 나오도록 계층형 쿼리를 작성하세요.
--계층형 sql
SELECT t1.name,
       PRIOR t1.name MGR_NAME       
FROM emp2 t1
START WITH t1.pempno IS NULL
CONNECT BY PRIOR t1.empno = t1.pempno;

--outer join
--SELECT t1.name,
--       t2.name MGR_NAME
--FROM emp2 t1, emp2 t2
--WHERE t1.pempno = t2.empno(+)