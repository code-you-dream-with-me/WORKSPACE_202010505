--ex)student과 professor조인 하여 출력 하세요.
--단 지도 학생이 결정되지 않는 교수들, 지도 교수가 결정되지 않는 학생들 이름도 같이 출력 하세요.
--ORACLE

col "STU_NAME" for a20
col "PROF_NAME" for a20

SELECT t1.name "STU_NAME"
      ,t2.name "PROF_NAME"
FROM student t1, professor t2
WHERE t1.profno = t2.profno(+)
UNION
SELECT t1.name "STU_NAME"
      ,t2.name "PROF_NAME"
FROM student t1, professor t2
WHERE t1.profno(+) = t2.profno;
--STU_NAME             PROF_NAME
---------------------- --------------------
--Anthony Hopkins
--Bill Murray          Jodie Foster
--Billy Crystal        Angela Bassett
--Charlie Sheen
--Christian Slater
--Daniel Day-Lewis     Jodie Foster
--Danny Devito
--Danny Glover         Nicole Kidman
--Demi Moore           Meryl Streep
--James Seo            Audie Murphy
--Macaulay Culkin      Meryl Streep
--Micheal Keaton       Nicole Kidman
--Nicholas Cage        Michelle Pfeiffer
--Rene Russo           Winona Ryder
--Richard Dreyfus      Angela Bassett
--Sandra Bullock       Julia Roberts
--Sean Connery
--Steve Martin         Nicole Kidman
--Tim Robbins          Winona Ryder
--Wesley Snipes        Susan Sarandon
--                     Andie Macdowell
--                     Emma Thompson
--                     Holly Hunter
--                     Jessica Lange
--                     Meg Ryan
--                     Sharon Stone
--                     Whoopi Goldberg
--
--27 행이 선택되었습니다.