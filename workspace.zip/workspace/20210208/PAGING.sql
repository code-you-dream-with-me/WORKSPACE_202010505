--PAGING : 
--1. �¶��� Ʈ����� ó��(Online transaction processing, OLTP) ���� ��ȸ�� ���� ���.

-- SELECT  TT1.*
-- FROM(
--     SELECT rownum rnum,T1.*
--     FROM (
--         SELECT *
--         FROM board
--         --�˻�����
--         ORDER BY mod_dt DESC
--     ) T1
--     WHERE rownum <= 10
-- ) TT1
-- WHERE rnum >=  1;
-- --WHERE rnum BETWEEN  1  AND 10;
--SELECT TT1.*
--FROM (
--		SELECT rownum rnum,T1.name
--		FROM (
--				SELECT *
--				FROM emp2
--				--�˻�����
--				ORDER BY birthday DESC
--		)T1
----	  WHERE rownum <=20
--) TT1
----WHERE rnum >=11
--WHERE rnum BETWEEN &PAGE_SIZE*(&PAGE_NUM-1)+1 AND &PAGE_SIZE*(&PAGE_NUM-1)+&PAGE_SIZE
--;

--1,11,21,31 :  &PAGE_SIZE*(&PAGE_NUM-1)+1
--10,20,30,40 : &PAGE_SIZE*(&PAGE_NUM-1)+&PAGE_SIZE
--
--PAGE_SIZE
--PAGE_NUM

--      RNUM NAME
------------ --------------------
--         1 Jack Nicholson
--         2 Denzel Washington
--         3 Richard Gere
--         4 Kevin Costner
--         5 Clint Eastwood
--         6 Harrison Ford
--         7 Tom Cruise
--         8 Sly Stallone
--         9 Robert De Niro
--        10 JohnTravolta
--
--      RNUM NAME
------------ --------------------
--        11 Val Kilmer
--        12 Tommy Lee Jones
--        13 Woody Harrelson
--        14 Gene Hackman
--        15 AL Pacino
--        16 Chris O'Donnell
--        17 Hugh Grant
--        18 Kevin Bacon
--        19 Keanu Reeves
--        20 Kurt Russell

--ANSI PAGING : ���+��ü�Ǽ�
SELECT A.*,B.CNT
FROM (
		SELECT TT1.*
		FROM (
				SELECT rownum rnum,T1.name
				FROM (
						SELECT *
						FROM emp2
						--�˻�����
						ORDER BY birthday DESC
				)T1
		) TT1
		WHERE rnum BETWEEN &PAGE_SIZE*(&PAGE_NUM-1)+1 AND &PAGE_SIZE*(&PAGE_NUM-1)+&PAGE_SIZE
)A CROSS JOIN (
--�ѰǼ�
SELECT COUNT(*) CNT
FROM emp2
--�˻�����
)B
;











