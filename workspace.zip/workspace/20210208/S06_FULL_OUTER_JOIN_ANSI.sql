--ex)student과 professor조인 하여 출력 하세요.
--단 지도 학생이 결정되지 않는 교수들, 지도 교수가 결정되지 않는 학생들 이름도 같이 출력 하세요.
--ANSI

col "STU_NAME" for a20
col "PROF_NAME" for a20
SELECT t1.name "STU_NAME"
      ,t2.name "PROF_NAME"
FROM student t1 FULL OUTER JOIN professor t2
ON t1.profno = t2.profno;
--STU_NAME             PROF_NAME
---------------------- --------------------
--James Seo            Audie Murphy
--Rene Russo           Winona Ryder
--Sandra Bullock       Julia Roberts
--Demi Moore           Meryl Streep
--Danny Glover         Nicole Kidman
--Billy Crystal        Angela Bassett
--Nicholas Cage        Michelle Pfeiffer
--Micheal Keaton       Nicole Kidman
--Bill Murray          Jodie Foster
--Macaulay Culkin      Meryl Streep
--Richard Dreyfus      Angela Bassett
--Tim Robbins          Winona Ryder
--Wesley Snipes        Susan Sarandon
--Steve Martin         Nicole Kidman
--Daniel Day-Lewis     Jodie Foster
--Danny Devito
--Sean Connery
--Christian Slater
--Charlie Sheen
--Anthony Hopkins
--                     Holly Hunter
--                     Andie Macdowell
--                     Sharon Stone
--                     Whoopi Goldberg
--                     Meg Ryan
--                     Emma Thompson
--                     Jessica Lange
--
--27 행이 선택되었습니다.