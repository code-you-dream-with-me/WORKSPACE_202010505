--FK를 생성시 OPTION 
--자식테이블의 데이터 추가시, 아버지 FK컬럼에 있는 데이터만 추가 가능
--부모테이블의 데이터 삭제시, 자식테이블의 FK컬럼에 데이터 부터 삭제 되어야 한다.
--1. ON DELETE CASCADE : 부모테이블에 데이터가 지워지면,자식 테이블의 테이터도 함께 지우라.
--2. ON DELETE SET NULL: 부모테이블에 데이터가 지워지면,자식 테이블의 테이터를 NULL로 만든다.

--C_TEST1			Child				
--C_TEST2			Parent	
--DROP TABLE C_TEST1;
--CREATE TABLE C_TEST1(
--	no NUMBER,
--	name VARCHAR2(20),
--	deptno NUMBER
--);

--CREATE TABLE C_TEST2(
--	no NUMBER,
--	name VARCHAR2(20)
--);


--FK 작성시 PARENT테이블의 해당 컬럼은 UNIQUE KEY가 설정되어야 한다.
--ALTER TABLE new_emp2
--ADD CONSTRAINT emp2_name_fk FOREIGN KEY(name)
--REFERENCES emp2(name);

--ALTER TABLE c_test1
--ADD CONSTRAINT c_test1_deptno_fk FOREIGN KEY(deptno)
--REFERENCES c_test2(no);
--
--3행에 오류:
--ORA-02270: 이 열목록에 대해 일치하는 고유 또는 기본 키가 없 습니다.


--c_test2(NO) UNIQUE KEY 생성
--ALTER TABLE c_test2
--ADD CONSTRAINT c_test2_no_fk UNIQUE(no);

--FK생성
--ALTER TABLE c_test1
--ADD CONSTRAINT c_test1_deptno_fk FOREIGN KEY(deptno)
--REFERENCES c_test2(no)
--ON DELETE CASCADE;

--ALTER TABLE c_test1
--DROP CONSTRAINT c_test1_deptno_fk;

--ALTER TABLE c_test1
--ADD CONSTRAINT c_test1_deptno_fk FOREIGN KEY(deptno)
--REFERENCES c_test2(no)
--ON DELETE CASCADE;

--DEVELOPER SCRIPT확인
--  CREATE TABLE "SCOTT"."C_TEST1" 
--   (	"NO" NUMBER, 
--	"NAME" VARCHAR2(20 BYTE), 
--	"DEPTNO" NUMBER, 
--	 CONSTRAINT "C_TEST1_DEPTNO_FK" FOREIGN KEY ("DEPTNO")
--	  REFERENCES "SCOTT"."C_TEST2" ("NO") ON DELETE CASCADE ENABLE
--   ) SEGMENT CREATION DEFERRED 
--  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
-- NOCOMPRESS LOGGING
--  TABLESPACE "USERS" ;

--c_test2 데이터 입력
--INSERT INTO c_test2 VALUES (10,'AAA');					
--INSERT INTO c_test2 VALUES (20,'BBB');					
--INSERT INTO c_test2 VALUES (30,'CCC');					
--COMMIT;



--c_test1 c_test2 no 데이터 기반으로 c_test1.deptno를 입력
--INSERT INTO c_test1(no,name,deptno) VALUES(1,'apple' ,10);		
--INSERT INTO c_test1(no,name,deptno) VALUES(2,'banana',20);		
--INSERT INTO c_test1(no,name,deptno) VALUES(3,'cherry',30);		
--COMMIT;

--parent no 컬럼에 없는 데이터를 입력 하면 오류
--INSERT INTO c_test1(no,name,deptno) VALUES(4,'peach',40);
--1행에 오류:
--ORA-02291: 무결성 제약조건(SCOTT.C_TEST1_DEPTNO_FK)이 위배되었습니다- 부모 키가 없습니다

--SELECT * FROM c_test1;
--부모테이블의 데이터 삭제시, 자식테이블의 FK컬럼에 데이터 부터 삭제 되어야 한다.
--1. ON DELETE CASCADE : 부모테이블에 데이터가 지워지면,자식 테이블의 테이터도 함께 지우라.

--DELETE FROM c_test2 
--WHERE no = 10;

--SELECT * FROM c_test1;











