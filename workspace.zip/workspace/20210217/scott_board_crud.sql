--doInsert():div 10(��������), 20(�����Խ���)
INSERT INTO BOARD (seq,title,contents,div,reg_id,mod_id) 
VALUES (2,'title_2','contents_2','10','eclass','elcass');
--2   ,title_2   ,contents_2   ,'eclass_2','eclass_2'
--102 ,title_102 ,contents_102 ,'eclass_102','eclass_102'
--202
--commit;
--SELECT * FROM BOARD;

--doSelectOne():�ܰ� ��ȸ
sb.append(" SELECT seq,                                            \n");
sb.append("        title,                                          \n");
sb.append("        contents,                                       \n");
sb.append("        read_cnt,                                       \n");
sb.append("        div,                                            \n");
sb.append("        reg_id,                                         \n");
sb.append("        reg_dt,                                         \n");
sb.append("        mod_id,                                         \n");
sb.append("        TO_CHAR(mod_dt,'YYYY-MM-DD HH24:MI:SS') mod_dt  \n");   
sb.append(" FROM board                                             \n");
sb.append(" WHERE seq = 2                                          \n");




--doReadCnt(): READ COUNT����
UPDATE board
SET read_cnt=NVL(read_cnt,0)+1
WHERE seq = 2;

COMMIT;


--doUpdate()
UPDATE board
SET title = :title,
    contents = :contents,
    mod_id = :mod_id,
    mod_dt = sysdate
WHERE seq = 2;

COMMIT;

--doDelete()
DELETE board
WHERE seq = 2;

COMMIT;

--doSelectList()
SELECT a.seq ,a.rnum  ,a.title  ,a.read_cnt	  ,TO_CHAR(a.mod_dt,'YYYY/MM/DD') MOD_DT  ,a.mod_id      ,B.cnt
FROM (
		SELECT TT1.*
		FROM (
				SELECT rownum rnum,T1.*
				FROM (
						SELECT *   
						FROM board
						--WHERE title like '����_1'||'%'
						--WHERE constents like '����_1'||'%'
						ORDER BY mod_dt DESC
				)T1  
		) TT1
		--WHERE rnum BETWEEN 1 AND 10
		WHERE rnum BETWEEN :PAGE_SIZE*(:PAGE_NUM-1)+1 AND :PAGE_SIZE*(:PAGE_NUM-1)+:PAGE_SIZE
)A CROSS JOIN (
--�ѰǼ�
SELECT COUNT(*) CNT   
FROM board
--WHERE title like '����_1'||'%'
--WHERE constents like '����_1'||'%'
)B
;        


