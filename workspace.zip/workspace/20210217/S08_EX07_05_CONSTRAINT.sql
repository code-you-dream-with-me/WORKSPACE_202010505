--5. emp 테이블에 설정되어 있는 제약조건 중 자신이 생성한 제약 조건들을 
--테이블명 , 컬럼명 ,제약조건명으로 검색하는 쿼리를 쓰세요.
--(단 Foreign key 는 제외합니다)

SELECT  t1.owner
       ,t1.table_name
       ,t2.column_name
       ,t1.constraint_name
FROM user_constraints t1,user_cons_columns t2
WHERE t1.table_name ='EMP'
AND  t1.constraint_name = t2.constraint_name
AND  t1.constraint_type  IN ('P','U','C'); 

--OWNER           TABLE_NAME      COLUMN_NAME     CONSTRAINT_NAME
----------------- --------------- --------------- ---------------
--SCOTT           EMP             EMPNO           PK_EMP