--POWER(숫자1,숫자2)	숫자1의  숫자2만큼의 승수																					
SELECT  POWER(2,5)
FROM dual;
