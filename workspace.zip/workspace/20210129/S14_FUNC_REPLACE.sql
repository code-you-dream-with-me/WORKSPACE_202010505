--REPLACE(문자열 컬럼,'문자1','문자2')
--문자열에서 문자1을 문자2로 치환
--emp테이블에서 이름 첫 두글자를 '*'로 치환
SELECT ename
      ,REPLACE(ename,SUBSTR(ename,1,2),'**') "REPLACE"
FROM emp
WHERE deptno =10;

--ENAME                REPLACE
---------------------- ----------------------------------------
--CLARK                **ARK
--KING                 **NG
--MILLER               **LLER