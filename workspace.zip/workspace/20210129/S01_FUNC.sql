--INITCAP()
--영어에서 첫 글자만 대문자로 출력.
--INITCAP(문자열 또는 컬럼)

SELECT ename
      ,INITCAP(ename)
FROM emp
WHERE deptno =10;

--ENAME                INITCAP(ENAME)
---------------------- --------------------
--CLARK                Clark
--KING                 King
--MILLER               Miller