--
COL name FOR a16
COL tel FOR a14
COL "INSTR" FOR 9
COL "SUBSTR_INSTR" FOR a4
SELECT name
      ,tel
	  ,INSTR(tel,')') "INSTR"
	  ,SUBSTR(tel,1,INSTR(tel,')')-1 ) "SUBSTR_INSTR"
FROM student
WHERE deptno1=201
;
--NAME             TEL            INSTR SUBS
------------------ -------------- ----- ----
--Demi Moore       02)6255-9875       3 02
--Macaulay Culkin  02)312-9838        3 02
--Wesley Snipes    053)736-4981       4 053
--Steve Martin     02)6175-3945       3 02
--Sean Connery     02)381-5440        3 02
--Christian Slater 031)345-5677       4 031