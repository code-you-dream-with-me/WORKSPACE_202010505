SELECT ename
      ,REPLACE(ename,SUBSTR(ename,2,2),'--') "REPLACE"
FROM emp
WHERE deptno =20;

--ENAME                REPLACE
---------------------- ----------------------------------------
--SMITH                S--TH
--JONES                J--ES
--FORD                 F--D