explain plan for

--PLAN SQL
SELECT *
FROM emp;

col plan_table_output format a80
SELECT * FROM table(dbms_xplan.display);

----------------------------------------------------------------------------
--| Id  | Operation         | Name | Rows  | Bytes | Cost (%CPU)| Time     |
----------------------------------------------------------------------------
--|   0 | SELECT STATEMENT  |      |    12 |   468 |     3   (0)| 00:00:01 |
--|   1 |  TABLE ACCESS FULL| EMP  |    12 |   468 |     3   (0)| 00:00:01 |
----------------------------------------------------------------------------
--
--8 행이 선택되었습니다.