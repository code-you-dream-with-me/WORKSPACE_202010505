--그룹핑 조건이 여러 개일 경우 유용하게 사용될수 있다.
--GROUPING SETS(expr1,expr2,expr3...)

--student 테이블에서 학년별 학생 인원수와 키 평균/ 학과별 인원수와 몸무계 평균

SELECT grade
      ,deptno1
	  ,COUNT(*)
	  ,AVG(height)
	  ,AVG(weight)
FROM student
GROUP BY GROUPING SETS(grade,deptno1)
;
     GRADE    DEPTNO1   COUNT(*) AVG(HEIGHT) AVG(WEIGHT)
---------- ---------- ---------- ----------- -----------
         1                     5       170.4        62.4
         2                     5       175.6        67.4
         4                     5       175.8        68.2
         3                     5       166.6        51.4
                  102          4      170.75       64.25
                  201          6  172.833333          67
                  301          2         172          60
                  202          2       179.5        62.5
                  101          4         172          60
                  103          2       165.5        51.5