--CUBE입력 데이터의 소계 및 전체 총계를 계산
--GROUP BY CUBE(컬럼1,컬럼2,....) : 2*n(승)
--모든 경우의 소계를 출력 하므로 컬럼순서는 중요하지 않음.

--부서별 평균 급여와 사원수,직급별 평균급여와 사원수,부서 직급별 평균급여와 사원수,전체 평균 급여와 사원수.
--emp
--1. 부서별 평균 급여와 사원수
--UNION ALL
--2. 직급별 평균급여와 사원수
--UNION ALL
--3. 부서 직급별 평균급여와 사원수
--UNION ALL
--4. 전체 평균 급여와 사원수


--1
--SELECT deptno
--      ,NULL job
--      ,ROUND(AVG(NVL(sal,0)),1) "AVG_SAL"
--	  ,COUNT(*)
--FROM emp
--GROUP BY deptno
--;

--2
--SELECT NULL deptno
--      ,job
--      ,ROUND(AVG(NVL(sal,0)),1) "AVG_SAL"
--	  ,COUNT(*)
--FROM emp
--GROUP BY job
--;

--3
--SELECT deptno
--      ,job
--      ,ROUND(AVG(NVL(sal,0)),1) "AVG_SAL"
--	  ,COUNT(*)
--FROM emp
--GROUP BY deptno,job
--;

--4
--SELECT NULL deptno
--      ,NULL job
--      ,ROUND(AVG(NVL(sal,0)),1) "AVG_SAL"
--	  ,COUNT(*)
--FROM emp
--;


--SELECT deptno
--      ,NULL job
--      ,ROUND(AVG(NVL(sal,0)),1) "AVG_SAL"
--	  ,COUNT(*)
--FROM emp
--GROUP BY deptno
--UNION ALL
--SELECT NULL deptno
--      ,job
--      ,ROUND(AVG(NVL(sal,0)),1) "AVG_SAL"
--	  ,COUNT(*)
--FROM emp
--GROUP BY job
--UNION ALL
--SELECT deptno
--      ,job
--      ,ROUND(AVG(NVL(sal,0)),1) "AVG_SAL"
--	  ,COUNT(*)
--FROM emp
--GROUP BY deptno,job
--UNION ALL
--SELECT NULL deptno
--      ,NULL job
--      ,ROUND(AVG(NVL(sal,0)),1) "AVG_SAL"
--	  ,COUNT(*)
--FROM emp
--ORDER BY deptno,job

--    DEPTNO JOB                   AVG_SAL   COUNT(*)
------------ ------------------ ---------- ----------
--        10 CLERK                    1300          1
--        10 MANAGER                  2450          1
--        10 PRESIDENT                5000          1
--        10                        2916.7          3
--        20 ANALYST                  3000          1
--        20 CLERK                     800          1
--        20 MANAGER                  2975          1
--        20                        2258.3          3
--        30 CLERK                     950          1
--        30 MANAGER                  2850          1
--        30 SALESMAN                 1400          4
--        30                        1566.7          6
--           ANALYST                  3000          1
--           CLERK                  1016.7          3
--           MANAGER                2758.3          3
--           PRESIDENT                5000          1
--           SALESMAN                 1400          4
--                                  2077.1         12
--
--18 행이 선택되었습니다.
--;

--GROUP BY CUBE( deptno,job ) : 2*N승
--1. deptno소계
--2. job소계
--3. deptno소계,job소계
--4. 전체소계

SELECT deptno
      ,job
      ,ROUND(AVG(NVL(sal,0)),1) "AVG_SAL"
	  ,COUNT(*)
FROM emp
GROUP BY CUBE( deptno,job )
ORDER BY deptno,job
;



--    DEPTNO JOB                   AVG_SAL   COUNT(*)
------------ ------------------ ---------- ----------
--        10 CLERK                    1300          1
--        10 MANAGER                  2450          1
--        10 PRESIDENT                5000          1
--        10                        2916.7          3
--        20 ANALYST                  3000          1
--        20 CLERK                     800          1
--        20 MANAGER                  2975          1
--        20                        2258.3          3
--        30 CLERK                     950          1
--        30 MANAGER                  2850          1
--        30 SALESMAN                 1400          4
--        30                        1566.7          6
--           ANALYST                  3000          1
--           CLERK                  1016.7          3
--           MANAGER                2758.3          3
--           PRESIDENT                5000          1
--           SALESMAN                 1400          4
--                                  2077.1         12

