--GROUP BY 특정 조건으로 세부적인 그룹
--원리: GROUP BY 뒤에오는 컬럼 값을 기준으로 먼저 모아놓고 SELECT절에 있는 그룹함수를 적용.
SELECT deptno,AVG(NVL(SAL,0)) "AVG"
FROM emp
GROUP BY deptno
;
--    DEPTNO        AVG
------------ ----------
--        30 1566.66667
--        10 2916.66667
--        20 2258.33333