--특정 위치를 지정하여 출력 하기
--* : 모든 이라는 뜻. 글자수가 0 일수도 있음.
--[ ]:해당 문자에 해당하는 한 문자
--[ ^ ]:해당 문자에 해당하지 않는 한 문자
--^ : 해당 문자로 시작하는 line 출력
--$ (달러):해당 문자로 끝나는 line 출력

--^ : 해당 문자로 시작하는 line 출력
--영문자로 시작하는
SELECT *
FROM t_reg
WHERE REGEXP_LIKE(text,'^[a-zA-Z]')
;
--TEXT
----------------------
--ABC123
--ABC 123
--ABC  123
--abc 123
--abc  123
--a1b2c3
--aabbcc123
--abc
--
--8 행이 선택되었습니다.

--테이블 목록 조회
---SELECT *
---FROM tab
---WHERE tname LIKE '%T_REG%';

SELECT *
FROM t_reg
WHERE REGEXP_LIKE(text,'^[0-9A-Z]')
;
--TEXT
----------------------
--ABC123
--ABC 123
--ABC  123
--123123
--123abc

