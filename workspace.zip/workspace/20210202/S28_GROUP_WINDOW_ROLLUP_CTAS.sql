--CTAS : SELECT한 테이블+데이터 복사
--CREATE TABLE professor2
--AS
--SELECT deptno
--      ,position
--	  ,pay
--FROM professor
--;

--CTAS 결과 확인
--SELECT *
--FROM professor2
--;

--    DEPTNO POSITION                    PAY
------------ -------------------- ----------
--       101 a full professor            550
--       101 assistant professor         380
--       101 instructor                  270
--       102 instructor                  250
--       102 assistant professor         350
--       102 a full professor            490
--       103 a full professor            530
--       103 assistant professor         330
--       103 instructor                  290
--       201 a full professor            570
--       201 assistant professor         330
--       202 assistant professor         310
--       202 instructor                  260
--       203 a full professor            500
--       301 instructor                  220
--       301 assistant professor         290
--
--16 행이 선택되었습니다.
--101학과에 중복된 데이터 입력 

--INSERT INTO professor2 VALUES(101,'instructor',100);

--INSERT INTO professor2 VALUES(101,'a full professor',100);
--INSERT INTO professor2 VALUES(101,'assistant professor',100);
--commit;


--SELECT *
--FROM professor2
--ORDER BY deptno
--;
--101 a full professor 650
--101 assistant professor 480
--101 instructor                  370


--    DEPTNO POSITION                    PAY
------------ -------------------- ----------
--       101 a full professor            550
--       101 assistant professor         100
--       101 instructor                  270
--       101 assistant professor         380
--       101 a full professor            100
--       101 instructor                  100
--       102 a full professor            490
--       102 instructor                  250
--       102 assistant professor         350
--       103 assistant professor         330
--       103 instructor                  290
--       103 a full professor            530
--       201 a full professor            570
--       201 assistant professor         330
--       202 assistant professor         310
--       202 instructor                  260
--       203 a full professor            500
--       301 instructor                  220
--       301 assistant professor         290
--
--19 행이 선택되었습니다.

SELECT deptno
      ,position
	  ,SUM(pay)
FROM professor2
GROUP BY deptno,ROLLUP(position)
;
--    DEPTNO POSITION                                                       SUM(PAY)
------------ ------------------------------------------------------------ ----------
--       101 instructor                                                          370
--       101 a full professor                                                    650
--       101 assistant professor                                                 480
--       101                                                                    1500
--       102 instructor                                                          250
--       102 a full professor                                                    490
--       102 assistant professor                                                 350
--       102                                                                    1090
--       103 instructor                                                          290
--       103 a full professor                                                    530
--       103 assistant professor                                                 330
--       103                                                                    1150
--       201 a full professor                                                    570
--       201 assistant professor                                                 330
--       201                                                                     900
--       202 instructor                                                          260
--       202 assistant professor                                                 310
--       202                                                                     570
--       203 a full professor                                                    500
--       203                                                                     500
--       301 instructor                                                          220
--       301 assistant professor                                                 290
--       301                                                                     510
--
--23 행이 선택되었습니다.
