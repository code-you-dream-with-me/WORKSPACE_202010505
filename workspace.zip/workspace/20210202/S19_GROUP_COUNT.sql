--복수행 함수에 *를 사용하면 NULL포함, 
--복수행 함수에 컬럼명을 쓰면 NULL 불포함
--COUNT:입력 데이터의  총건수 출력
SELECT COUNT(*)
      ,COUNT(comm)
FROM emp;

--  COUNT(*) COUNT(COMM)
------------ -----------
--        12           4