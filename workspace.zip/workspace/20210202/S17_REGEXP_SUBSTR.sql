--REGEXP_SUBSTR: 정규식을 검색하여 문자추출
--REGEXP_SUBSTR(source_char, pattern
--              [, position
--                 [, occurrence
--                    [, match_param
--                       [, subexpr
--                       ]
--                    ]
--                 ]
--              ]
--             )
--* : 모든 이라는 뜻. 글자수가 0 일수도 있음.
--[ ]:해당 문자에 해당하는 한 문자
--[^]:해당 문자에 해당하지 않는 한 문자
--^ : 해당 문자로 시작하는 line 출력
--$ (달러):해당 문자로 끝나는 line 출력
--| : 패턴을 OR 연산을 수행할 때 사용합니다.
--():괄호안의 문자를 하나의 문자로 인식합니다.

--\:역슬러쉬 뒤 문자는 문자 그대로 해석.
--.:임의의 문자 [단 ‘'는 넣을 수 없습니다.]
--?:앞 문자가 없거나 하나 있을 수 있습니다.
--+:앞 문자가 1개 이상의 개수가 존재할 수 있습니다.
--REGEXP_SUBSTR: 정규식을 검색하여 문자추출
--http://num1.naver.com  -> num1.naver.com 
--http:// 부분 제거, '.'으로 구분 되는 필드 3,4까지 출력
--
COL "URL"  FOR a20
COL hpage  FOR a21
SELECT name
      ,hpage
	  ,LTRIM(REGEXP_SUBSTR(hpage,'/([A-Za-z0-9]+\.?){3,4}'),'/') "URL"
FROM professor
WHERE hpage IS NOT NULL;
;
--NAME                                     HPAGE                 URL
------------------------------------------ --------------------- --------------------
--Audie Murphy                             http://www.abc.net    www.abc.net
--Angela Bassett                           http://www.abc.net    www.abc.net
--Jessica Lange                            http://www.power.com  www.power.com
--Michelle Pfeiffer                        http://num1.naver.com num1.naver.com






