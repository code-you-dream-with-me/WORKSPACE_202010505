col TOTAL for A5
col "JAN" for A5
col "FEB" for A5
col "MAR" for A5
col "APR" for A5
col "MAY" for A5
col "JUN" for A5
col "JUL" for A5
col "AUG" for A5
col "SEP" for A5
col "OCT" for A5
col "NOV" for A5
col "DEC" for A5


SELECT TOTAL||'EA' TOTAL
      ,JAN||'EA' AS JAN
      ,FEB||'EA' AS FEB	  
      ,MAR||'EA' AS MAR	  
      ,APR||'EA' AS APR	  
      ,MAY||'EA' AS MAY	  
      ,JUN||'EA' AS JUN	  
      ,JUL||'EA' AS JUL	  
      ,AUG||'EA' AS AUG	  
      ,SEP||'EA' AS SEP	  
      ,OCT||'EA' AS OCT	  
      ,NOV||'EA' AS NOV	  
      ,DEC||'EA' AS DEC	  
FROM(
	SELECT * FROM ( SELECT COUNT(*) OVER() "TOTAL",TO_CHAR(birthday,'MM') "E_MONTH" FROM student )
	PIVOT(
		   COUNT(E_MONTH) FOR E_MONTH  IN ( '01' AS  "JAN" 
										   ,'02' AS  "FEB"
										   ,'03' AS  "MAR"
										   ,'04' AS  "APR"
										   ,'05' AS  "MAY"
										   ,'06' AS  "JUN"
										   ,'07' AS  "JUL"
										   ,'08' AS  "AUG"
										   ,'09' AS  "SEP"
										   ,'10' AS  "OCT"
										   ,'11' AS  "NOV"
										   ,'12' AS  "DEC"
										  )
	)
);


--col "TOTAL" for 999999
--SELECT COUNT(*) OVER() "TOTAL",TO_CHAR(birthday,'MM') "E_MONTH" FROM student








