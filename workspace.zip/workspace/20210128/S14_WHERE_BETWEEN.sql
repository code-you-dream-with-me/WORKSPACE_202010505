--비교 컬럼 BETWEEN A AND B: A<=컬럼<=B
--A가 작은 값, B가 큰값
--A<=컬럼  AND 컬럼<=B
--emp테이블에서 sal 2000 3000사이인 사람들의 empno,ename,sal
--SELECT empno
--      ,ename
--	  ,sal
--FROM emp
--WHERE sal BETWEEN 2000 AND 3000
--;
--     EMPNO ENAME                       SAL
------------ -------------------- ----------
--      7566 JONES                      2975
--      7698 BLAKE                      2850
--      7782 CLARK                      2450
--      7902 FORD                       3000

--BETWEEN보다 출력 속도우수
SELECT empno
      ,ename
	  ,sal
FROM emp
WHERE sal >= 2000 
AND sal <=3000
;