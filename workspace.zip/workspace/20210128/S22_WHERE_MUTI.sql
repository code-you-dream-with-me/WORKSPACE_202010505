--검색조건이 두개 이상
--AND, OR
--AND: 두개의 조건이 동시 만족(hiredate > 82/01/23 and sal>=1300
--OR: 둘중 한가지 조건만 만족해도 될 경우
SELECT ename
      ,hiredate
	  ,sal
FROM emp
WHERE hiredate >= '82/01/23'
AND sal>=1300
;
--
--ENAME                HIREDATE        SAL
---------------------- -------- ----------
--MILLER               82/01/23       1300
--
--1개의 행이 선택되었습니다.