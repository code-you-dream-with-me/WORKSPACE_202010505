COL "ID AND WEIGHT" FOR A50
SELECT name ||' ''s ID : '||id||', WEIGHT is '||weight ||'Kg' AS "ID AND WEIGHT"
FROM student
;

--ID AND WEIGHT
----------------------------------------------------
--James Seo 's ID : 75true, WEIGHT is72Kg
--Rene Russo 's ID : Russo, WEIGHT is64Kg
--Sandra Bullock 's ID : Bullock, WEIGHT is52Kg
--Demi Moore 's ID : Moore, WEIGHT is83Kg
--Danny Glover 's ID : Glover, WEIGHT is70Kg
--Billy Crystal 's ID : Crystal, WEIGHT is48Kg
--Nicholas Cage 's ID : Cage, WEIGHT is42Kg
--Micheal Keaton 's ID : Keaton, WEIGHT is55Kg
--Bill Murray 's ID : Murray, WEIGHT is58Kg
--Macaulay Culkin 's ID : Culkin, WEIGHT is54Kg
--Richard Dreyfus 's ID : Dreyfus, WEIGHT is72Kg
--Tim Robbins 's ID : Robbins, WEIGHT is70Kg
--Wesley Snipes 's ID : Snipes, WEIGHT is82Kg
--Steve Martin 's ID : Martin, WEIGHT is51Kg
--Daniel Day-Lewis 's ID : Day-Lewis, WEIGHT is62Kg
--Danny Devito 's ID : Devito, WEIGHT is48Kg
--Sean Connery 's ID : Connery, WEIGHT is63Kg
--Christian Slater 's ID : Slater, WEIGHT is69Kg
--Charlie Sheen 's ID : Sheen, WEIGHT is81Kg
--Anthony Hopkins 's ID : Hopkins, WEIGHT is51Kg
--
--20 행이 선택되었습니다.