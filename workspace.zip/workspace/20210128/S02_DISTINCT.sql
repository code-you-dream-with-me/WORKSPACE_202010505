--SELECT job,ename
--FROM emp
--ORDER BY 1,2
--;
--JOB                ENAME
-------------------- --------------------
--ANALYST            FORD
--CLERK              JAMES
--CLERK              MILLER
--CLERK              SMITH
--MANAGER            BLAKE
--MANAGER            CLARK
--MANAGER            JONES
--PRESIDENT          KING
--SALESMAN           ALLEN
--SALESMAN           MARTIN
--SALESMAN           TURNER
--SALESMAN           WARD
--
--12 행이 선택되었습니다.

--출력 ROW DATA에 대한 중복 제거
SELECT  DISTINCT job
       ,ename
FROM emp
ORDER BY 1,2
;
--JOB                ENAME
-------------------- --------------------
--ANALYST            FORD
--CLERK              JAMES
--CLERK              MILLER
--CLERK              SMITH
--MANAGER            BLAKE
--MANAGER            CLARK
--MANAGER            JONES
--PRESIDENT          KING
--SALESMAN           ALLEN
--SALESMAN           MARTIN
--SALESMAN           TURNER
--SALESMAN           WARD
--
--12 행이 선택되었습니다.