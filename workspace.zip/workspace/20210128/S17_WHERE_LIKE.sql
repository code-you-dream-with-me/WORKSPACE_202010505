--LIKE 연산자 : '%',_
--%:*(0개포함)
-- '_': 글자수는 한글자만 올수 있고 어떤 글자가 와도 상관 없다.
--sal가 1로 시작하는
SELECT empno
      ,ename
	  ,sal
FROM emp
WHERE sal like '1%'
;
--    EMPNO ENAME                       SAL
------------ -------------------- ----------
--      7499 ALLEN                      1600
--      7521 WARD                       1250
--      7654 MARTIN                     1250
--      7844 TURNER                     1500
--      7934 MILLER                     1300