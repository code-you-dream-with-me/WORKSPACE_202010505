--DISTINCT연산자								
--	중복된 값을 제거하고 출력 하기							
--SELECT deptno
--FROM emp;
--    DEPTNO
------------
--        20
--        30
--        30
--        20
--        30
--        30
--        10
--        10
--        30
--        30
--        20
--        10

SELECT DISTINCT deptno
FROM emp;
--    DEPTNO
------------
--        30
--        10
--        20