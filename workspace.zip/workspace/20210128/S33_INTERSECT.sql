--집합 연산자
--UNION       두 집합의 결과를 합쳐서 출력, 중복 값 제거하고 출력:u + 정렬
--UNION ALL   두 집합의 결과를 합쳐서 출력, 중복 값 제거하지 않고 출력:u
--INTERSECT   두 집합의 교집함 출력
--MINUS       두 집합의 차집합

--집합 연산자 사용 조건
--1. 두 집합의 SELECT 절에 오는 컬럼수 동일
--2. 두 집합의 SELECT 절에 오는 데이터형 동일
--3. 두 집합의 SELECT 절에 오는 컬럼명을 달라도 상관 없다.



--UNION ALL   두 집합의 결과를 합쳐서 출력, 중복 값 제거하지 않고 출력:u
SELECT studno,name			
FROM student
WHERE deptno1=101
INTERSECT
SELECT studno,name			
FROM student
WHERE deptno2=201
;



--    STUDNO NAME
------------ ------------------------------------------------------------
--      9411 James Seo
--      9511 Billy Crystal
--      9611 Richard Dreyfus
--      9711 Danny Devito


--    STUDNO NAME
------------ ------------------------------------------------------------
--      9411 James Seo(중복 데이터)
--      9512 Nicholas Cage

--    STUDNO NAME
------------ ------------------------------------------------------------
--      9411 James Seo