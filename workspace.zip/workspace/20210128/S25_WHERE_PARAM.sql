--사용자에게 조건을 입력 받아서 
--출력 :&변수명

SELECT ename
      ,empno
      ,hiredate
	  ,sal
	  ,comm
FROM emp
WHERE empno =&empno
;