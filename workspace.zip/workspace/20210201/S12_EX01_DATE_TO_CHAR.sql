col  NAME for a20
col  BIRTHDAY for a15
SELECT studno
      ,name
	  ,TO_CHAR(birthday,'YY-MM-DD') BIRTHDAY
FROM student
WHERE TO_CHAR(birthday,'MM')='01'
;

    STUDNO NAME                 BIRTHDAY
---------- -------------------- ---------------
      9511 Billy Crystal        76-01-23
      9514 Bill Murray          76-01-20
      9712 Sean Connery         78-01-05