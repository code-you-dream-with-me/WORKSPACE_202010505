--MONTHS_BETWEEN: 두 날짜 사이의 개월 수
--두 날짜중 큰 날짜를 먼저 써야 양수가 나온다.
--MONTHS_BETWEEN(DATE01,DATE02)
--윤달은 인식 않됨!
--1개월의 기준일 31일로 계산
SELECT MONTHS_BETWEEN('2014-02-01','2014-12-01') "MONTHS_BETWEEN"
      ,MONTHS_BETWEEN('2014-12-01','2014-02-01') "MONTHS_BETWEEN_02"
	  ,MONTHS_BETWEEN('2021-01-01','2021-01-29') "MONTHS_BETWEEN_03"
FROM dual
;
--MONTHS_BETWEEN MONTHS_BETWEEN_02 MONTHS_BETWEEN_03
---------------- ----------------- -----------------
--           -10                10        -.90322581
