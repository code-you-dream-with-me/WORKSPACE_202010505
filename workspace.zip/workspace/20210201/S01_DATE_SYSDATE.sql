--SYSDATE	시스템에 있는 현재 시간
--서버의 시간을 함부로 바꾸면 안된다.
SELECT SYSDATE
FROM dual;

--임시로 현재 SESSION시간 FORMAT변경
--ALTER SESSION SET NLS_DATE_FORMAT='RRRR-MM-DD:HH24:MI:SS' ;
--09:14:42 SCOTT>@S01_DATE_SYSDATE.sql
--
--SYSDATE
----------
--21/02/01
--
--09:15:42 SCOTT>@S01_DATE_SYSDATE.sql
--
--세션이 변경되었습니다.
--
--09:18:40 SCOTT>@S01_DATE_SYSDATE.sql
--
--SYSDATE
---------------------
--2021-02-01:09:19:00