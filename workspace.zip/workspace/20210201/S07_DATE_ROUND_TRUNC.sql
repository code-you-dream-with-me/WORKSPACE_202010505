--ROUND:반올림 EX)상품 접수 및 배송(12:00이후 그 다음날)
--TRUNC:버림  EX)원서접수 (무조건 당일)
SELECT  SYSDATE
       ,ROUND(SYSDATE)
	   ,TRUNC(SYSDATE)
FROM dual;

--SYSDATE             ROUND(SYSDATE)      TRUNC(SYSDATE)
--------------------- ------------------- -------------------
--2021-02-01:12:48:58 2021-02-02:00:00:00 2021-02-01:00:00:00