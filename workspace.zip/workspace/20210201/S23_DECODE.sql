--DECODE:JAVA에서 사용하는 IF문을 오라클로 가져온 함수.

--1. 유형1 A,B일 경우 1을 출력
--DECODE(A,B,1,NULL) (단 마지막의 NULL은 생략 가능)
--DECODE(A,B,1) (단 마지막의 NULL은 생략 가능)

SELECT name     
      ,deptno   
	  ,DECODE(deptno,101,'Computer Engineering',NULL) "DNAME"
FROM professor
;
--NAME                                         DEPTNO DNAME
------------------------------------------ ---------- ----------------------------------------
--Audie Murphy                                    101 Computer Engineering
--Angela Bassett                                  101 Computer Engineering
--Jessica Lange                                   101 Computer Engineering
--Winona Ryder                                    102 NULL
--Michelle Pfeiffer                               102 NULL
--Whoopi Goldberg                                 102 NULL
--Emma Thompson                                   103 NULL
--Julia Roberts                                   103 NULL
--Sharon Stone                                    103 NULL
--Meryl Streep                                    201 NULL
--Susan Sarandon                                  201 NULL
--Nicole Kidman                                   202 NULL
--Holly Hunter                                    202 NULL
--Meg Ryan                                        203 NULL
--Andie Macdowell                                 301 NULL
--Jodie Foster                                    301 NULL
--
--16 행이 선택되었습니다.
