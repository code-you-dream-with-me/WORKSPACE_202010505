package com.sist.ehr.cmn;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.servlet.view.AbstractView;

public class DownloadView extends AbstractView {

	final Logger LOG = LoggerFactory.getLogger(this.getClass());
	
	public DownloadView() {
		setContentType("application/download;charset=utf-8");
	}
	
	/**
	 * 다운로드 파일을 원본파일명으로 변환.
	 * @param orgFileNm
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	public void setDownloadFileName(String orgFileNm,HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		//브라우저 구분자
		String userAgent = request.getHeader("User-Agent");//브라우저 구분자
		LOG.debug("D V F=====userAgent="+userAgent);
		LOG.debug("D V F=====orgFileNm="+orgFileNm);
		LOG.debug("D V F=====userAgent="+userAgent);
		
		//IE 11 Trident
		if(userAgent.indexOf("Trident")>-1 ) {
			//file이름에 space가 있으면 치환
			orgFileNm = URLEncoder.encode(orgFileNm, "utf-8").replaceAll("\\+", "%20");
		//chrome,Edge
		}else if(userAgent.indexOf("Chrome")>-1) {
			orgFileNm = URLEncoder.encode(orgFileNm, "utf-8");
		}else {
			orgFileNm = URLEncoder.encode(orgFileNm, "utf-8");
		}
		
		//header에 파일 이름 set
		response.setHeader("Content-Disposition", "attachment; fileName=\""+orgFileNm+"\";");
		response.setHeader("Content-Transfer-Encoding", "binary");
	}
		
	/**
	 * stream을 사용해서 파일을 다운로드 
	 * @param downloadFile
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	public void downloadFile(File downloadFile,HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		LOG.debug("D V d=====downloadFile="+downloadFile);
		FileInputStream  in=new FileInputStream(downloadFile);
		
		OutputStream out = response.getOutputStream();
		try {
			FileCopyUtils.copy(in, out);
		}catch(IOException e) {
			throw e;
		}finally {
			if(null !=in) {
			
				try {
					in.close();
				}catch(IOException i) {
					
				}
			}
			
			if(null !=out) {
				
				try {
					out.close();
				}catch(IOException i) {
					
				}
			}			
		}
		
	}
	//downloadview 진입점:1
	@Override
	protected void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		setResponseContentType(request, response);
		
		String orgFileNm = (String) model.get("orgFileNm");
		File  downloadFile = (File) model.get("downloadFile");
		
		LOG.debug("D V========================");
		LOG.debug("D V=====orgFileNm="+orgFileNm);
		LOG.debug("D V=====downloadFile="+downloadFile);
		
		//원본파일명으로 파일명 변환
		setDownloadFileName(orgFileNm,request,response);
		
		//다운로드 파일
		downloadFile(downloadFile,request,response);
		
	}

}
