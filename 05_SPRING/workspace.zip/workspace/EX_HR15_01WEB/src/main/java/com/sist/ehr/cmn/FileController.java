package com.sist.ehr.cmn;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;

@Controller
public class FileController {

	final Logger LOG = LoggerFactory.getLogger(this.getClass());
	
	final String UPLOAD_FILE_DIR ="D:\\20201123_eClass\\05_SPRING\\workspace\\EX_HR15_01WEB\\src\\main\\webapp\\WEB-INF\\upload";
	
	final String UPLOAD_IMG_DIR ="D:\\20201123_eClass\\05_SPRING\\workspace\\EX_HR15_01WEB\\src\\main\\webapp\\resources\\img";
	
	@Resource(name = "downloadView")
	View  download;
	
	
	@RequestMapping(value = "file/download.do",method = RequestMethod.POST)
	public ModelAndView download(FileVO fileVO, ModelAndView  model) {
		LOG.debug("C========================");
		LOG.debug("C=download()="+fileVO);
		LOG.debug("C=download="+download);
		LOG.debug("C========================");		
		// DownloadView.java
		//   renderMergedOutputModel()
		//   setDownloadFileName()
		//   downloadFile()
		LOG.debug("=C path="+fileVO.getSavePath());
		LOG.debug("=C orgFileNm="+fileVO.getOrgFileNm());
		LOG.debug("=C saveFileNm="+fileVO.getSaveFileNm());
		
		File  downloadFile=new File(fileVO.getSavePath(), fileVO.getSaveFileNm());
		
		model.setView(download);
		//원본파일명
		model.addObject("orgFileNm",fileVO.getOrgFileNm());
		//파일객체:저장경로,저장파일명
		model.addObject("downloadFile",downloadFile);
		
		
		
		return model;
	}
	
	//http://localhost:8080/ehr/file/file_view.do
	@RequestMapping(value="file/file_view.do")
	public String fileView() {
		LOG.debug("========================");
		LOG.debug("=fileView()=");
		LOG.debug("========================");
		return "file/upload";
	}
	//http://localhost:8080/ehr/file/upload.do
	@RequestMapping(value="file/upload.do",method = RequestMethod.POST)
	public ModelAndView upload(MultipartHttpServletRequest mReg,ModelAndView modelAndView) throws IllegalStateException, IOException {
		LOG.debug("========================");
		LOG.debug("=upload()=");
		LOG.debug("========================");
		//폴더당 생성 파일수 limt존재
		//2021/04
		    
		File   fileRootDir = new File(UPLOAD_FILE_DIR);
		if(fileRootDir.isDirectory()==false) {
			boolean flag = fileRootDir.mkdir();
			LOG.debug("=upload() 생성여부="+flag);  
		}
		
		//년도
		String year = StringUtil.formatDate("yyyy");
		//월
		String month = StringUtil.formatDate("MM");
		LOG.debug("=year="+year);
		LOG.debug("=month="+month);
		
		String fileDiv = mReg.getParameter("file_div");
		LOG.debug("=fileDiv="+fileDiv);
		//UPLOAD_FILE_DIR+/년도/월"
		String datePath = "";
		
		if(fileDiv.equals("20")) {//image
			datePath = UPLOAD_IMG_DIR+File.separator+year+File.separator+month; 
		}else {//file
			datePath = UPLOAD_FILE_DIR+File.separator+year+File.separator+month; 
		}
		
		LOG.debug("=datePath="+datePath);
		File dataFilePath =new File(datePath);
		if(dataFilePath.isDirectory()==false) {
			boolean flag =dataFilePath.mkdirs();
			LOG.debug("=upload() dataFilePath="+flag);  
		}
		//--2021/04
		
		List<FileVO> list = new ArrayList<FileVO>();
		String title = mReg.getParameter("title");
		LOG.debug("=title="+title);
		
		
		Iterator<String> files = mReg.getFileNames();
		while(files.hasNext()) {
			
			FileVO fileVO=new FileVO();
			String upFileNm = files.next();
			LOG.debug("=upFileNm="+upFileNm);
			
			//file정보
			MultipartFile mFile = mReg.getFile(upFileNm);
			
			//원본파일
			String orgFileNm = mFile.getOriginalFilename();
			LOG.debug("=orgFileNm="+orgFileNm);
			
			if(null == orgFileNm || "".equals(orgFileNm))continue;
			
			fileVO.setOrgFileNm(orgFileNm);
			fileVO.setFileSize(mFile.getSize());//bytes
			
			//20210423142414+uuid
			//20210423142414+21371b967af89444b382d4dbf4258ba193
			String saveFileNm = StringUtil.getPK("yyyyMMddHH24mmss");
			LOG.debug("=saveFileNm="+saveFileNm);
			
			String ext = "";
			if(orgFileNm.indexOf(".")>-1) {
				ext = orgFileNm.substring(orgFileNm.indexOf(".")+1);
				saveFileNm+="."+ext;
			}
			LOG.debug("=ext="+ext);
			LOG.debug("=saveFileNm+ext="+saveFileNm);
			fileVO.setSaveFileNm(saveFileNm);
			fileVO.setExt(ext);
			   
			
			
			//Server에 저장: 저장 파일명으로 저장
			File   renameFile=new File(datePath, fileVO.getSaveFileNm());
			LOG.debug("=renameFile.getAbsolutePath()="+renameFile.getAbsolutePath());
			fileVO.setSavePath(datePath);
			//fileVO.setSaveFileNm(renameFile.getAbsolutePath());
			
			LOG.debug("=fileVO="+fileVO);
			
			list.add(fileVO);
			
			//file server로 저장
			mFile.transferTo(new File(fileVO.getSavePath()+File.separator+	
					                  fileVO.getSaveFileNm()));
			
			
		}//--while
		
		modelAndView.addObject("list", list);
		modelAndView.setViewName("file/upload");
		
		return modelAndView;
	}
	
	
	
}
