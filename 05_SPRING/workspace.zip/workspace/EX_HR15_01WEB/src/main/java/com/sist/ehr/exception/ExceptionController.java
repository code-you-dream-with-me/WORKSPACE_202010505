package com.sist.ehr.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sist.ehr.member.domain.User;

@Controller
public class ExceptionController {

	final Logger  LOG = LoggerFactory.getLogger(this.getClass());
	
	//http://localhost:8080/ehr/exec/null_pointer.do?uId=
	@RequestMapping(value="exec/null_pointer.do")
	public String nullPointer(User user) {
		
		if(null !=user.getuId() || "".equals(user.getuId())) {
			throw new NullPointerException("아디를 입력 하세요.");
		}
		
			
		return "main/main";
	}
	//http://localhost:8080/ehr/exec/illegal.do?uId=
	@RequestMapping(value="exec/illegal.do")
	public String illegalAgrument(User user) {
		
		if(null !=user.getuId() || "".equals(user.getuId())) {
			throw new IllegalArgumentException("아이디 형식을 확인 하세요.");
		}
		
			
		return "main/main";
	}	
	
	
}
