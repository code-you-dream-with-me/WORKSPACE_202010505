package com.sist.ehr.main;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sist.ehr.member.controller.UserController;

@Controller
public class MainController {
	final Logger  LOG = LoggerFactory.getLogger(MainController.class);
	final String  VIEW_NAME = "main/main";

	@RequestMapping("main/main_view.do")
	public String mainView(Model model) throws SQLException {
		
		LOG.debug("====================");
		LOG.debug("==mainView()=");
		LOG.debug("====================");
		
		return VIEW_NAME;
	}
	
	
}
 