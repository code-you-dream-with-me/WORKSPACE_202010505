package com.sist.ehr.cmn;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

public class UserExceptionResolver extends SimpleMappingExceptionResolver {
 
	Logger LOG = LoggerFactory.getLogger(this.getClass());
	@Override
	protected ModelAndView doResolveException(HttpServletRequest request, HttpServletResponse response, Object handler,
			Exception ex) {
		String viewName = determineViewName(ex, request);
		LOG.debug("viewName:"+viewName);
		if(null != viewName) {
			//LOG.debug("request.getHeader:"+request.getHeader("AJAX"));

			
			return getModelAndView(viewName,ex,request);  
		}else {
			
			return null;
		}
		
		
	}
	@Override
	protected ModelAndView getModelAndView(String viewName, Exception ex, HttpServletRequest request) {
		ModelAndView  mv=new ModelAndView(viewName);

		mv.addObject("url", request.getRequestURL());
		
		return mv;
	}
	
	

}
