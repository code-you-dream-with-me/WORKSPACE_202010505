/**
* <pre>
* com.sist.ehr.board.controller
* Class Name : BoardController.java
* Description: 게시판
* Author: sist
* Since: 2021/04/28
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2021/04/28 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.ehr.board.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sist.ehr.board.domain.BoardVO;
import com.sist.ehr.board.service.BoardService;
import com.sist.ehr.cmn.DTO;
import com.sist.ehr.cmn.Message;
import com.sist.ehr.cmn.Search;
import com.sist.ehr.cmn.StringUtil;
import com.sist.ehr.code.domain.Code;
import com.sist.ehr.code.service.CodeService;
import com.sist.ehr.member.controller.UserController;
import com.sist.ehr.member.domain.User;

/**
 * @author sist
 *
 */
@Controller
public class BoardController {

	final Logger  LOG = LoggerFactory.getLogger(BoardController.class);
	
	
	@Autowired
	BoardService boardService;
	
	@Autowired
	CodeService  codeService;	
	
	//message처리
	@Autowired
	MessageSource messageSource;
	
	
	@RequestMapping(value="board/do_insert.do",method = RequestMethod.POST
			,produces = "application/json;charset=UTF-8")
	@ResponseBody
	public Message doInsert(BoardVO board,Locale locale,HttpSession session) throws SQLException {
		Message message=new Message();
		LOG.debug("1====================================");
		LOG.debug("board:"+board);
		LOG.debug("====================================");			
		if(null != session.getAttribute("user")) {
			User user = (User)session.getAttribute("user");
			//board.setModId(user.getuId());
			board.setModId(user.getuId());
			board.setRegId(user.getuId());
		}
		LOG.debug("2 board:"+board);
		LOG.debug("====================================");		
		int flag = boardService.doInsert(board);
		message.setMsgId(String.valueOf(flag));
		
		
		String resultMsg = "";
		String doInsert =messageSource.getMessage("user.cmn.doinsert", null, locale);
		if(flag>0) {
			Object[] param = new String[]{doInsert};  
			//{0} 되었습니다. -> {삭제} 되었습니다.
			String doUpdateMsg =messageSource.getMessage("user.cmn.message", param, locale);
			resultMsg = doUpdateMsg;			
		}else {
			Object[] param = new String[]{doInsert};
			//user.cmn.fail.message = {0} 실패 되었습니다.
			String doUpdateMsg =messageSource.getMessage("user.cmn.fail.message", param, locale);
			resultMsg = doUpdateMsg;								
		}
		
		message.setMsgContents(resultMsg);
		
		
		return message;
	}
	
	
	@RequestMapping(value="board/do_update.do",method = RequestMethod.POST
			,produces = "application/json;charset=UTF-8")
	@ResponseBody
	public Message doUpdate(BoardVO board,Locale locale,HttpSession session) throws SQLException {
		Message message=new Message();
		LOG.debug("1====================================");
		LOG.debug("board:"+board);
		LOG.debug("====================================");			
		if(null != session) {
			User user = (User)session.getAttribute("user");
			board.setModId(user.getuId());
			//board.setModId("goodman");
		}
		LOG.debug("2 board:"+board);
		LOG.debug("====================================");		
		int flag = boardService.doUpdate(board);
		message.setMsgId(String.valueOf(flag));
		

		
		
		
		String resultMsg = "";
		String doUpdate =messageSource.getMessage("user.cmn.doupdate", null, locale);
		if(flag>0) {
			Object[] param = new String[]{doUpdate};  
			//{0} 되었습니다. -> {삭제} 되었습니다.
			String doUpdateMsg =messageSource.getMessage("user.cmn.message", param, locale);
			resultMsg = doUpdateMsg;			
		}else {
			Object[] param = new String[]{doUpdate};
			//user.cmn.fail.message = {0} 실패 되었습니다.
			String doUpdateMsg =messageSource.getMessage("user.cmn.fail.message", param, locale);
			resultMsg = doUpdateMsg;								
		}
		
		message.setMsgContents(resultMsg);
		
		
		return message;
	}
	
	@RequestMapping(value="board/do_delete.do",method = RequestMethod.POST
			,produces = "application/json;charset=UTF-8")
	@ResponseBody
	public Message doDelete(BoardVO board,Locale locale) throws SQLException {	
		LOG.debug("1====================================");
		LOG.debug("board:"+board);
		LOG.debug("====================================");		
		
		int flag  = this.boardService.doDelete(board);
		Message message=new Message();
		message.setMsgId(String.valueOf(flag));
		String resultMsg = "";
		String doDelete =messageSource.getMessage("user.cmn.dodelete", null, locale);
		
		if(flag>0) {
			
			Object[] param = new String[]{doDelete};   
			//{0} 되었습니다. -> {삭제} 되었습니다.
			String doDeleteMsg =messageSource.getMessage("user.cmn.message", param, locale);
			resultMsg = doDeleteMsg;
		}else {
			Object[] param = new String[]{doDelete};
			//user.cmn.fail.message = {0} 실패 되었습니다.
			String doDeleteMsg =messageSource.getMessage("user.cmn.fail.message", param, locale);
			resultMsg = doDeleteMsg;			
			
		}
		message.setMsgContents(resultMsg);
		
		return message;
	}	
	
	@RequestMapping(value="board/do_selectone.do",method = RequestMethod.GET)
	public String doSelectOne(BoardVO board,Model model) throws SQLException {
		LOG.debug("1====================================");
		LOG.debug("board:"+board);
		LOG.debug("====================================");	
		String returnView = "board/board_mng";
		
		BoardVO outVO = (BoardVO) this.boardService.doSelectOne(board);
		LOG.debug("outVO:"+outVO);
		model.addAttribute("vo", outVO);
		
		return returnView;
	}   
	
	@RequestMapping(value="board/board_reg_view.do",method = RequestMethod.GET)
	public String viewReg(Model model,HttpServletRequest req) throws SQLException {
		LOG.debug("1====================================");
		LOG.debug("viewReg:");
		LOG.debug("====================================");	
		
		String boardDiv = StringUtil.nvl(req.getParameter("boardDiv"),"10");
		model.addAttribute("boardDiv", boardDiv);
		
		return "board/board_reg";//화면
	}
	
	
	@RequestMapping(value="board/board_view.do",method = RequestMethod.GET)
	public String view(Model model,Search search) throws SQLException {
		List<Code> codeList = (List<Code>) getCodePageRetrieve();
		List<Code> comPageSizeList = new ArrayList<Code>();//페이지 사이즈
		List<Code> boardSearchList = new ArrayList<Code>();//게시 검색
		for(Code vo  :codeList) {
			if(vo.getMstCode().equals("COM_PAGE_SIZE")) {
				comPageSizeList.add(vo);
				LOG.debug("COM_PAGE_SIZE:"+vo);
			}
			
			if(vo.getMstCode().equals("BOARD_SEARCH")) {
				boardSearchList.add(vo);
				LOG.debug("BOARD_SEARCH:"+vo);
			}			
		}
		LOG.debug("1====================================");
		LOG.debug("search:"+search);
		LOG.debug("====================================");	
		
		//NVL처리 
		//검색구분
		search.setSearchDiv(StringUtil.nvl(search.getSearchDiv(),""));
		//검색어
		search.setSearchWord(StringUtil.nvl(search.getSearchWord(),""));
		
		//게시구분
		if(search.getBoardDiv()==0) {
			search.setBoardDiv(10);//공지사항
		}
		
		//페이지 넘
		if(search.getPageNum()==0) {
			search.setPageNum(1);
		}
		
		//페이지 사이즈
		if(search.getPageSize()==0) {
			search.setPageSize(10);
		}
		
		LOG.debug("2====================================");
		LOG.debug("search:"+search);
		LOG.debug("====================================");	
		List<BoardVO> list= (List<BoardVO>) this.boardService.doRetrieve(search);
		model.addAttribute("list", list);//페이지 사이즈
		int totalCnt = 0;
		if(null !=list && list.size()>0) {
			BoardVO totalVO = list.get(0);
			totalCnt = totalVO.getTotalCnt();
		}
		
		model.addAttribute("totalCnt", totalCnt);
		
		model.addAttribute("COM_PAGE_SIZE", comPageSizeList);//페이지 사이즈
		model.addAttribute("BOARD_SEARCH", boardSearchList);//게시 검색조건
		model.addAttribute("search", search);
		
		
		return "board/board_list";//화면
	}
	
	private List<?> getCodePageRetrieve() throws SQLException {
		List codeListParam = new ArrayList<String>();
		codeListParam.add("BOARD_SEARCH"); //게시판검색
		codeListParam.add("COM_PAGE_SIZE");//페이지사이즈
		
		Map<String,Object>  codeMap =new HashMap<String,Object>();
		codeMap.put("codeList",codeListParam);	
		
		return codeService.getCodeRetrieve(codeMap);
	}
	
	
	@RequestMapping(value="board/do_retrieve.do",method = RequestMethod.GET)
	public String doRetrieve(Search search,Model model) throws SQLException {
		String viewName = "board/board_list";

		//NVL처리 
		//검색구분
		search.setSearchDiv(StringUtil.nvl(search.getSearchDiv(),""));
		//검색어
		search.setSearchWord(StringUtil.nvl(search.getSearchWord(),""));
		
		//게시구분
		if(search.getBoardDiv()==0) {
			search.setBoardDiv(10);//공지사항
		}
		
		//페이지 넘
		if(search.getPageNum()==0) {
			search.setPageNum(1);
		}
		
		//페이지 사이즈
		if(search.getPageSize()==0) {
			search.setPageSize(10);
		}
		   
		LOG.debug("====================================");
		LOG.debug("param_init:"+search);
		LOG.debug("====================================");			
		
		List<Code> codeList = (List<Code>) getCodePageRetrieve();
		List<Code> comPageSizeList = new ArrayList<Code>();//페이지 사이즈
		List<Code> boardSearchList = new ArrayList<Code>();//게시 검색
		for(Code vo  :codeList) {
			if(vo.getMstCode().equals("COM_PAGE_SIZE")) {
				comPageSizeList.add(vo);
				LOG.debug("COM_PAGE_SIZE:"+vo);
			}
			
			if(vo.getMstCode().equals("BOARD_SEARCH")) {
				boardSearchList.add(vo);
				LOG.debug("BOARD_SEARCH:"+vo);
			}			
		}
		
		model.addAttribute("COM_PAGE_SIZE", comPageSizeList);//페이지 사이즈
		model.addAttribute("BOARD_SEARCH", boardSearchList);//게시 검색조건
		model.addAttribute("search", search);
		
		List<BoardVO> list= (List<BoardVO>) this.boardService.doRetrieve(search);

		int totalCnt = 0;
		if(null !=list && list.size()>0) {
			BoardVO totalVO = list.get(0);
			totalCnt = totalVO.getTotalCnt();
		}
		
		model.addAttribute("totalCnt", totalCnt);
		model.addAttribute("list", list);
		
		return viewName;
	}
	
	@RequestMapping(value="board/do_retrieve_json.do",method = RequestMethod.GET
			,produces = "application/json;charset=UTF-8")
	@ResponseBody
	public List<BoardVO> doRetrieveJSON(Search search) throws SQLException {
		String viewName = "board/board_list";

		//NVL처리 
		//검색구분
		search.setSearchDiv(StringUtil.nvl(search.getSearchDiv(),""));
		//검색어
		search.setSearchWord(StringUtil.nvl(search.getSearchWord(),""));
		
		//게시구분
		if(search.getBoardDiv()==0) {
			search.setBoardDiv(10);//공지사항
		}
		
		//페이지 넘
		if(search.getPageNum()==0) {
			search.setPageNum(1);
		}
		
		//페이지 사이즈
		if(search.getPageSize()==0) {
			search.setPageSize(10);
		}
		   
		LOG.debug("====================================");
		LOG.debug("param_init:"+search);
		LOG.debug("====================================");			
						
		List<BoardVO> list= (List<BoardVO>) this.boardService.doRetrieve(search);


		
		return list;
	}	
	
}


























