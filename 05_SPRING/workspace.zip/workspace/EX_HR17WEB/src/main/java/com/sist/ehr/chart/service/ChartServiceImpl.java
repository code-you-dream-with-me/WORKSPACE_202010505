package com.sist.ehr.chart.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sist.ehr.chart.dao.ChartDaoImpl;
import com.sist.ehr.chart.domain.PieVO;

@Service
public class ChartServiceImpl implements ChartService {
	final Logger LOG = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	ChartDaoImpl  chartDao;
	
	@Override
	public List<PieVO> getMemberRatio() {
		return chartDao.getMemberRatio();
	}

}
