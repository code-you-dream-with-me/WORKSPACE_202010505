package com.sist.ehr.board.service;

import java.sql.SQLException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sist.ehr.board.dao.BoardDaoImpl;
import com.sist.ehr.cmn.DTO;
@Service
public class BoardServiceImpl implements BoardService {
	final Logger LOG = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	BoardDaoImpl  boardDao;
	
	
	public BoardServiceImpl() {
		
	}
	
	@Override
	public List<?> doRetrieve(DTO dto) throws SQLException {
		return boardDao.doRetrieve(dto);
	}

	/**
	 * 단건조회,조회count++
	 */
	@Override
	public DTO doSelectOne(DTO dto) throws SQLException {
		int flag = boardDao.doReadCnt(dto);
		LOG.debug("-----------------------");
		LOG.debug("-flag-"+flag);
		LOG.debug("-----------------------");		
		return boardDao.doSelectOne(dto);
	}

	@Override
	public int doUpdate(DTO dto) throws SQLException {
		return boardDao.doUpdate(dto);
	}

	@Override
	public int doDelete(DTO dto) throws SQLException {
		return boardDao.doDelete(dto);
	}

	@Override
	public int doInsert(DTO dto) throws SQLException {
		return boardDao.doInsert(dto);
	}

}
