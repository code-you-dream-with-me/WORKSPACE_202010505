package com.sist.ehr.board.dao;

import java.sql.SQLException;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Repository;

import com.sist.ehr.board.domain.BoardVO;
import com.sist.ehr.cmn.DTO;
import com.sist.ehr.cmn.Search;
import com.sist.ehr.member.dao.UserDaoImpl;

@Repository
public class BoardDaoImpl {
    final static Logger LOG = LoggerFactory.getLogger(BoardDaoImpl.class);
	
	final String NAMESPACE = "com.sist.ehr.board";//com.sist.ehr.board.doDelete
	
	@Autowired
	SqlSessionTemplate sqlSessionTemplate;	
	
	public BoardDaoImpl() {}
	
	/**
	 * 삭제
	 * @param dto
	 * @return
	 * @throws SQLException
	 */
	public int doDelete(DTO dto) throws SQLException {
		int flag = 0;
		BoardVO  board = (BoardVO) dto;
		//com.sist.ehr.board.doDelete
		String statement = this.NAMESPACE+".doDelete";
		LOG.debug("=============================");
		LOG.debug("=board="+board);
		LOG.debug("=statement="+statement);
		flag =  this.sqlSessionTemplate.delete(statement, board);

		LOG.debug("=flag="+flag);
		LOG.debug("=============================");			
		
		return flag;
	}
	
	public int doInsert(DTO dto) throws SQLException {
		int flag = 0;
		BoardVO  board = (BoardVO) dto;
		String statement = this.NAMESPACE+".doInsert";	
		LOG.debug("=============================");
		LOG.debug("=board="+board);
		LOG.debug("=statement="+statement);		
		
		
		flag = this.sqlSessionTemplate.insert(statement, board);
		LOG.debug("=flag="+flag);
		LOG.debug("=============================");
		return flag;		
	}
	
	public DTO doSelectOne(DTO dto) throws SQLException {
		BoardVO   inVO = (BoardVO) dto;
		BoardVO   outVO= null;
		String statement = this.NAMESPACE+".doSelectOne";	
		LOG.debug("=============================");
		LOG.debug("=BoardVO="+inVO);
		LOG.debug("=statement="+statement);
		
		outVO = this.sqlSessionTemplate.selectOne(statement, inVO);
		
		LOG.debug("=1 outVO="+outVO);
		LOG.debug("=============================");
		if(null == outVO) {
			LOG.debug("=============================");
			LOG.debug("=null outVO ="+outVO);
			LOG.debug("=============================");			
			throw new EmptyResultDataAccessException("여기 EmptyResultDataAccessException",1);
		}
		return outVO;
	}
	
	
	public int doUpdate(DTO dto) throws SQLException {
		int flag = 0;
		BoardVO board = (BoardVO) dto;
		String statement = this.NAMESPACE+".doUpdate";	
		LOG.debug("=============================");
		LOG.debug("=board="+board);
		LOG.debug("=statement="+statement);		
		flag = this.sqlSessionTemplate.update(statement, board);
		LOG.debug("=flag="+flag);		
		LOG.debug("=============================");	
		return flag;		
	}
	

	
	public List<?> doRetrieve(DTO dto) throws SQLException {
		Search  param = (Search) dto;
		String statement = this.NAMESPACE+".doRetrieve";
		LOG.debug("=============================");	
		LOG.debug("=param=\n"+param);
		LOG.debug("=statement="+statement);		
		
		List<BoardVO> list = this.sqlSessionTemplate.selectList(statement, param);
		
		for(BoardVO vo :list) {
			LOG.debug("=vo:"+vo);
		}
		LOG.debug("=============================");	
		
		return list;
	}
	
	public int doReadCnt(DTO dto) throws SQLException {
		int 	flag = 0;
		BoardVO board = (BoardVO) dto;
		String statement = this.NAMESPACE+".doReadCnt";			
		LOG.debug("=============================");
		LOG.debug("=board="+board);
		LOG.debug("=statement="+statement);	
		flag = this.sqlSessionTemplate.update(statement, board);
		LOG.debug("=flag="+flag);		
		LOG.debug("=============================");			
		return flag;		
	}
	
	
}













