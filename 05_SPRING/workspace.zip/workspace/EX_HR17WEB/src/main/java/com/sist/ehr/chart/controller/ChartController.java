package com.sist.ehr.chart.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.JsonArray;
import com.sist.ehr.chart.domain.PieVO;
import com.sist.ehr.chart.service.ChartService;

@Controller
public class ChartController {
	Logger LOG = LoggerFactory.getLogger(this.getClass());
	
	
	@Autowired
	ChartService chartService;
	
	@RequestMapping(value = "chart/pie_chart_view.do",method = RequestMethod.GET)
	public String doPieView() {
		LOG.debug("====================");
		LOG.debug("=doPieView()=");
		LOG.debug("====================");
		return "chart/pie_chart";
	}
	
	//PieVO
	@RequestMapping(value = "chart/pie_chart.do",method = RequestMethod.GET
			,produces = "application/json; charset=UTF-8")
	@ResponseBody   
	public String pieChart() {
		LOG.debug("====================");
		LOG.debug("=pieChart()=");
		LOG.debug("====================");
//        ['Work',     11],
//        ['Eat',      2],
//        ['Commute',  2],
//        ['Watch TV', 2],
//        ['Sleep',    7]

		
		List<PieVO> list=chartService.getMemberRatio();

		
		JsonArray  jArray=new JsonArray();
		for(PieVO vo:list) {
			JsonArray  sArray=new JsonArray();
			sArray.add(vo.getLevelNm());
			sArray.add(vo.getLevelCnt());
			
			jArray.add(sArray);
		}
		
		LOG.debug("=========================");
		LOG.debug("=jArray=="+jArray.toString());
		LOG.debug("=========================");
		
		
		return jArray.toString();
	}	
}
