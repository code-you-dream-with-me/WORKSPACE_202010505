package com.sist.ehr.main;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.sist.ehr.board.domain.BoardVO;
import com.sist.ehr.board.service.BoardService;
import com.sist.ehr.cmn.Search;
import com.sist.ehr.cmn.StringUtil;
import com.sist.ehr.code.domain.Code;
import com.sist.ehr.member.controller.UserController;

@Controller
public class MainController {
	final Logger  LOG = LoggerFactory.getLogger(MainController.class);
	final String  VIEW_NAME = "main/main";
	@Autowired
	BoardService boardService;
	
	@RequestMapping("main/main_view.do")
	public String mainView(Search search,Model model) throws SQLException {
		
		LOG.debug("====================");
		LOG.debug("==mainView()=");
		LOG.debug("====================");
		//NVL처리 
		//검색구분
		search.setSearchDiv(StringUtil.nvl(search.getSearchDiv(),""));
		//검색어
		search.setSearchWord(StringUtil.nvl(search.getSearchWord(),""));
		
		//게시구분
		if(search.getBoardDiv()==0) {
			search.setBoardDiv(10);//공지사항
		}
		
		//페이지 넘
		if(search.getPageNum()==0) {
			search.setPageNum(1);
		}
		
		//페이지 사이즈
		if(search.getPageSize()==0) {
			search.setPageSize(5);
		}
		   
		LOG.debug("====================================");
		LOG.debug("param_init:"+search);
		LOG.debug("====================================");	
		
		List<BoardVO> list10= (List<BoardVO>) this.boardService.doRetrieve(search);
		
		search.setBoardDiv(20);//자유게시판
		List<BoardVO> list20= (List<BoardVO>) this.boardService.doRetrieve(search);
		

		model.addAttribute("board_list_10", list10);
		model.addAttribute("board_list_20", list20);  
		
		return VIEW_NAME;
	}
	
	
	
}
 