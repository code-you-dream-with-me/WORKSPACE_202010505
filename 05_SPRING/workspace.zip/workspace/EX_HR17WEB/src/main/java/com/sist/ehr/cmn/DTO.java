package com.sist.ehr.cmn;
/**
 * 모든 VO의 Parent
 * @author sist
 *
 */
public class DTO {
   
	//번호
	private int num;
	//총글수
	private int totalCnt;
	
	//게시구분
	private int boardDiv;
	
	
	
	public DTO() {}



	public int getBoardDiv() {
		return boardDiv;
	}



	public void setBoardDiv(int boardDiv) {
		this.boardDiv = boardDiv;
	}



	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public int getTotalCnt() {
		return totalCnt;
	}

	public void setTotalCnt(int totalCnt) {
		this.totalCnt = totalCnt;
	}



	@Override
	public String toString() {
		return "DTO [num=" + num + ", totalCnt=" + totalCnt + ", boardDiv=" + boardDiv + "]";
	}

	
	
}
