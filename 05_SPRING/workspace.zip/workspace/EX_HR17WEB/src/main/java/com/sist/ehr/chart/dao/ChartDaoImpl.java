package com.sist.ehr.chart.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sist.ehr.board.dao.BoardDaoImpl;
import com.sist.ehr.board.domain.BoardVO;
import com.sist.ehr.chart.domain.PieVO;

@Repository
public class ChartDaoImpl {
	
final static Logger LOG = LoggerFactory.getLogger(BoardDaoImpl.class);
	
	final String NAMESPACE = "com.sist.ehr.chart";//com.sist.ehr.board.doDelete
	
	@Autowired
	SqlSessionTemplate sqlSessionTemplate;	
	
	

	public List<PieVO> getMemberRatio() {
		String statement = this.NAMESPACE+".getMemberRatio";
		LOG.debug("=============================");	
		LOG.debug("=statement="+statement);		
		
		List<PieVO> list = this.sqlSessionTemplate.selectList(statement);
		
		for(PieVO vo :list) {
			LOG.debug("=vo:"+vo);
		}
		LOG.debug("=============================");	
		
		return list;	
	}
}
