package com.sist.ehr.chart.service;

import java.util.List;

import com.sist.ehr.chart.domain.PieVO;

public interface ChartService {

	public List<PieVO> getMemberRatio();
}
