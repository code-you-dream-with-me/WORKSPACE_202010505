package com.sist.ehr.chart.domain;

import com.sist.ehr.cmn.DTO;

public class PieVO extends DTO {
    private String levelNm;
	private int levelCnt;
	
	public PieVO() {}

	public PieVO(String levelNm, int levelCnt) {
		super();
		this.levelNm = levelNm;
		this.levelCnt = levelCnt;
	}

	public String getLevelNm() {
		return levelNm;
	}

	public void setLevelNm(String levelNm) {
		this.levelNm = levelNm;
	}

	public int getLevelCnt() {
		return levelCnt;
	}

	public void setLevelCnt(int levelCnt) {
		this.levelCnt = levelCnt;
	}

	@Override
	public String toString() {
		return "PieVO [levelNm=" + levelNm + ", levelCnt=" + levelCnt + ", toString()=" + super.toString() + "]";
	}



	
	
}

