package com.sist.ehr;

import org.apache.log4j.Logger;

public class Hello {
	final static Logger LOG = Logger.getLogger(Hello.class);
	public static void main(String[] args) {
		System.out.println("Hello, world.");
		
		LOG.debug("========================");
		LOG.debug("==Hello, world.=");
		LOG.debug("========================");

	}

}
