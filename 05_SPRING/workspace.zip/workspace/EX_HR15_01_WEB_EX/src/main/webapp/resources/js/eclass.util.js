/**
 * e반 util : eclass.util.js
 * 작성자  : 김현룡
 * 작성일  : 2021-04-21
 * 수정일  : 2021-04-21
 */
var eUtil = {};
eUtil.PROTOCOL = window.location.protocol; 


eUtil.ISEmpty = function(str){
	if(null != str && undefined != str ){
		str = str.toString();
		
		if(str.replace(/ /gi,"").length ==0){
			return true;
		}
	}
	return false;
}

