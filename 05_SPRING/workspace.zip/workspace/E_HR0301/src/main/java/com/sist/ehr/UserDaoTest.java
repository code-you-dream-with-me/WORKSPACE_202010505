package com.sist.ehr;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class UserDaoTest {
    final static Logger LOG = Logger.getLogger(UserDaoTest.class);
	public static void main(String[] args) {
		
		
		ApplicationContext  context = new GenericXmlApplicationContext("/applicationContext.xml");
		LOG.debug("====================");
		LOG.debug("=context="+context);
		LOG.debug("====================");			
		
		UserDao dao= context.getBean("userDao", UserDao.class);
		LOG.debug("====================");
		LOG.debug("=dao="+dao);
		LOG.debug("====================");			
		
		//UserDao dao=new DaoFactory().userDao();
		
		User user=new User("H_124","이상무","1234");
		
		try {
			int flag = dao.add(user);
			if(1==flag) {
				LOG.debug("====================");
				LOG.debug("=등록성공=");
				LOG.debug("====================");				
			}
			  
			User outVO = dao.get(user.getuId()); 
			
			if(user.getuId().equals(outVO.getuId())  
			   && user.getName().equals(outVO.getName())
			   && user.getPasswd().equals(outVO.getPasswd())
				) {
				LOG.debug("====================");
				LOG.debug("=단건조회 성공=");
				LOG.debug("====================");					
				
			}
				
			
			
		} catch (ClassNotFoundException e) {
			LOG.debug("====================");
			LOG.debug("=ClassNotFoundException="+e.getMessage());
			LOG.debug("====================");
			e.printStackTrace();
		} catch (SQLException e) {
			LOG.debug("====================");
			LOG.debug("=SQLException="+e.getMessage());
			LOG.debug("====================");			
			e.printStackTrace();
		}

	}

}
