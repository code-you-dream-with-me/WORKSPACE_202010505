/**
 * 
 */
package com.sist.ehr;

import static org.junit.Assert.*;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * @author sist
 *
 */
public class JTestLifeCycle02 {

	final static Logger LOG = Logger.getLogger(JTestLifeCycle02.class);
	
	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		LOG.debug("-----------------------");
		LOG.debug("=@BeforeClass=");
		LOG.debug("-----------------------");
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		LOG.debug("-----------------------");
		LOG.debug("=@AfterClass=");
		LOG.debug("-----------------------");		
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		LOG.debug("=======================");
		LOG.debug("=@Before=");
		LOG.debug("=======================");	
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
		LOG.debug("=======================");
		LOG.debug("=@After=");
		LOG.debug("=======================");			
	}

	@Test
	public void test01() {
		LOG.debug("=======================");
		LOG.debug("=@Test test01=");
		LOG.debug("=======================");
	}
	
	@Test
	public void test02() {
		LOG.debug("=======================");
		LOG.debug("=@Test test02=");
		LOG.debug("=======================");
	}	

}
