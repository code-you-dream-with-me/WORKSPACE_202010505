package com.sist.ehr;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

import org.apache.log4j.Logger;
import org.junit.Ignore;
import org.junit.Test;

public class JTestUserDao {
	final Logger LOG = Logger.getLogger(this.getClass());
	
	@Test
	public void test() {
		LOG.debug("=======================");
		LOG.debug("=test=");
		LOG.debug("=======================");
	}
	
	@Test
	@Ignore
	public void test02() {
		LOG.debug("=======================");
		LOG.debug("=test02=");
		LOG.debug("=======================");	
		
		
		assertThat(1, is(0));
		
	}
	
	
	
	
	
	

}
