/**
 * 
 */
package com.sist.ehr;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;
import org.springframework.dao.EmptyResultDataAccessException;

/**
 * @author sist
 *
 */
public class JTestUserDao03 {

	final static Logger LOG = Logger.getLogger(JTestUserDao03.class);
	
//	assertArrayEquals(a, b); 
//	- 배열 A와 B가 일치함을 확인한다.
//
//	assertEquals(a, b);
//	- 객체 A와 B가 일치함을 확인한다.
//
//	assertEquals(a, b, c);
//	- 객체 A와 B가 일치함을 확인한다.
//
//	- a: 예상값, b:결과값, c: 오차범위
//
//	​
//
//	assertSame(a, b); 
//	- 객체 A와 B가 같은 객임을 확인한다.
//
//	​
//	assertTrue(a); 
//	- 조건 A가 참인가를 확인한다.			
	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		LOG.debug("-----------------------");
		LOG.debug("=@BeforeClass=");
		LOG.debug("-----------------------");
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		LOG.debug("-----------------------");
		LOG.debug("=@AfterClass=");
		LOG.debug("-----------------------");		
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		LOG.debug("=======================");
		LOG.debug("=@Before=");
		LOG.debug("=======================");	
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
		LOG.debug("=======================");
		LOG.debug("=@After=");
		LOG.debug("=======================");			
	}

	//@Test(expected=EmptyResultDataAccessException) :  EmptyResultDataAccessException이 발생하면 성공
	@Test(expected = EmptyResultDataAccessException.class)
	public void getFailure() throws ClassNotFoundException, SQLException {
		LOG.debug("=======================");
		LOG.debug("=@getFailure=");
		LOG.debug("=======================");
		
		ApplicationContext  context = new GenericXmlApplicationContext("/applicationContext.xml");
		LOG.debug("=context="+context);
		assertNotNull(context);//갹채가 null이 아님을 확인한다.
		
		UserDao dao= context.getBean("userDao", UserDao.class);
		LOG.debug("=dao="+dao);
		assertNotNull(dao);
		
		User user01=new User("H_124_01","이상무","1234");
		User user02=new User("H_124_02","이상무","1234");
		User user03=new User("H_124_03","이상무","1234");
		//삭제
		dao.deleteUser(user01);
		dao.deleteUser(user02);
		dao.deleteUser(user03);
		
		//단건조회
		dao.get("unknown_id");
		
	}
	
	//milliseconds
	//@Test(timeout = 1000)
	@Test
	@Ignore
	public void addAndGet() throws ClassNotFoundException, SQLException {
		LOG.debug("=======================");
		LOG.debug("=@addAndGet=");
		LOG.debug("=======================");
		
		ApplicationContext  context = new GenericXmlApplicationContext("/applicationContext.xml");
		LOG.debug("=context="+context);
		assertNotNull(context);//갹채가 null이 아님을 확인한다.
		
		UserDao dao= context.getBean("userDao", UserDao.class);
		LOG.debug("=dao="+dao);
		assertNotNull(dao);
		
		User user01=new User("H_124_01","이상무","1234");
		User user02=new User("H_124_02","이상무","1234");
		User user03=new User("H_124_03","이상무","1234");
		
		//검색용도
		User user09=new User("H_124","이상무","1234");
		//삭제
		dao.deleteUser(user01);
		dao.deleteUser(user02);
		dao.deleteUser(user03);
		
		//등록
		int flag = dao.add(user01);
		assertThat(flag, is(dao.count(user09)));//flag(actual)과 is(예상) 비교
		
		
		flag += dao.add(user02);
		assertThat(flag, is(dao.count(user09)));//flag(actual)과 is(예상) 비교
		

		flag += dao.add(user03);
		assertThat(flag, is(dao.count(user09)));//flag(actual)과 is(예상) 비교
		
		
		//단건조회:user01
		User vsUser01 =dao.get(user01.getuId());
		
		//단건조회:user02
		User vsUser02 =dao.get(user02.getuId());
		
		//단건조회:user03
		User vsUser03 =dao.get(user03.getuId());
		
		//비교 
		checkUser(vsUser01, user01);
		checkUser(vsUser02, user02);
		checkUser(vsUser03, user03);
	}
	
	private void checkUser(User vsUser, User user01) {
		//비교
		assertThat(vsUser.getuId(), is(user01.getuId()));
		assertThat(vsUser.getName(), is(user01.getName()));
		assertThat(vsUser.getPasswd(), is(user01.getPasswd()));		
	}
	
	
	@Test
	@Ignore
	public void test02() {
		LOG.debug("=======================");
		LOG.debug("=@Test test02=");
		LOG.debug("=======================");
	}	

}
