package com.sist.ehr.anno;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MockMvcBuilder;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.ui.Model;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.sist.ehr.Level;
import com.sist.ehr.User;


//메소드 수행 순서: method ASCENDING ex)a~z
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class) //스프링 테스트 컨텍스트 프레임의 JUnit기능 확장
@ContextConfiguration(locations = {"file:src/main/webapp/WEB-INF/spring/root-context.xml",
                               "file:src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml"		
})
public class JTestAnnoController {
	final Logger LOG = LoggerFactory.getLogger(JTestAnnoController.class);
	
	
	@Autowired
	WebApplicationContext webApplicationContext;
	
	//브라우저 대신할 Mock
	MockMvc  mockMvc;
	
	User user01;
	
	@Before
	public void setUp() throws Exception {
		LOG.debug("setUp()");
		
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
		user01=new User("H_124_01","이상무","1234",Level.BASIC,1,0,"jamesol@naver.com","");
	}

	
	
	@After
	public void tearDown() throws Exception {
		LOG.debug("tearDown()");
	}

	
	@Test
	@Ignore
	public void doSelectOne() throws Exception {
		//url호출, param전달
		MockHttpServletRequestBuilder  createMessage = MockMvcRequestBuilders.post("/anno/do_selectone.do")
				.param("u_id", user01.getuId())
				.param("name", user01.getName())
				.param("passwd", user01.getPasswd())
				.param("email", user01.getEmail());
				
		
		ResultActions resultActions =mockMvc.perform(createMessage).andExpect(status().isOk());
		
		MvcResult  mvcResult =resultActions.andReturn();
		
		//Model + View
		ModelAndView modelAndView=mvcResult.getModelAndView();
		
		User userResult = (User) modelAndView.getModel().get("vo");
		LOG.debug("userResult:"+userResult);
		
		checkUser(userResult,user01);
	}
	
	@Test
	public void getAjax() throws Exception {
		//url호출, param전달
		MockHttpServletRequestBuilder  createMessage = MockMvcRequestBuilders.post("/anno/ajax.do")
				.param("u_id", user01.getuId())
				.param("name", user01.getName())
				.param("passwd", user01.getPasswd())
				.param("email", user01.getEmail());		
		
		
		ResultActions resultActions =mockMvc.perform(createMessage)
									.andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_UTF8))
									.andExpect(status().isOk());
		
		//출력 결과 요약
		String result = resultActions.andDo(print())
				        .andReturn()
				        .getResponse().getContentAsString();		
		LOG.debug("-------------------------------------");
		LOG.debug("result:"+result);
		LOG.debug("-------------------------------------");
		
		
		Gson gson=new Gson();
		User outVO = gson.fromJson(result, User.class);
		
		LOG.debug("-------------------------------------");
		LOG.debug("outVO:"+outVO);
		LOG.debug("-------------------------------------");		
		checkUser(outVO,user01);
		/*
MockHttpServletRequest:
      HTTP Method = POST
      Request URI = /anno/ajax.do
       Parameters = {u_id=[H_124_01], name=[이상무], passwd=[1234], email=[jamesol@naver.com]}
          Headers = []
             Body = <no character encoding set>
    Session Attrs = {}

Handler:
             Type = com.sist.ehr.anno.controller.AnnoController
           Method = com.sist.ehr.anno.controller.AnnoController#getAjax(HttpServletRequest, User)

Async:
    Async started = false
     Async result = null

Resolved Exception:
             Type = null

ModelAndView:
        View name = null
             View = null
            Model = null

FlashMap:
       Attributes = null

MockHttpServletResponse:
           Status = 200
    Error message = null
          Headers = [Content-Type:"application/json;charset=UTF-8", Content-Length:"105"]
     Content type = application/json;charset=UTF-8
             Body = {"uId":"H_124_01","name":"이상무","passwd":"1234","login":0,"recommend":0,"email":"jamesol@naver.com"}
    Forwarded URL = null
   Redirected URL = null
          Cookies = []
[2021-04-13 10:37:14.335] DEBUG JTestAnnoController.getAjax(JTestAnnoController.java:121) - -------------------------------------
[2021-04-13 10:37:14.336] DEBUG JTestAnnoController.getAjax(JTestAnnoController.java:122) - result:{"uId":"H_124_01","name":"이상무","passwd":"1234","login":0,"recommend":0,"email":"jamesol@naver.com"}
[2021-04-13 10:37:14.336] DEBUG JTestAnnoController.getAjax(JTestAnnoController.java:123) - -------------------------------------
[2021-04-13 10:37:14.337] DEBUG JTestAnnoController.getAjax(JTestAnnoController.java:129) - -------------------------------------
[2021-04-13 10:37:14.337] DEBUG JTestAnnoController.getAjax(JTestAnnoController.java:130) - outVO:User [uId=H_124_01, name=이상무, passwd=1234, level=null, login=0, recommend=0, email=jamesol@naver.com, regDt=null, toString()=com.sist.ehr.User@1deceb67]
[2021-04-13 10:37:14.338] DEBUG JTestAnnoController.getAjax(JTestAnnoController.java:131) - -------------------------------------
[2021-04-13 10:37:14.338] DEBUG JTestAnnoController.tearDown(JTestAnnoController.java:75) - tearDown()

		 */
	}
	
	
	
	//Response Result print
	@Test
	@Ignore
	public void doSelectOne02() throws Exception {
		//url호출, param전달
		MockHttpServletRequestBuilder  createMessage = MockMvcRequestBuilders.post("/anno/do_selectone.do")
				.param("u_id", user01.getuId())
				.param("name", user01.getName())
				.param("passwd", user01.getPasswd())
				.param("email", user01.getEmail());
				
		
		ResultActions resultActions =mockMvc.perform(createMessage).andExpect(status().isOk());
		
		MvcResult  mvcResult =resultActions.andReturn();
		
		//Model + View
		ModelAndView modelAndView=mvcResult.getModelAndView();
		
		User userResult = (User) modelAndView.getModel().get("vo");
		LOG.debug("userResult:"+userResult);
		
		checkUser(userResult,user01);
		
		//출력 결과 요약
		String result = resultActions.andDo(print())
				        .andReturn()
				        .getResponse().getContentAsString();
	
		
		
	}	
	
	private void checkUser(User vsUser, User user01) {
		//비교
		assertThat(vsUser.getuId(), is(user01.getuId()));
		assertThat(vsUser.getName(), is(user01.getName()));
		assertThat(vsUser.getPasswd(), is(user01.getPasswd()));	
		assertThat(vsUser.getEmail(), is(user01.getEmail()));	
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	@Test
	public void beans() {
		LOG.debug("webApplicationContext:"+webApplicationContext);
		LOG.debug("mockMvc:"+mockMvc);
		assertThat(webApplicationContext, is(notNullValue()));
		assertThat(mockMvc, is(notNullValue()));
	}

}
