package com.sist.ehr.anno.controller;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.sist.ehr.DTO;
import com.sist.ehr.User;
import com.sist.ehr.anno.service.AnnoService;

@Controller
public class AnnoController {
  final Logger LOG = LoggerFactory.getLogger(AnnoController.class);
	
  @Autowired	
  AnnoService  service;
  
  
  @RequestMapping(value = "anno/anno.do",method = RequestMethod.GET)
  public String viewAnno(HttpServletRequest req) throws SQLException {
	  LOG.debug("=========================");
	  LOG.debug("=viewAnno()=");
	  LOG.debug("=========================");	  
	  
	  return "anno/anno";
  }
  
  @RequestMapping(value = "anno/ajax.do",method=RequestMethod.POST
			,produces = "application/json;charset=UTF-8")
  @ResponseBody
  public String getAjax(HttpServletRequest req,User vo) {
	  LOG.debug("=========================");
	  LOG.debug("=getAjax()=");
	  LOG.debug("=========================");	  
	  String uId    = req.getParameter("u_id");
	  String name   = req.getParameter("name");
	  String passwd = req.getParameter("passwd");
	  String email  = req.getParameter("email");
	  
	  LOG.debug("=uId="+uId);
	  LOG.debug("=name="+name);
	  LOG.debug("=passwd="+passwd);
	  LOG.debug("=email="+email);
	  
	  User user=new User();   
	  user.setuId(uId);
	  user.setName(name);
	  user.setPasswd(passwd);
	  user.setEmail(email);
	  LOG.debug("=user="+user);	  
	  
	  Gson gson=new Gson();
	  
	  String jsonString = gson.toJson(user);
	  
	  LOG.debug("=jsonString="+jsonString);
	  LOG.debug("=========================");	  
	  return jsonString;
  }
  
  
  @RequestMapping(value = "anno/do_selectone.do",method = RequestMethod.POST)
  public String doSelectOne(HttpServletRequest req,Model model) throws SQLException {
	  LOG.debug("=========================");
	  LOG.debug("=doSelectOne()=");
	  LOG.debug("=========================");	  
	  
	  String uId    = req.getParameter("u_id");
	  String name   = req.getParameter("name");
	  String passwd = req.getParameter("passwd");
	  String email  = req.getParameter("email");
	  LOG.debug("=uId="+uId);
	  LOG.debug("=name="+name);
	  LOG.debug("=passwd="+passwd);
	  LOG.debug("=email="+email);
	  
	  User user=new User();   
	  user.setuId(uId);
	  user.setName(name);
	  user.setPasswd(passwd);
	  user.setEmail(email);
	  LOG.debug("=user="+user);     
	  
	  User outVO = (User) this.service.doSelectOne(user);
	  LOG.debug("=outVO="+outVO);
	  model.addAttribute("vo", outVO);
	  
	  
	  return "anno/anno";
  }  
  /**
   * 브라우저
   * http://localhost:8080/ehr/anno/doInsert.do
   * 
   * Controller
   * anno/anno_view.do
   * @return
   * @throws SQLException
		AnnoController.doInsert(AnnoController.java:33) - =========================
		AnnoController.doInsert(AnnoController.java:34) - =doInsert()=
		AnnoController.doInsert(AnnoController.java:35) - =========================
		
		AnnoServiceImpl.doInsert(AnnoServiceImpl.java:49) - ======================
		AnnoServiceImpl.doInsert(AnnoServiceImpl.java:50) - =doInsert()=
		AnnoServiceImpl.doInsert(AnnoServiceImpl.java:51) - ======================
		
		AnnoDaoImpl.doInsert(AnnoDaoImpl.java:56) - ======================
		AnnoDaoImpl.doInsert(AnnoDaoImpl.java:57) - =doInsert=
		AnnoDaoImpl.doInsert(AnnoDaoImpl.java:58) - ======================		
   */
  @RequestMapping(value = "anno/do_insert.do",method = RequestMethod.GET)
  public String  doInsert() throws  SQLException{
	  LOG.debug("=========================");
	  LOG.debug("=doInsert()=");
	  LOG.debug("=========================");
	  
	  //------------------------
	  //service call
	  //------------------------
	  this.service.doInsert(new DTO()); 
	  
	  
	  ///WEB-INF/views/ +anno/anno+ .jsp ->/WEB-INF/views/anno/anno.jsp
	  return "anno/anno";
  }
}
