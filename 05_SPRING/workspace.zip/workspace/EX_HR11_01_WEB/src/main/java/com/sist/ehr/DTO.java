package com.sist.ehr;
/**
 * 모든 VO의 Parent
 * @author sist
 *
 */
public class DTO {

}
