package com.sist.ehr;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;
import javax.swing.tree.TreePath;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class UserDaoImpl implements UserDao {
	final static Logger LOG = LoggerFactory.getLogger(UserDaoImpl.class);
	//Spring JdbcTemplate
	JdbcTemplate jdbcTemplate;
	
	DataSource dataSource;
	
	RowMapper<User>  row =new RowMapper<User>() {
		public User mapRow(ResultSet rs, int rowNum) throws SQLException {
			User  userVO=new User();
			LOG.debug("1rowNum:"+rowNum);
			userVO.setuId(rs.getString("u_id"));
			userVO.setName(rs.getString("name"));
			userVO.setPasswd(rs.getString("passwd"));	
			//int to Level로 변환
			userVO.setLevel(Level.valueOf(rs.getInt("u_level"))); 
			userVO.setLogin(rs.getInt("login"));
			userVO.setRecommend(rs.getInt("recommend"));
			userVO.setEmail(rs.getString("email"));
			userVO.setRegDt(rs.getString("reg_dt"));
			LOG.debug("2rowNum:"+rowNum);
			return userVO;
		}
	};
	
	public UserDaoImpl() {}
	
	
	//setter를 통한 주입
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	

    /**
     * 다건조회
     * @param user
     * @return List<User>
     * @throws SQLException
     */
	public List<User> getAll(User user)throws SQLException{
		List<User> list=null;
		StringBuffer sb=new StringBuffer(200);	
		sb.append(" SELECT               \n");
		sb.append("     u_id,            \n");
		sb.append("     name,            \n");
		sb.append("     passwd,          \n");
		//컬럼추가:2021/03/30
		sb.append("     u_level,         \n");
		sb.append("     login,           \n");
		sb.append("     recommend,       \n");
		sb.append("     email,           \n");
		sb.append("     TO_CHAR(reg_dt,'YYYY/MM/DD HH24MISS') reg_dt     \n");		
		sb.append(" FROM hr_member             \n");
		sb.append(" WHERE u_id LIKE ? ||'%'    \n");
		sb.append(" ORDER BY u_id              \n");
		LOG.debug("=============================");
		LOG.debug("=sql=\n"+sb.toString());
		LOG.debug("=param=\n"+user);
		LOG.debug("=============================");			
		
		Object[] args = {user.getuId()};
		list = this.jdbcTemplate.query(sb.toString(), args, row);
		for(User vo :list) {
			LOG.debug(vo.toString());
		}
		
		return list;
	}

	/**
	 * 등록 건수 조회
	 * @param user
	 * @return int
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public int count(User user)throws ClassNotFoundException,SQLException{
		int cnt = 0;
		

		StringBuffer sb=new StringBuffer(200);	
		sb.append("  SELECT COUNT(*) cnt      \n");
		sb.append("  FROM hr_member           \n");
		sb.append("  WHERE U_ID LIKE ? ||'%'  \n");		
		LOG.debug("=============================");
		LOG.debug("=sql=\n"+sb.toString());
		LOG.debug("=param=\n"+user);
		LOG.debug("=============================");	
		Object[] args = {user.getuId()};
		cnt = this.jdbcTemplate.queryForObject(sb.toString(), args,Integer.class);
		
		LOG.debug("=============================");
		LOG.debug("=99_cnt="+cnt);
		LOG.debug("=============================");			

		
		return cnt;
	}


	public int doDelete(DTO dto) throws SQLException {
		int flag = 0;
		User   user = (User)dto;
		StringBuffer sb=new StringBuffer(200);
		sb.append(" DELETE FROM hr_member \n");
		sb.append(" WHERE  u_id = ?       \n"); 
		LOG.debug("=sql=\n"+sb.toString());
		
		Object[]  args = {user.getuId()};
		LOG.debug("=============================");
		LOG.debug("=user="+user);
		LOG.debug("=============================");		
		
		
		flag = jdbcTemplate.update(sb.toString(), args);
		return flag;
	}


	@Override
	public int doInsert(DTO dto) throws SQLException {
		int flag = 0;
		User user = (User) dto;
		
		StringBuffer sb=new StringBuffer(200);
		sb.append(" INSERT INTO hr_member (  \n");
		sb.append("     u_id,                \n");
		sb.append("     name,                \n");
		sb.append("     passwd,              \n");
		//추가컬럼
		sb.append("     u_level,             \n");
		sb.append("     login,               \n");
		sb.append("     recommend,           \n");
		sb.append("     email,               \n");
		sb.append("     reg_dt               \n");
		sb.append(" ) VALUES (               \n");
		sb.append("     ?,                   \n");
		sb.append("     ?,                   \n");
		sb.append("     ?,                   \n");
		sb.append("     ?,                   \n");	
		sb.append("     ?,                   \n");
		sb.append("     ?,                   \n");
		sb.append("     ?,                   \n");
		sb.append("     SYSDATE              \n");
		sb.append(" )                        \n");	
		LOG.debug("=sql=\n"+sb.toString());
		
		Object[]  args = {user.getuId(),
				          user.getName(),
				          user.getPasswd(),
				          user.getLevel().getValue(),
				          user.getLogin(),
				          user.getRecommend(),
				          user.getEmail()
				          
		};
		flag = jdbcTemplate.update(sb.toString(), args);
		
		return flag;
	}


	@Override
	public DTO doSelectOne(DTO dto) throws SQLException {
		//B  2. SQL을 담은 Statement, PreparedStatement
		//B  3. PreparedStatement를 수행
		//B  4. 조회의 경우 ResultSet으로  정보를 받아와 User Object에 저장
		User inVO  = (User) dto;
		User outVO = null;

		StringBuffer sb=new StringBuffer(200);	
		sb.append(" SELECT               \n");
		sb.append("     u_id,            \n");
		sb.append("     name,            \n");
		sb.append("     passwd,          \n");
		//컬럼추가:2021/03/30
		sb.append("     u_level,         \n");
		sb.append("     login,           \n");
		sb.append("     recommend,       \n");
		sb.append("     email,           \n");
		sb.append("     TO_CHAR(reg_dt,'YYYY/MM/DD HH24MISS') reg_dt     \n");
		sb.append(" FROM                 \n");
		sb.append("     hr_member        \n");
		sb.append(" WHERE   u_id = ?     \n");		
		LOG.debug("=============================");
		LOG.debug("=sql=\n"+sb.toString());
		LOG.debug("=============================");	
		Object[] args = {inVO.getuId()};
		LOG.debug("=args=\n"+inVO.getuId());
		

		
		outVO = this.jdbcTemplate.queryForObject(sb.toString(), args, row);

		LOG.debug("=============================");
		LOG.debug("=1 outVO="+outVO);
		LOG.debug("=============================");
		
		if(null == outVO) {
			LOG.debug("=============================");
			LOG.debug("=null outVO ="+outVO);
			LOG.debug("=============================");			
			throw new EmptyResultDataAccessException("여기 EmptyResultDataAccessException",1);
		}
		
		LOG.debug("=============================");
		LOG.debug("=2 outVO="+outVO);
		LOG.debug("=============================");
		
		return outVO;
	}


	@Override
	public List<?> doRetrieve(DTO dto) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public int doUpdate(DTO dto) throws SQLException {
		int flag = 0;
		User user = (User) dto;
		StringBuffer sb=new StringBuffer(200);
		sb.append(" UPDATE hr_member   \n");
		sb.append(" SET                \n");
		sb.append("     name      = ?, \n");
		sb.append(" 	passwd    = ?, \n");
		sb.append(" 	u_level   = ?, \n");
		sb.append(" 	login     = ?, \n");
		sb.append(" 	recommend = ?, \n");
		sb.append(" 	email     = ?,  \n");
		sb.append(" 	reg_dt    = SYSDATE  \n");
		sb.append(" WHERE u_id = ?     \n");
		LOG.debug("=sql=\n"+sb.toString());
		
		Object[]  args = {
		          user.getName(),
		          user.getPasswd(),
		          user.getLevel().getValue(),
		          user.getLogin(),
		          user.getRecommend(),
		          user.getEmail(),
		          user.getuId()};
		LOG.debug("=user=\n"+user);
        flag = jdbcTemplate.update(sb.toString(), args);

		return flag;
	}
}

























