package com.sist.ehr;

public class MusicVO {
	private int rank;// 순위
	private String title;// 제목
	private String singer;// 가수
	private String poster;// 포스터
	private String state;// 상태
	private String idcrement;
	private String key; // 키

	@Override
	public String toString() {
		return "MusicVO [rank=" + rank + ", title=" + title + ", singer=" + singer + ", poster=" + poster + ", state="
				+ state + ", idcrement=" + idcrement + ", key=" + key + "]";
	}

	public int getRank() {
		return rank;
	}

	public void setRank(int rank) {
		this.rank = rank;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSinger() {
		return singer;
	}

	public void setSinger(String singer) {
		this.singer = singer;
	}

	public String getPoster() {
		return poster;
	}

	public void setPoster(String poster) {
		this.poster = poster;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getIdcrement() {
		return idcrement;
	}

	public void setIdcrement(String idcrement) {
		this.idcrement = idcrement;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}
}
