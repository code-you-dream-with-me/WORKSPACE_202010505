package com.sist.ehr;

import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class YouTubeMusicManager {

	public static void main(String args[]) {
		YouTubeMusicManager musicManager = new YouTubeMusicManager();
		List<MusicVO> list = musicManager.musicAllData();

		// Json save :{"datas":[{},{},{},{}]}
		JSONObject root = new JSONObject();
		JSONArray arr = new JSONArray();

		for (MusicVO vo : list) {
			JSONObject obj = new JSONObject();
			obj.put("rank", vo.getRank());
			obj.put("title", vo.getTitle());
			obj.put("singer", vo.getSinger());
			obj.put("poster", vo.getPoster());
			obj.put("key", vo.getKey());

			arr.add(obj);
		}
		root.put("datas", arr);
		System.out.println("root=" + root.toJSONString());
		try {
			FileWriter fw = new FileWriter("c:\\music.json");
			fw.write(root.toJSONString());
			fw.close();
		} catch (Exception e) {
			System.out.println("e=" + e.getMessage());
		}

	}

	public List<MusicVO> musicAllData() {
		List<MusicVO> list = new ArrayList<MusicVO>();
		try {
			// Jsoup: html parse
			Document doc = Jsoup.connect("http://www.genie.co.kr/chart/top200").get();
			Elements poster = doc.select("a.cover img");
			Elements title = doc.select("table.list-wrap a.title");
			Elements singer = doc.select("table.list-wrap a.artist");
			System.out.println("==============================");
			for (int i = 0; i < 50; i++) {
				// System.out.println(title.get(i).text()+"||"+singer.get(i).text()+"||"+poster.attr("src"));
				MusicVO musicVO = new MusicVO();
				musicVO.setRank(i + 1);
				musicVO.setTitle(title.get(i).text());
				musicVO.setPoster(poster.get(i).attr("src"));
				musicVO.setSinger(singer.get(i).text());

				String key = youtubeKey(musicVO.getTitle());
				System.out.println("=key=" + key);

				musicVO.setKey(key);

				list.add(musicVO);
			}
			System.out.println("==============================");

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return list;
	}

	/**
	 * 키가 있어야 동영상 출력 가능.
	 * 
	 * @param title
	 * @return
	 */
	public String youtubeKey(String title) {
		String key = "";
		// https://www.youtube.com/results?search_query=
		String url = "https://www.youtube.com/results?search_query=";
		try {
			org.jsoup.nodes.Document doc = Jsoup.connect(url + title).get();
			// youtube
			Pattern p = Pattern.compile("/watch\\?v=[^가-힣]+");// 한글 제외,모든 문자
			Matcher m = p.matcher(doc.toString());

			while (m.find() == true) {
				/// watch?v=xRbPAVnqtcs","webPageType"
				String data = m.group();// 찾은 문자 1줄

				System.out.println(data);
				data = data.substring(data.indexOf("=") + 1, data.indexOf("\""));

				key = data;
				break;
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return key;
	}
}
