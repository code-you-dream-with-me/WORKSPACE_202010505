package com.sist.ehr.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.sist.ehr.member.domain.User;

@Controller
public class ExceptionController {
	Logger LOG = LoggerFactory.getLogger(this.getClass());
	//View
	private final String VIEW_NM = "main/main";     
	//NullPointerException
	@RequestMapping(value="except/null_pointer",method = RequestMethod.GET)
	public String nullPointer(User user) {
		if(null == user.getuId() || user.getuId().equals("")) {
			throw new NullPointerException("아이디를 입력 하세요.");
		}
		
		LOG.debug("VIEW_NM:"+VIEW_NM);
		return VIEW_NM;
	}
	
	//IllegalArgumentException
	@RequestMapping(value="except/illegal_arg",method = RequestMethod.GET)
	public String illegalArgument(User user) {
		if(null == user.getuId() || user.getuId().equals("")) {
			throw new IllegalArgumentException("아이디 형식을 확인 하세요.");
		}
		
		LOG.debug("VIEW_NM:"+VIEW_NM);
		return VIEW_NM;
	}	
}
