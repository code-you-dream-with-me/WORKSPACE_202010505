package com.sist.ehr.member.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;
import javax.swing.tree.TreePath;

import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.sist.ehr.cmn.DTO;
import com.sist.ehr.cmn.Search;
import com.sist.ehr.member.domain.Level;
import com.sist.ehr.member.domain.User;
//mybatis오류 확인 
//1. NAMESPACE+.+id 확인:.
//2. query오류 확인
//3. resultType 확인
public class UserDaoImpl implements UserDao {
	final static Logger LOG = LoggerFactory.getLogger(UserDaoImpl.class);
	
	final String NAMESPACE = "com.sist.ehr.member";//com.sist.ehr.member.doDelete
	
	@Autowired
	SqlSessionTemplate sqlSessionTemplate;
	
	
	
	//Spring JdbcTemplate
	JdbcTemplate jdbcTemplate;
	
	DataSource dataSource;
	
	RowMapper<User>  row =new RowMapper<User>() {
		public User mapRow(ResultSet rs, int rowNum) throws SQLException {
			User  userVO=new User();
			userVO.setuId(rs.getString("u_id"));
			userVO.setName(rs.getString("name"));
			userVO.setPasswd(rs.getString("passwd"));
			//int to Level로 변환
			userVO.setLevel(Level.valueOf(rs.getInt("u_level")));
			userVO.setLogin(rs.getInt("login"));
			userVO.setRecommend(rs.getInt("recommend"));
			userVO.setEmail(rs.getString("email"));
			userVO.setRegDt(rs.getString("reg_dt"));
			
			userVO.setNum(rs.getInt("rnum"));
			userVO.setTotalCnt(rs.getInt("total_cnt"));
			
			return userVO;
		}
	};
	
	public UserDaoImpl() {}
	
	
	//setter를 통한 주입
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	

    /**
     * 다건조회
     * @param user
     * @return List<User>
     * @throws SQLException
     */
	public List<User> getAll(User user)throws SQLException{
		List<User> list=null;
		StringBuffer sb=new StringBuffer(200);	
		sb.append(" SELECT               \n");
		sb.append("     u_id,            \n");
		sb.append("     name,            \n");
		sb.append("     passwd,          \n");
		//컬럼추가:2021/03/30
		sb.append("     u_level,         \n");
		sb.append("     login,           \n");
		sb.append("     recommend,       \n");
		sb.append("     email,           \n");
		sb.append("     TO_CHAR(reg_dt,'YYYY/MM/DD HH24MISS') reg_dt,     \n");
		sb.append("     1 rnum,          \n");
		sb.append("     1 total_cnt      \n");
		sb.append(" FROM hr_member             \n");
		sb.append(" WHERE u_id LIKE ? ||'%'    \n");
		sb.append(" ORDER BY u_id              \n");
		LOG.debug("=============================");
		LOG.debug("=sql=\n"+sb.toString());
		LOG.debug("=param=\n"+user);
		LOG.debug("=============================");			
		
		Object[] args = {user.getuId()};
		list = this.jdbcTemplate.query(sb.toString(), args, row);
		for(User vo :list) {
			LOG.debug(vo.toString());
		}
		
		return list;
	}

	/**
	 * 등록 건수 조회
	 * @param user
	 * @return int
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public int count(User user)throws ClassNotFoundException,SQLException{
		int cnt = 0;
		
		//mybatis sql: NAMESPACE+.+id;
		String statement = this.NAMESPACE+".count";			
		cnt = sqlSessionTemplate.selectOne(statement, user);
		
		
		LOG.debug("=============================");
		LOG.debug("=99_cnt="+cnt);
		LOG.debug("=============================");			

		
		return cnt;
	}


	public int doDelete(DTO dto) throws SQLException {
		int flag = 0;
		User   user = (User)dto;
		
		//mybatis sql: NAMESPACE+.+id;
		String statement = this.NAMESPACE+".doDelete";
		
		LOG.debug("=============================");
		LOG.debug("=user="+user);
		LOG.debug("=statement="+statement);
		LOG.debug("=============================");		
		

		
		flag = this.sqlSessionTemplate.delete(statement, user);
		return flag;
	}


	@Override
	public int doInsert(DTO dto) throws SQLException {
		int flag = 0;
		User user = (User) dto;
		//mybatis sql: NAMESPACE+.+id;
		String statement = this.NAMESPACE+".doInsert";		
		LOG.debug("=============================");
		LOG.debug("=user="+user);
		LOG.debug("=statement="+statement);
		LOG.debug("=============================");	
		flag = sqlSessionTemplate.insert(statement, user);
		
		return flag;
	}


	@Override
	public DTO doSelectOne(DTO dto) throws SQLException {

		User inVO  = (User) dto;
		User outVO = null;

		String statement = this.NAMESPACE+".doSelectOne";		
		LOG.debug("=============================");
		LOG.debug("=user="+inVO);
		LOG.debug("=statement="+statement);
		LOG.debug("=============================");	
		
		outVO = this.sqlSessionTemplate.selectOne(statement, inVO);

		LOG.debug("=============================");
		LOG.debug("=1 outVO="+outVO);
		LOG.debug("=============================");
		
		if(null == outVO) {
			LOG.debug("=============================");
			LOG.debug("=null outVO ="+outVO);
			LOG.debug("=============================");			
			throw new EmptyResultDataAccessException("여기 EmptyResultDataAccessException",1);
		}
		
		return outVO;
	}


	@Override
	public List<?> doRetrieve(DTO dto) throws SQLException {
		Search  param = (Search) dto;
		
		StringBuffer sbWhere = new StringBuffer(100);
		
		//검색조건:이름(10),id(20),EMAIL(30)  
		if(null !=param  && !"".equals(param.getSearchDiv()))  {
			
			if("10".equals(param.getSearchDiv())) {
				sbWhere.append(" WHERE name LIKE  ? ||'%' \n");
			}else if("20".equals(param.getSearchDiv())) {
				sbWhere.append(" WHERE u_id LIKE  ? ||'%' \n");
			}else if("30".equals(param.getSearchDiv())) {
				sbWhere.append(" WHERE email LIKE  ? ||'%' \n");
			}
		}
		
		
		StringBuffer sb=new StringBuffer(1000);
		sb.append(" SELECT A.*,B.*                                                                                      \n");
		sb.append(" FROM(                                                                                               \n");
		sb.append("     SELECT t2.rnum,                                                                                 \n");
		sb.append("            t2.u_id,                                                                                 \n");
		sb.append("            t2.name,                                                                                 \n");
		sb.append("            t2.passwd,                                                                                 \n");
		sb.append("            t2.u_level,                                                                              \n");
		sb.append("            t2.login,                                                                                \n");
		sb.append("            t2.recommend,                                                                            \n");
		sb.append("            t2.email,                                                                                \n");
		sb.append("            DECODE(TO_CHAR(SYSDATE,'YYYYMMDD'),TO_CHAR(t2.reg_dt,'YYYYMMDD')                         \n");
		sb.append("                   ,TO_CHAR(t2.reg_dt,'HH24:MI')                                                     \n");
		sb.append("                   ,TO_CHAR(t2.reg_dt,'YYYY/MM/DD')) AS reg_dt                                       \n");
		sb.append("     FROM(                                                                                           \n");
		sb.append("         SELECT ROWNUM rnum,t1.*                                                                     \n");
		sb.append("         FROM (                                                                                      \n");
		sb.append("             SELECT *                                                                                \n");
		sb.append("             FROM hr_member                                                                          \n");
		//-------------------------------------------------------------------------------------------------------------------
		//검색
		//-------------------------------------------------------------------------------------------------------------------
		sb.append(sbWhere.toString());
		sb.append("             ORDER BY reg_dt desc                                                                    \n");
		sb.append("         )t1                                                                                         \n");
		sb.append("     )t2                                                                                             \n");
		//sb.append("    -- WHERE rnum BETWEEN (&PAGE_SIZE * (&PAGE_NUM-1)+1) AND (&PAGE_SIZE * (&PAGE_NUM-1)+&PAGE_SIZE) \n");
		sb.append("     WHERE rnum BETWEEN (? * (?-1) + 1) AND (? * (?-1) + ?)                                          \n");
		sb.append(" )A                                                                                                  \n");
		sb.append(" CROSS JOIN                                                                                          \n");
		sb.append("     (SELECT COUNT(*) total_cnt                                                                      \n");
		sb.append("      FROM hr_member                                                                                 \n");
		//sb.append("     --WHERE조건: 이름(10),id(20),EMAIL(30)                                                             \n");
		//-------------------------------------------------------------------------------------------------------------------
		//검색
		//-------------------------------------------------------------------------------------------------------------------
		sb.append(sbWhere.toString());		
		sb.append("     )B                                                                                              \n");
		
		LOG.debug("=sql=\n"+sb.toString());
		LOG.debug("=param=\n"+param);

		//query에 파라메터 set
		List<Object>   listArg = new ArrayList<Object>();
		//검색조건이 있으면 : 6개
		if(null !=param  && !"".equals(param.getSearchDiv()))  {
			//검색
			listArg.add(param.getSearchWord());
			//페이징 정보
			listArg.add(param.getPageSize());
			listArg.add(param.getPageNum());
			listArg.add(param.getPageSize());
			listArg.add(param.getPageNum());
			listArg.add(param.getPageSize());
			//검색
			listArg.add(param.getSearchWord());
		//검색조건이 있으면 : 5개	
		}else {
			//페이징 정보
			listArg.add(param.getPageSize());
			listArg.add(param.getPageNum());
			listArg.add(param.getPageSize());
			listArg.add(param.getPageNum());
			listArg.add(param.getPageSize());			
		}
		
		LOG.debug("1=listArg="+listArg.toArray());
		for(Object ob:listArg) {
			LOG.debug("=ob="+ob.toString());
		}
		
		List<User> list = jdbcTemplate.query(sb.toString(), listArg.toArray(), row);
		LOG.debug("2=param=");
		return list;
	}


	@Override
	public int doUpdate(DTO dto) throws SQLException {
		int flag = 0;
		User user = (User) dto;
		
		LOG.debug("=user=\n"+user);
		String statement = this.NAMESPACE+".doUpdate";		
		LOG.debug("=============================");
		LOG.debug("=user="+user);
		LOG.debug("=statement="+statement);
		LOG.debug("=============================");	
		flag = sqlSessionTemplate.update(statement, user);

		return flag;
	}
}

























