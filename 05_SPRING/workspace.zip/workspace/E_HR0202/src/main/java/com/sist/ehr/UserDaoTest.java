package com.sist.ehr;

import java.sql.SQLException;

import org.apache.log4j.Logger;

public class UserDaoTest {
    final static Logger LOG = Logger.getLogger(UserDaoTest.class);
	public static void main(String[] args) {
		UserDao dao=new NUserDao();
		User user=new User("H_124","이상무","1234");
		
		try {
			int flag = dao.add(user);
			if(1==flag) {
				LOG.debug("====================");
				LOG.debug("=등록성공=");
				LOG.debug("====================");				
			}
			  
			User outVO = dao.get(user.getuId()); 
			
			if(user.getuId().equals(outVO.getuId())  
			   && user.getName().equals(outVO.getName())
			   && user.getPasswd().equals(outVO.getPasswd())
				) {
				LOG.debug("====================");
				LOG.debug("=단건조회 성공=");
				LOG.debug("====================");					
				
			}
				
			
			
		} catch (ClassNotFoundException e) {
			LOG.debug("====================");
			LOG.debug("=ClassNotFoundException="+e.getMessage());
			LOG.debug("====================");
			e.printStackTrace();
		} catch (SQLException e) {
			LOG.debug("====================");
			LOG.debug("=SQLException="+e.getMessage());
			LOG.debug("====================");			
			e.printStackTrace();
		}

	}

}
