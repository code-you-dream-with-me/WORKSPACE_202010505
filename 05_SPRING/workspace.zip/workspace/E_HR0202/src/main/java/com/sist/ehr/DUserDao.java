package com.sist.ehr;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DUserDao extends UserDao {

	@Override
	public Connection getConnection() throws ClassNotFoundException, SQLException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		final  String DB_URL = "jdbc:oracle:thin:@211.238.142.124:1521:xe";
		final  String USER_ID = "SPRING";
		final  String USER_PASS = "eclass";			
		
		Connection connection = DriverManager.getConnection(DB_URL, USER_ID, USER_PASS);
		LOG.debug("=============================");
		LOG.debug("=connection="+connection);
		LOG.debug("=============================");		
		
		return connection;
	}

}
