package com.sist.ehr;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class SingleTonRegistryMain {

	public static void main(String[] args) {
		
		ApplicationContext context = new AnnotationConfigApplicationContext(DaoFactory.class);
		UserDao dao= context.getBean("userDao", UserDao.class);		
		UserDao dao02= context.getBean("userDao", UserDao.class);
		System.out.println("dao:"+dao);
		System.out.println("dao02:"+dao02);
		//dao:com.sist.ehr.UserDao@514646ef
		//dao02:com.sist.ehr.UserDao@514646ef		
		
		DaoFactory factory=new DaoFactory();
		UserDao dao03 = factory.userDao();
		UserDao dao04 = factory.userDao();
		
		//dao03:com.sist.ehr.UserDao@305ffe9e
		//dao04:com.sist.ehr.UserDao@302c971f
		System.out.println("dao03:"+dao03);
		System.out.println("dao04:"+dao04);		
	}

}
