package com.sist.ehr.board;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.*;
import static org.mockito.Matchers.isNotNull;

import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.sist.ehr.board.dao.BoardDaoImpl;
import com.sist.ehr.board.domain.BoardVO;
import com.sist.ehr.cmn.DTO;
import com.sist.ehr.cmn.Search;
import com.sist.ehr.member.domain.User;
import com.sist.ehr.user.JTestUserDao;
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(SpringJUnit4ClassRunner.class) //스프링 테스트 컨텍스트 프레임의 JUnit기능 확장
@ContextConfiguration(locations = {"file:src/main/webapp/WEB-INF/spring/root-context.xml",
                                   "file:src/main/webapp/WEB-INF/spring/appServlet/test-servlet-context.xml"
})
public class JTestBoardDao {
	final static Logger LOG = Logger.getLogger(JTestBoardDao.class);
	@Autowired
	ApplicationContext  context;//테스트 오브젝트가 만들어 지고 나면 스프링 테스트 컨텍스트에 의해 자동으로 주입된다.
	
	BoardVO board01;
	BoardVO board02;
	BoardVO board03;
	
	@Autowired
	BoardDaoImpl  boardDao;
	
	Search search01;
	
	@Before
	public void setUp() throws Exception {
		board01 =new BoardVO(1241, "title_1241", "contents_1241", 0, "10", "강사", "", "eclass_2", "");
		board02 =new BoardVO(1242, "title_1242", "contents_1242", 0, "10", "강사", "", "eclass_2", "");
		board03 =new BoardVO(1243, "title_1243", "contents_1243", 0, "10", "강사", "", "eclass_2", "");
		
		search01=new Search("", "", 10, 1);		
	}
	
	@Test
	public void doRetrieve() throws SQLException {
		//삭제
		//추가
		//doRetrieve
		//삭제
		boardDao.doDelete(board01);
		boardDao.doDelete(board02);
		boardDao.doDelete(board03);			
		
		//입력
		int flag = boardDao.doInsert(board01);
		assertThat(flag, is(1));
		
		flag +=boardDao.doInsert(board02);
		assertThat(flag, is(2)); 
		
		flag +=boardDao.doInsert(board03);
		assertThat(flag, is(3));		  
		
		search01.setSearchDiv("30");//제목
		search01.setSearchWord("강사");
		search01.setBoardDiv(10);
		
		List<BoardVO> list=(List<BoardVO>) boardDao.doRetrieve(search01);
		assertThat(list.size(), is(3));

	}
	
	@Test
	@Ignore
	public void doReadCnt() throws SQLException {
		//삭제
		//추가
		//doReadCnt
		//단건조회
		
		//삭제
		boardDao.doDelete(board01);
		boardDao.doDelete(board02);
		boardDao.doDelete(board03);		
		
		//입력
		int flag = boardDao.doInsert(board01);
		assertThat(flag, is(1));
		
		//doReadCnt
		flag = boardDao.doReadCnt(board01);
		assertThat(flag, is(1));
		
		//단건조회
		BoardVO vsBoare = (BoardVO) boardDao.doSelectOne(board01);
		
		assertThat(vsBoare.getReadCnt(), is(board01.getReadCnt()+1));
	}
	
	@Test
	@Ignore
	public void doUpdate() throws SQLException {
		LOG.debug("====================");
		LOG.debug("=doUpdate()=");
		LOG.debug("====================");		
		//삭제
		boardDao.doDelete(board01);
		boardDao.doDelete(board02);
		boardDao.doDelete(board03);		
		
		//입력
		int flag = boardDao.doInsert(board01);
		assertThat(flag, is(1));		
		
		board01.setTitle(board01.getTitle()+"_99");
		board01.setContents(board01.getContents()+"_99");
		board01.setModId(board01.getModId()+"_99");
		//board01.setReadCnt(board01.getReadCnt()+99);
		
		flag  = boardDao.doUpdate(board01);
		assertThat(flag, is(1));
		
		BoardVO vsBoard01 = (BoardVO) boardDao.doSelectOne(board01);
		checkBoard(vsBoard01, board01);
		
	}
	
	@Test
	public void addAndGet() throws Exception{
		LOG.debug("====================");
		LOG.debug("=addAndGet()=");
		LOG.debug("====================");
		//삭제
		boardDao.doDelete(board01);
		boardDao.doDelete(board02);
		boardDao.doDelete(board03);
		
		
		//입력
		int flag = boardDao.doInsert(board01);
		assertThat(flag, is(1));
		
		flag +=boardDao.doInsert(board02);
		assertThat(flag, is(2));
		
		flag +=boardDao.doInsert(board03);
		assertThat(flag, is(3));
		
		
		BoardVO vsBoard01 = (BoardVO) boardDao.doSelectOne(board01);
		
		BoardVO vsBoard02 = (BoardVO) boardDao.doSelectOne(board02);
		
		BoardVO vsBoard03 = (BoardVO) boardDao.doSelectOne(board03);
		
		checkBoard(vsBoard01,board01);
		checkBoard(vsBoard02,board02);
		checkBoard(vsBoard03,board03);
	}
	
	private void checkBoard(BoardVO vsBoard, BoardVO board01) {
		//비교
		assertThat(vsBoard.getSeq(), is(board01.getSeq()));
		assertThat(vsBoard.getTitle(), is(board01.getTitle()));
		assertThat(vsBoard.getContents(), is(board01.getContents()));	
		//컬럼추가:
		assertThat(vsBoard.getDiv(),is(board01.getDiv()));
		assertThat(vsBoard.getRegId(),is(board01.getRegId()));
		assertThat(vsBoard.getModId(),is(board01.getModId()));
		assertThat(vsBoard.getReadCnt(),is(board01.getReadCnt()));
		
		
	}	
	

	@After
	public void tearDown() throws Exception {
		
	}

	@Test
	public void beans() {
		LOG.debug("context:"+context);
		LOG.debug("boardDao:"+boardDao);
		assertThat(context, is(notNullValue()));
		assertThat(boardDao, is(notNullValue()));
	}

}
