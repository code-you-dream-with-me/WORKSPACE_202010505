package com.sist.ehr.board;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.sist.ehr.board.domain.BoardVO;
import com.sist.ehr.cmn.Search;
import com.sist.ehr.member.domain.User;
import com.sist.ehr.user.JTestUserController;
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class) //스프링 테스트 컨텍스트 프레임의 JUnit기능 확장
@ContextConfiguration(locations = {"file:src/main/webapp/WEB-INF/spring/root-context.xml",
                                   "file:src/main/webapp/WEB-INF/spring/appServlet/test-servlet-context.xml"
})
public class JTestBoardController {
	final Logger LOG = LoggerFactory.getLogger(JTestUserController.class);

	@Autowired
	WebApplicationContext webApplicationContext;

	// 브라우저 대신할 Mock
	MockMvc mockMvc;

	BoardVO board01;
	BoardVO board02;
	BoardVO board03;

	//검색
	Search search01;
	
	
	@Before
	public void setUp() throws Exception {
		board01 =new BoardVO(1241, "title_1241", "contents_1241", 0, "10", "강사", "", "eclass_2", "");
		board02 =new BoardVO(1242, "title_1242", "contents_1242", 0, "10", "강사", "", "eclass_2", "");
		board03 =new BoardVO(1243, "title_1243", "contents_1243", 0, "10", "강사", "", "eclass_2", "");
		
		search01=new Search("", "", 10, 1);	
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
	}
    
	@Test
	public void doRetrieve() throws Exception {
		// url호출, param전달
		MockHttpServletRequestBuilder createMessage = 
				MockMvcRequestBuilders.get("/board/do_retrieve.do")
				.param("searchDiv", search01.getSearchDiv())
				.param("searchWord", search01.getSearchWord())
				.param("pageSize", String.valueOf(search01.getPageSize()))
				.param("pageNum", String.valueOf(search01.getPageNum()))
				;				
		
		ResultActions resultActions =mockMvc.perform(createMessage)
				.andExpect(status().isOk());
		
		String result = resultActions.andDo(print())
		        .andReturn()
		        .getResponse().getContentAsString();	
				
				
	}
	
	@After
	public void tearDown() throws Exception {
	}

	
	
	
	@Test
	public void beans() {
		LOG.debug("webApplicationContext:" + webApplicationContext);
		LOG.debug("mockMvc:" + mockMvc);
		assertThat(webApplicationContext, is(notNullValue()));
		assertThat(mockMvc, is(notNullValue()));
	}

}
