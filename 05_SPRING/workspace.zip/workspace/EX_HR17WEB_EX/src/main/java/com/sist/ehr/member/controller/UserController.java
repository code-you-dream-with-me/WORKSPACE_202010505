package com.sist.ehr.member.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.LocaleResolver;

import com.google.gson.Gson;
import com.sist.ehr.cmn.DTO;
import com.sist.ehr.cmn.Message;
import com.sist.ehr.cmn.Search;
import com.sist.ehr.cmn.StringUtil;
import com.sist.ehr.code.domain.Code;
import com.sist.ehr.code.service.CodeService;
import com.sist.ehr.member.domain.User;
import com.sist.ehr.member.service.UserService;
/**
 * @RequestMapping("user")
 * @RequestMapping(value = "/id_check.do"
 * ---> user/id_check.do
 * @author sist
 *
 */
@Controller
@RequestMapping("user")
public class UserController {

	final Logger  LOG = LoggerFactory.getLogger(UserController.class);
	final String  VIEW_NAME = "user/user_mng";
	
	
	//locale
	@Autowired
	LocaleResolver  localeResolver;
	
	//message처리
	@Autowired
	MessageSource messageSource;
	
	
	
	@Autowired
	UserService  userService;
	
	   
	@Autowired
	CodeService  codeService;
	
	public UserController() {
		 
	}
	 
	@RequestMapping(value = "/do_change_locale.do",method = RequestMethod.GET)	
	public String changeLocale(@RequestParam("lang") String language
			,HttpServletRequest req,Model model) {
		LOG.debug("====================================");
		LOG.debug("lang:"+language);
		LOG.debug("====================================");
		
		Locale locale = Locale.KOREA;
		if("ko".equals(language)) {
			locale = Locale.KOREA;
		}else if("en".equals(language)) {
			locale = Locale.ENGLISH;
		}
		model.addAttribute("lang", language);
		
		localeResolver.setLocale(req, null, locale);
		return "login/login";      
	}
	
	
	@RequestMapping(value = "/id_check.do",method = RequestMethod.POST
			,produces = "application/json;charset=UTF-8")
	@ResponseBody	
	public Message idCheck(User user) throws SQLException {
		LOG.debug("====================================");
		LOG.debug("param:"+user);
		LOG.debug("====================================");		
		
		int flag = userService.idCheck(user);
		
		Message idCheckMessage=new Message();
		idCheckMessage.setMsgId(flag+"");
		
		if(1!=flag) {//ID있음
			idCheckMessage.setMsgContents(user.getuId()+"는 사용 하실수 있습니다.");
		}else {
			idCheckMessage.setMsgContents(user.getuId()+"는 사용 하실수 없습니다.");
		}
		
		return idCheckMessage;
	}
	
	/**
	 * jackson : Message to json으로 변환
	 * http://localhost:8080/ehr/user/do_login.do?uId=H_124_01&passwd=123499
	 * @param user
	 * @param session
	 * @return
	 * @throws SQLException
	 */
	@RequestMapping(value = "/do_login.do",method = RequestMethod.POST
			,produces = "application/json;charset=UTF-8")
	@ResponseBody
	public Message doLogin(User user, HttpSession session)throws SQLException {
		LOG.debug("====================================");
		LOG.debug("param:"+user);
		LOG.debug("====================================");
				
		Message loginMessage = userService.loginCheck(user);
		
		//아이디, 비번이 확인
		if("30".equals(loginMessage.getMsgId())) {
			
			//1. 단건조회
			//2. seesion에 User
			
			//1.
			User loginUser = (User) userService.doSelectOne(user);
			if(null !=loginUser) {
				loginMessage.setMsgContents(loginUser.getName()+"님 로그인 되었습니다.");
			}
			
			session.setAttribute("user", loginUser);
		}
		
		//Gson 불필요.
		
		
		
		return loginMessage;
	}
	
	@RequestMapping(value="/login_out.do",method = RequestMethod.GET)
	public String loginView(HttpSession session) throws SQLException {
		if(null != session.getAttribute("user")) {
			session.removeAttribute("user");
			session.invalidate();
		}
		LOG.debug("login_out.do");
		return "main/main";
	}
	
	
	@RequestMapping(value="/login_view.do",method = RequestMethod.GET)
	public String loginView(Model model) throws SQLException {
		
		LOG.debug("login_view.do");
		return "login/login";
	}
	
	
	@RequestMapping(value="/user_view.do",method = RequestMethod.GET)
	public String view(Model model,Locale locale) throws SQLException {
		//Message Read
		
		String tmpMessage = this.messageSource.getMessage("user.user_mng.idverification", null, locale);
		
		LOG.debug("====================================");
		LOG.debug("locale:"+locale);
		LOG.debug("tmpMessage:"+tmpMessage);
		LOG.debug("====================================");		
		
		
		List codeListParam = new ArrayList<String>();
		codeListParam.add("MEMBER_SEARCH");//회원검색
		codeListParam.add("COM_PAGE_SIZE");//페이지사이즈
		codeListParam.add("MEMBER_LEVEL");//회원등급
		
		List<Code> codeList = getCodePageRetrieve(codeListParam);
		
		List<Code> comPageSizeList = new ArrayList<Code>();
		List<Code> memberSearchList = new ArrayList<Code>();
		List<Code> memberLevelList = new ArrayList<Code>();
		
		for(Code vo  :codeList) {
			
			if(vo.getMstCode().equals("COM_PAGE_SIZE")) {
				comPageSizeList.add(vo);
			}
			
			if(vo.getMstCode().equals("MEMBER_SEARCH")) {
				memberSearchList.add(vo);
			}			
			
			if(vo.getMstCode().equals("MEMBER_LEVEL")) {
				memberLevelList.add(vo);
			}				
			
		}
		//LOG.debug(comPageSizeList.toString());   
		//페이지 사이즈 코드
        model.addAttribute("COM_PAGE_SIZE", comPageSizeList);
        model.addAttribute("MEMBER_SEARCH", memberSearchList);
        model.addAttribute("MEMBER_LEVEL", memberLevelList);
		return VIEW_NAME;
	}

	
	//View(jsp)에서 사용할 데이터를 설정하는 용도로도 사용 가능
	
	private List<?> getCodePageRetrieve(List<String> codeList) throws SQLException {
		Map<String,Object>  codeMap =new HashMap<String,Object>();
		codeMap.put("codeList",codeList);
		
		return codeService.getCodeRetrieve(codeMap);
	}
	
	
	//1. 브라우저에서 "user/do_retrieve.do" call
	//2. @ModelAttribute("member_search") 설정된 getCodeRetrieve()가 수행
	//3. public String doRetrieve(Search search) 메소드 수행
	//View(jsp)에서 사용할 데이터를 설정하는 용도로도 사용 가능
//	@ModelAttribute("member_search")
//	public List<?> getCodeRetrieve() throws SQLException {
//		Map<String,Object>  codeMap =new HashMap<String,Object>();
//		List codeList = new ArrayList<String>();
//		codeList.add("MEMBER_SEARCH");
//		codeMap.put("codeList",codeList);
//		
//		return codeService.getCodeRetrieve(codeMap);
//	}
	
	/**
	 * 회원 목록 조회
	 * @param dto
	 * @return JSON(User)
	 * @throws RuntimeException
	 * @throws SQLException 
	 */     
	@RequestMapping(value = "/do_retrieve.do",method = RequestMethod.GET
			,produces = "application/json;charset=UTF-8")
	@ResponseBody		
	public String doRetrieve(Search search) throws SQLException {
		LOG.debug("====================================");
		LOG.debug("param:"+search);
		LOG.debug("====================================");		
		
		//NVL처리 
		//검색구분
		search.setSearchDiv(StringUtil.nvl(search.getSearchDiv(),""));
		//검색어
		search.setSearchWord(StringUtil.nvl(search.getSearchWord(),""));
		
		//페이지 넘
		if(search.getPageNum()==0) {
			search.setPageNum(1);
		}
		
		//페이지 사이즈
		if(search.getPageSize()==0) {
			search.setPageSize(10);
		}
		   
		LOG.debug("====================================");
		LOG.debug("param_init:"+search);
		LOG.debug("====================================");			
		
		
		List<User> list = (List<User>) this.userService.doRetrieve(search);
		
		
		for(User vo:list) {
			LOG.debug(vo.toString());
		}
		
		//List to Json
		Gson gson=new Gson();
		
		String jsonList = gson.toJson(list);
		LOG.debug("====================================");
		LOG.debug("jsonList:"+jsonList);
		LOG.debug("====================================");				
		
		
		return jsonList;
	}
	
	/**
	 * 회원 단건 조회
	 * @param dto
	 * @return JSON(User)
	 * @throws RuntimeException
	 * @throws SQLException 
	 */     
	@RequestMapping(value = "/do_selectone.do",method = RequestMethod.GET
			,produces = "application/json;charset=UTF-8")
	@ResponseBody	
	public String doSelectOne(User user) throws SQLException {
		LOG.debug("====================================");
		LOG.debug("param:"+user);
		LOG.debug("====================================");
		
		User  outVO = (User) this.userService.doSelectOne(user);
		LOG.debug("====================================");
		LOG.debug("outVO:"+outVO);
		LOG.debug("====================================");		
		
		
		Gson  gson=new Gson();
		String jsonStr = gson.toJson(outVO);
		LOG.debug("====================================");
		LOG.debug("jsonStr:"+jsonStr);
		LOG.debug("====================================");		
		return jsonStr;
	}
	
	/**
	 * 회원 삭제
	 * @param dto
	 * @return JSON(1:성공,0:실패)
	 * @throws RuntimeException
	 * @throws SQLException 
	 */     
	@RequestMapping(value = "/do_delete.do",method = RequestMethod.POST
			,produces = "application/json;charset=UTF-8")
	@ResponseBody	
	public String doDelete(User user,Locale locale) throws SQLException {
		LOG.debug("====================================");
		LOG.debug("param:"+user);
		LOG.debug("====================================");
		int flag = this.userService.doDelete(user);
		String resultMsg = "";
		if(1==flag) {
			//삭제
			String doDelete =messageSource.getMessage("user.cmn.dodelete", null, locale);
			
			Object[] param = new String[]{doDelete};
			//{0} 되었습니다. -> {삭제} 되었습니다.
			String doDeleteMsg =messageSource.getMessage("user.cmn.message", param, locale);
			
			resultMsg = user.getuId()+"님\n"+doDeleteMsg;
		}else {
			resultMsg = "삭제 실패.";
		}     
		
		Message message=new Message();
		message.setMsgId(flag+"");
		message.setMsgContents(resultMsg);
		
		Gson  gson=new Gson();
		String jsonStr = gson.toJson(message);
		LOG.debug("====================================");
		LOG.debug("jsonStr:"+jsonStr);
		LOG.debug("====================================");		
		return jsonStr;
	}
	
	
	/**
	 * 회원 수정
	 * @param dto
	 * @return JSON(1:성공,0:실패)
	 * @throws RuntimeException
	 * @throws SQLException 
	 */     
	@SuppressWarnings("deprecation")
	@RequestMapping(value = "/do_update.do",method = RequestMethod.POST
			,produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ResponseBody       
	public String doUpdate(User user) throws SQLException {
		LOG.debug("====================================");
		LOG.debug("param:"+user);
		LOG.debug("====================================");		
		
		int flag = this.userService.doUpdate(user);
		String resultMsg = "";
		if(1 == flag) {
			resultMsg = user.getName()+"님\n수정 성공.";
		}else {
			resultMsg = user.getName()+"님\n수정 실패.";
		}
		
		Message message=new Message();
		message.setMsgId(flag+"");
		message.setMsgContents(resultMsg);
		
		Gson  gson=new Gson();
		String jsonStr = gson.toJson(message);
		LOG.debug("====================================");
		LOG.debug("jsonStr:"+jsonStr);
		LOG.debug("====================================");		
		return jsonStr;
	}
	
	
	/**
	 * 회원 등록
	 * @param dto
	 * @return JSON(1:성공,0:실패)
	 * @throws RuntimeException
	 * @throws SQLException 
	 */     
	@RequestMapping(value = "/do_insert.do",method = RequestMethod.POST
			,produces = "application/json;charset=UTF-8")
	@ResponseBody       
	public String doInsert(User user,Locale locale) throws SQLException  {
		  
		LOG.debug("====================================");
		LOG.debug("param:"+user);
		LOG.debug("====================================");
		
		
		if(null == user.getName()||user.getName().equals("")) {
			LOG.debug("user.getName():"+user.getName());
			throw new NullPointerException("이름을 입력 하세요.");
		}
		
		
		  
		int flag = userService.add(user);
		
		
		String resultMsg = "";
		if(1==flag) {
			String doInsert =messageSource.getMessage("user.cmn.doinsert", null, locale);
			LOG.debug("doInsert:"+doInsert);
			
			Object[] param = new String[]{doInsert};

			LOG.debug("param[0]:"+param[0]);
			String doInsertMsg =messageSource.getMessage("user.cmn.message", param, locale);
			
			LOG.debug("====================================");
			LOG.debug("doInsert:"+doInsert);
			
			
			
			resultMsg = user.getName()+"님\n"+doInsertMsg;
			LOG.debug("doInsertMsg:"+doInsertMsg);
			LOG.debug("resultMsg:"+resultMsg);
			LOG.debug("====================================");	
		}else {
			resultMsg = "등록 실패.";
		}       
		
		Message message=new Message();
		message.setMsgId(flag+"");
		message.setMsgContents(resultMsg);
		
		Gson  gson=new Gson();
		String jsonStr = gson.toJson(message);
		LOG.debug("====================================");
		LOG.debug("jsonStr:"+jsonStr);
		LOG.debug("====================================");		
		return jsonStr;
	}
}

