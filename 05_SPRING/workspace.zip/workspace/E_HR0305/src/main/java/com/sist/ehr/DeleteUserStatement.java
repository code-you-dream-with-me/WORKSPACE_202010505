package com.sist.ehr;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;

public class DeleteUserStatement implements StatementStrategy {
	final static Logger LOG = Logger.getLogger(DeleteUserStatement.class);
	
	User user;
	
	public DeleteUserStatement() {}
	
	public DeleteUserStatement(User user) {
		super();
		this.user = user;
	}


	@Override
	public PreparedStatement makeStatement(Connection connection) throws SQLException {
		PreparedStatement ps = null;
		StringBuffer sb=new StringBuffer(200);
		sb.append(" DELETE FROM hr_member \n");
		sb.append(" WHERE  u_id = ?       \n");
		LOG.debug("=sql=\n"+sb.toString());
				
		ps = connection.prepareStatement(sb.toString());
		LOG.debug("=ps="+ps);
		ps.setString(1, user.getuId());
		
		
		return ps; 
	}

}
