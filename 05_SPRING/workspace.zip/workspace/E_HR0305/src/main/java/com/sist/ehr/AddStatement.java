package com.sist.ehr;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;

public class AddStatement implements StatementStrategy {
    final Logger LOG = Logger.getLogger(AddStatement.class);
    
    User user;
    public AddStatement() {
    	
    }
    
	public AddStatement(User user) {
		super();
		this.user = user;
	}



	@Override
	public PreparedStatement makeStatement(Connection connection) throws SQLException {
		StringBuffer sb=new StringBuffer(200);
		sb.append(" INSERT INTO hr_member (  \n");
		sb.append("     u_id,                \n");
		sb.append("     name,                \n");
		sb.append("     passwd               \n");
		sb.append(" ) VALUES (               \n");
		sb.append("     ?,                   \n");
		sb.append("     ?,                   \n");
		sb.append("     ?                    \n");
		sb.append(" )                        \n");	
		LOG.debug("=sql=\n"+sb.toString());
		PreparedStatement pstmt = connection.prepareStatement(sb.toString());
		LOG.debug("=============================");
		LOG.debug("=pstmt="+pstmt);
		LOG.debug("=============================");			
		
		pstmt.setString(1, user.getuId());
		pstmt.setString(2, user.getName());
		pstmt.setString(3, user.getPasswd());		
		
		return pstmt;
	}

}
