package com.sist.ehr;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.dao.EmptyResultDataAccessException;

public class UserDao {
	final static Logger LOG = Logger.getLogger(UserDao.class);
	DataSource dataSource;
	
	public UserDao() {}
	
	
	//setter를 통한 주입
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
  
	/**
	 * 등록 건수 조회
	 * @param user
	 * @return int
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public int count(User user)throws ClassNotFoundException,SQLException{
		int cnt = 0;
		
		Connection connection = dataSource.getConnection();
		LOG.debug("=============================");
		LOG.debug("=connection="+connection);
		LOG.debug("=============================");
		
		StringBuffer sb=new StringBuffer(200);	
		sb.append("  SELECT COUNT(*) cnt      \n");
		sb.append("  FROM hr_member           \n");
		sb.append("  WHERE U_ID LIKE ? ||'%'  \n");		
		LOG.debug("=============================");
		LOG.debug("=sql=\n"+sb.toString());
		LOG.debug("=param=\n"+user);
		LOG.debug("=============================");	
		PreparedStatement pstmt =  connection.prepareStatement(sb.toString());
		pstmt.setString(1, user.getuId());
		ResultSet rs = pstmt.executeQuery();
		if(rs.next()) {
			cnt = rs.getInt("cnt");
		}
		LOG.debug("=============================");
		LOG.debug("=cnt="+cnt);
		LOG.debug("=============================");			
		//자원반납
		rs.close();
		pstmt.close();
		connection.close();
		
		return cnt;
	}
	

	public int jdbcContextWidthStatmentStrategy(StatementStrategy stmt) throws SQLException {
		int flag = 0;
		Connection connection   = null;
		PreparedStatement pstmt = null;
		LOG.debug("=============================");
		LOG.debug("=connection="+connection);
		LOG.debug("=============================");	
		//자원반납
		try {
			connection = dataSource.getConnection();
			pstmt      = stmt.makeStatement(connection);
			
			flag = pstmt.executeUpdate();
		}catch(SQLException e) {
			throw e;
		}finally {
			if(null != pstmt) {
				try {
					pstmt.close();
				}catch(SQLException e) {
					
				}
			}
			
			if(null != connection) {
				try {
					connection.close();
				}catch(SQLException e) {
					
				}
			}
			
			
		}
		LOG.debug("=============================");
		LOG.debug("=flag="+flag);
		LOG.debug("=============================");	
		return flag;		
	}

	
	
	public int deleteUser(User user)throws ClassNotFoundException,SQLException{
		
		StatementStrategy strategy=new DeleteUserStatement(user);
		
		int flag = jdbcContextWidthStatmentStrategy(strategy);
		
		return flag;
	}
	

	/**
	 * 등록
	 * @param user
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public int add(User user)throws ClassNotFoundException,SQLException{
		int flag = 0;
		StatementStrategy  strategy = new AddStatement(user);
		flag = jdbcContextWidthStatmentStrategy(strategy);
		
		return flag;
	}



	/**
	 * 단건조회
	 * @param id
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public User get(String id)throws ClassNotFoundException,SQLException{
		//A  1. DB연결을 위한 Connection:
		
		//B  2. SQL을 담은 Statement, PreparedStatement
		//B  3. PreparedStatement를 수행
		//B  4. 조회의 경우 ResultSet으로  정보를 받아와 User Object에 저장
		
		//C  5. 자원 반납 Connection,PreparedStatement,ResultSet close()
		//* 예외가 발생하면 예외는 밖으로 throw한다.
		User outVO = null;
		
		Connection connection = dataSource.getConnection();
		LOG.debug("=============================");
		LOG.debug("=connection="+connection);
		LOG.debug("=============================");
		
		StringBuffer sb=new StringBuffer(200);	
		sb.append(" SELECT               \n");
		sb.append("     u_id,            \n");
		sb.append("     name,            \n");
		sb.append("     passwd           \n");
		sb.append(" FROM                 \n");
		sb.append("     hr_member        \n");
		sb.append(" WHERE   u_id = ?     \n");		
		LOG.debug("=============================");
		LOG.debug("=sql=\n"+sb.toString());
		LOG.debug("=param=\n"+id);
		LOG.debug("=============================");	
		
		PreparedStatement pstmt =  connection.prepareStatement(sb.toString());
		pstmt.setString(1, id);
		
		ResultSet rs = pstmt.executeQuery();
		if(rs.next()) {
			outVO = new User();
			outVO.setuId(rs.getString("u_id"));
			outVO.setName(rs.getString("name"));
			outVO.setPasswd(rs.getString("passwd"));
		}
		
		LOG.debug("=============================");
		LOG.debug("=outVO="+outVO);
		LOG.debug("=============================");
		
		//자원반납
		rs.close();
		pstmt.close();
		connection.close();
		
		if(null == outVO) {
			throw new EmptyResultDataAccessException(1);
		}
		
		
		
		return outVO;
	}
}
