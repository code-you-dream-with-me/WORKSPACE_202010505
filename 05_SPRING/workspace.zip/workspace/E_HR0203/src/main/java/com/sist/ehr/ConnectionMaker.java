package com.sist.ehr;

import java.sql.Connection;
import java.sql.SQLException;

public interface ConnectionMaker {
	/**
	 * Connection 생성구조 정의
	 * @return Connection
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public Connection makeConnection()throws ClassNotFoundException,SQLException;
	
}
