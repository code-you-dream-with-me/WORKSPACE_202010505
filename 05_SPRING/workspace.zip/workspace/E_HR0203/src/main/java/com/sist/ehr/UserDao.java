package com.sist.ehr;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

public class UserDao {
	final static Logger LOG = Logger.getLogger(UserDao.class);
	ConnectionMaker connectionMaker;
	
	public UserDao(ConnectionMaker connectionMaker) {
		this.connectionMaker = connectionMaker;
	}

	/**
	 * 등록
	 * @param user
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public int add(User user)throws ClassNotFoundException,SQLException{
		//1. DB연결을 위한 Connection
		//2. SQL을 담은 Statement, PreparedStatement
		//3. PreparedStatement를 수행
		//4. 조회의 경우 ResultSet으로  정보를 받아와 User Object에 저장
		//5. 자원 반납 Connection,PreparedStatement,ResultSet close()
		//* 예외가 발생하면 예외는 밖으로 throw한다.
		
		
		Connection connection = connectionMaker.makeConnection();
		LOG.debug("=============================");
		LOG.debug("=connection="+connection);
		LOG.debug("=============================");
		
		StringBuffer sb=new StringBuffer(200);
		sb.append(" INSERT INTO hr_member (  \n");
		sb.append("     u_id,                \n");
		sb.append("     name,                \n");
		sb.append("     passwd               \n");
		sb.append(" ) VALUES (               \n");
		sb.append("     ?,                   \n");
		sb.append("     ?,                   \n");
		sb.append("     ?                    \n");
		sb.append(" )                        \n");		
		LOG.debug("=============================");
		LOG.debug("=sql=\n"+sb.toString());
		LOG.debug("=param=\n"+user.toString());
		LOG.debug("=============================");		
		
		PreparedStatement pstmt = connection.prepareStatement(sb.toString());
		LOG.debug("=============================");
		LOG.debug("=pstmt="+pstmt);
		LOG.debug("=============================");			
		
		pstmt.setString(1, user.getuId());
		pstmt.setString(2, user.getName());
		pstmt.setString(3, user.getPasswd());
		
		int flag = pstmt.executeUpdate();
		LOG.debug("=============================");
		LOG.debug("=flag="+flag);
		LOG.debug("=============================");		
		
		//자원반납
		pstmt.close();
		connection.close();
		
		return flag;
	}

	
	/**
	 * 단건조회
	 * @param id
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public User get(String id)throws ClassNotFoundException,SQLException{
		//A  1. DB연결을 위한 Connection:
		
		//B  2. SQL을 담은 Statement, PreparedStatement
		//B  3. PreparedStatement를 수행
		//B  4. 조회의 경우 ResultSet으로  정보를 받아와 User Object에 저장
		
		//C  5. 자원 반납 Connection,PreparedStatement,ResultSet close()
		//* 예외가 발생하면 예외는 밖으로 throw한다.
		User outVO = null;
		
		
		
		Connection connection = connectionMaker.makeConnection();
		LOG.debug("=============================");
		LOG.debug("=connection="+connection);
		LOG.debug("=============================");
		
		StringBuffer sb=new StringBuffer(200);	
		sb.append(" SELECT               \n");
		sb.append("     u_id,            \n");
		sb.append("     name,            \n");
		sb.append("     passwd           \n");
		sb.append(" FROM                 \n");
		sb.append("     hr_member        \n");
		sb.append(" WHERE   u_id = ?     \n");		
		LOG.debug("=============================");
		LOG.debug("=sql=\n"+sb.toString());
		LOG.debug("=param=\n"+id);
		LOG.debug("=============================");	
		
		PreparedStatement pstmt =  connection.prepareStatement(sb.toString());
		pstmt.setString(1, id);
		
		ResultSet rs = pstmt.executeQuery();
		if(rs.next()) {
			outVO = new User();
			outVO.setuId(rs.getString("u_id"));
			outVO.setName(rs.getString("name"));
			outVO.setPasswd(rs.getString("passwd"));
		}
		
		LOG.debug("=============================");
		LOG.debug("=outVO="+outVO);
		LOG.debug("=============================");			
		//자원반납
		rs.close();
		pstmt.close();
		connection.close();
		
		return outVO;
	}
}
