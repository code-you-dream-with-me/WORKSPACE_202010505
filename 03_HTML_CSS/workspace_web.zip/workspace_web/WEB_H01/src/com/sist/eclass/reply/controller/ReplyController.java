package com.sist.eclass.reply.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.sist.eclass.board.controller.BoardController;
import com.sist.eclass.cmn.MessageVO;
import com.sist.eclass.cmn.StringUtil;
import com.sist.eclass.reply.domain.ReplyVO;
import com.sist.eclass.reply.service.ReplyService;

/**
 * Servlet implementation class ReplyController
 */
@WebServlet(description = "댓글", urlPatterns = { "/reply/reply.do" })
public class ReplyController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    final Logger LOG = Logger.getLogger(ReplyController.class);   
    
	ReplyService  replyService;   
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ReplyController() {
        super();
        replyService = new ReplyService();
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//request에 들어오는 encoding 일괄로 UTF-8
		request.setCharacterEncoding("UTF-8");
		String workDiv = StringUtil.nvl(request.getParameter("word_div"),"doRetrieve");
		LOG.debug("------------------------");
		LOG.debug("-workDiv-"+workDiv);
		LOG.debug("------------------------");
		switch(workDiv) {
		case "doInsert"://등록
			doInsert(request,response);	
			break;
		case "doDelete"://등록
			doDelete(request,response);	
			break;	
			
		case "replySelectList"://등록
			replySelectList(request,response);	
			break;				
		}	
		
	}
	
	public void replySelectList(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		String seq = StringUtil.nvl(request.getParameter("seq"),"-1");

		
		ReplyVO reply=new ReplyVO();
		reply.setSeq(Integer.parseInt(seq));		
		LOG.debug("-seq:"+seq);
		LOG.debug("--reply-"+reply);		
		
		List<ReplyVO> reply_list = (List<ReplyVO>)this.replyService.doRetrieve(reply);
		
		Gson gson=new Gson();
		String jsonString = gson.toJson(reply_list);
		
		//VO to JSON
		LOG.debug("--jsonString-"+jsonString);		
			
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out= response.getWriter();
		out.print(jsonString);			
	}
	
	
	public void doDelete(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		LOG.debug("------------------------");
		LOG.debug("-doDelete");	
		String repSeq           = StringUtil.nvl(request.getParameter("repSeq"),"-1");
		ReplyVO  param=new ReplyVO();
		param.setRepSeq(Integer.parseInt(repSeq));
		LOG.debug("------------------------");			
		int flag = replyService.doDelete(param);
		
		//메시지
		MessageVO  msgVO=new MessageVO();
		msgVO.setMsgId(String.valueOf(flag));
		
		String msg = "";
		if(1==flag) {
			msg = "댓글 삭제 성공";
		}else {
			msg = "댓글 삭제 실패";
		}
		
		msgVO.setMsgContents(msg);
		
		//메시지 to json
		Gson  gson=new Gson();
		String jsonString = gson.toJson(msgVO);
		LOG.debug("-jsonString:"+jsonString);
		
		//화면에 message전달
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out= response.getWriter();
		out.print(jsonString);		
	}	
	
	public void doInsert(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		LOG.debug("------------------------");
		LOG.debug("-doInsert");	
		String seq           = StringUtil.nvl(request.getParameter("seq"),"-1");
		String repContents   = StringUtil.nvl(request.getParameter("rep_contents"),"");
		
		
		ReplyVO  param=new ReplyVO();
		param.setSeq(Integer.parseInt(seq));
		param.setRepContents(repContents);
		param.setRegId("Admin");
		LOG.debug("-param:"+param);
		
		LOG.debug("------------------------");			
		int flag = replyService.doInsert(param);
		
		//메시지
		MessageVO  msgVO=new MessageVO();
		msgVO.setMsgId(String.valueOf(flag));
		
		String msg = "";
		if(1==flag) {
			msg = "댓글 등록 성공";
		}else {
			msg = "댓글 등록 실패";
		}
		
		msgVO.setMsgContents(msg);
		
		//메시지 to json
		Gson  gson=new Gson();
		String jsonString = gson.toJson(msgVO);
		LOG.debug("-jsonString:"+jsonString);
		
		//화면에 message전달
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out= response.getWriter();
		out.print(jsonString);		
	}
	
	
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
