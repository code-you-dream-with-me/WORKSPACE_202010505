/**
* <pre>
* com.sist.eclass.member.service
* Class Name : MemberService.java
* Description:
* Author: sist
* Since: 2021/03/11
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2021/03/11 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.member.service;

import java.util.List;

import org.apache.log4j.Logger;

import com.sist.eclass.board.servie.BoardService;
import com.sist.eclass.cmn.DTO;
import com.sist.eclass.cmn.MessageVO;
import com.sist.eclass.member.dao.MemberDao;
import com.sist.eclass.member.domain.MemberVO;
import com.sist.eclass.member.domain.SexsualVO;

/**
 * @author sist
 *
 */
public class MemberService {
	private final Logger LOG = Logger.getLogger(MemberService.class);
	private MemberDao dao;
	
	public MemberService() {
		dao = new MemberDao();
	}
	
	public List<SexsualVO> sexsualRatio(){
		return dao.sexsualRatio();
	}
	
	/**
	 * 아이디 비번 확인
	 * @param dto
	 * @return MessageVO
	 */
	public MessageVO doLoginCheck(DTO dto) {
		MessageVO message=new MessageVO();
		
		MemberVO  param  = (MemberVO) dto;
		LOG.debug("param:"+param);
		//id체크
		//비번체크
		
		int idCheckFlag =  dao.idCheck(param);
		if(1 != idCheckFlag) {
			message.setMsgId("10");//ID 없음!
			message.setMsgContents("아이디를 확인 하세요.");
			return message;
		}
		
		
		int passwordCheckFlag = dao.passwordCheck(param);
		if(1 != passwordCheckFlag) {
			message.setMsgId("20");//ID 없음!
			message.setMsgContents("비번을 확인 하세요.");
			return message;
		}
		
		message.setMsgId("0");
		message.setMsgContents("아이디와 비번이 확인 되었습니다.");
		
		
		return message;
	}
	
	public List<?> doRetrieve(DTO param) {
		return dao.doRetrieve(param);
	}
	
	public DTO doTotalCnt(DTO param) {
		return dao.doTotalCnt(param);
	}
	
	public int doUpdate(DTO param) {
		return dao.doUpdate(param);
	}
	/**
	 * 회원 단건 조회
	 * @param param
	 * @return
	 */
	public DTO doSelectOne(DTO param) {
		return dao.doSelectOne(param);
	}
	
	
	public int doInsert(DTO param) {
		return dao.doInsert(param);
	}
	
	public int doDelete(DTO param) {
		return dao.doDelete(param);
	}
	
	
	
	
	
	
	
	
}
