/**
* <pre>
* com.sist.eclass.reply.service
* Class Name : ReplyService.java
* Description:
* Author: HB
* Since: 2021/03/14
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2021/03/14 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.reply.service;

import java.util.List;

import org.apache.log4j.Logger;

import com.sist.eclass.board.dao.BoardDao;
import com.sist.eclass.board.domain.BoardVO;
import com.sist.eclass.board.servie.BoardService;
import com.sist.eclass.cmn.DTO;
import com.sist.eclass.reply.dao.ReplyDao;
import com.sist.eclass.reply.domain.ReplyVO;

/**
 * @author HB
 *
 */
public class ReplyService {
	private final Logger LOG = Logger.getLogger(ReplyService.class);
	private ReplyDao dao;
	
	
	public ReplyService() {
		dao = new ReplyDao();
		
	}
	
	public List<?> doRetrieve(DTO param){
		return dao.doRetrieve(param);
	}
	
	/**
	 * 수정
	 * @param param 
	 * @return 성공:1, 실패:0
	 */
	public int doUpdate(DTO param) {
		return dao.doUpdate(param);
	}
	
	/**
	 * 게시글 삭제
	 * @param param
	 * @return 성공:1, 실패:0
	 */
	public int doDelete(DTO param) {
		return dao.doDelete(param);
	}	
	
	
	/**
	 * 게시글 등록
	 * @param param
	 * @return 성공:1, 실패:0
	 */
	public int doInsert(DTO param) {
		return dao.doInsert(param);
	}	
	
	/**
	 * 단건조회 + 조회Count증가 
	 * @param param
	 * @return
	 */
	public DTO doSelectOne(DTO param) {
		return dao.doSelectOne(param);
	}	
}
