/**
* <pre>
* com.sist.eclass.cmn.search.domain
* Class Name : SearchVO.java
* Description: 검색(구분, 검색어,pageSize,pageNum)
* Author: sist
* Since: 2021/02/22
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2021/02/22 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.cmn.search.domain;

import com.sist.eclass.cmn.DTO;

/**
 * @author sist
 *
 */
public class SearchVO extends DTO {

	private String searchDiv;//검색구분
	private String searchWord;//검색어
	
	private int pageSize;//10,20,30,50,100
	private int pageNum;//1,2,3,........
	
	private String div;//10,20(게시 구분)
	
	
	
	public SearchVO() {
	
	}


	public SearchVO(String searchDiv, String searchWord, int pageSize, int pageNum,String div) {
		super();
		this.searchDiv = searchDiv;
		this.searchWord = searchWord;
		this.pageSize = pageSize;
		this.pageNum = pageNum;
		this.div     = div;
	}


	public String getSearchDiv() {
		return searchDiv;
	}


	public void setSearchDiv(String searchDiv) {
		this.searchDiv = searchDiv;
	}


	public String getSearchWord() {
		return searchWord;
	}


	public void setSearchWord(String searchWord) {
		this.searchWord = searchWord;
	}


	public int getPageSize() {
		return pageSize;
	}


	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}


	public int getPageNum() {
		return pageNum;
	}


	public void setPageNum(int pageNum) {
		this.pageNum = pageNum;
	}


	public String getDiv() {
		return div;
	}


	public void setDiv(String div) {
		this.div = div;
	}


	@Override
	public String toString() {
		return "SearchVO [searchDiv=" + searchDiv + ", searchWord=" + searchWord + ", pageSize=" + pageSize
				+ ", pageNum=" + pageNum + ", div=" + div + ", toString()=" + super.toString() + "]";
	}



	
	
}



