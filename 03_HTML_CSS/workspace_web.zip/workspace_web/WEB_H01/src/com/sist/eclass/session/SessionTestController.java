package com.sist.eclass.session;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.sist.eclass.board.controller.BoardController;
import com.sist.eclass.cmn.MessageVO;
import com.sist.eclass.cmn.StringUtil;
import com.sist.eclass.member.domain.MemberVO;
import com.sist.eclass.member.service.MemberService;

/**
 * Servlet implementation class SessionTestController
 */
@WebServlet(description = "세션테스트", urlPatterns = { "/session/session.do" })
public class SessionTestController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	final Logger LOG = Logger.getLogger(SessionTestController.class);
	
	private MemberService service;
	
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SessionTestController() {
        super();
        service = new MemberService();
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		
		String workDiv =StringUtil.nvl(request.getParameter("work_div"),"login");
		LOG.debug("------------------------");
		LOG.debug("-workDiv:"+workDiv);		
		LOG.debug("------------------------");		
		switch(workDiv) {
		case "login":
			login(request,response);
			break;
			
		case "logout":
			logout(request,response);
			break;
			
		}
	}
	
	protected void logout(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		if(null !=session && null != session.getAttribute("memberInfo")) {
			//session삭제
			session.invalidate();
		}
		
		RequestDispatcher  dispatcher= request.getRequestDispatcher("/session/login_result.jsp");
		dispatcher.forward(request, response);		
		
	}
	

	protected void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LOG.debug("------------------------");
		LOG.debug("-login");		
		
		String userId =StringUtil.nvl(request.getParameter("user_id"),"");
		String passwd =StringUtil.nvl(request.getParameter("passwd"),"");
		LOG.debug("-userId:"+userId);
		LOG.debug("-passwd:"+passwd);
		
		MemberVO  inVO =new MemberVO();
		inVO.setMemberId(userId);
		inVO.setPasswd(passwd);
		LOG.debug("-inVO:"+inVO);
		LOG.debug("------------------------");		
		MessageVO message = service.doLoginCheck(inVO);
		
		//id와 비번 존재: 
		if(message.getMsgId().equals("0")) {
			MemberVO  loginMember = (MemberVO) service.doSelectOne(inVO);
			HttpSession seesion = request.getSession();
			seesion.setAttribute("memberInfo", loginMember);
		}
		
		//message화면에 전달
		request.setAttribute("message", message);

		
		RequestDispatcher  dispatcher= request.getRequestDispatcher("/session/login_result.jsp");
		dispatcher.forward(request, response);
		
	}
	
	
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
