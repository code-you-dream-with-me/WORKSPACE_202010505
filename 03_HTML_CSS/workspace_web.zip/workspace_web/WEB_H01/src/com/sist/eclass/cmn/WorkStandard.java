/**
* <pre>
* com.sist.eclass.board.domain
* Class Name : WorkStandard.java
* Description:
* Author: sist
* Since: 2021/02/18
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2021/02/18 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.cmn;

import java.util.List;

import com.sist.eclass.board.domain.BoardVO;

/**
 * @author sist
 *
 */
public interface WorkStandard {

	/**
	 * 목록 조회 
	 * @return
	 */
	List<?> doRetrieve(DTO param);

	/**
	 * 수정
	 * @param param
	 * @return 성공:1, 실패:0
	 */
	int doUpdate(DTO param);

	/**
	 * 단건조회 
	 * @param param
	 * @return BoardVO
	 */
	DTO doSelectOne(DTO param);

	/**
	 * 게시글 삭제
	 * @param param
	 * @return 성공:1, 실패:0
	 */
	int doDelete(DTO param);

	/**
	 * 게시글 등록
	 * @param param
	 * @return 성공:1, 실패:0
	 */
	int doInsert(DTO param);

}