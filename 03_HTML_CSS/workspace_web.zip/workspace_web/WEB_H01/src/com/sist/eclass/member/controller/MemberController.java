package com.sist.eclass.member.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.sist.eclass.board.controller.BoardController;
import com.sist.eclass.cmn.MessageVO;
import com.sist.eclass.cmn.StringUtil;
import com.sist.eclass.cmn.search.domain.SearchVO;
import com.sist.eclass.member.domain.MemberVO;
import com.sist.eclass.member.domain.SexsualVO;
import com.sist.eclass.member.service.MemberService;

/**
 * Servlet implementation class MemberController
 */
@WebServlet(
		description = "회원관리", 
		urlPatterns = { 
				"/member/member.do", 
				"/login/login.do"
		})
public class MemberController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private MemberService  memberService;
	final Logger LOG = Logger.getLogger(MemberController.class);
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MemberController() {
        super();
        memberService = new MemberService();
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String workDiv = StringUtil.nvl(request.getParameter("work_div"),"doRetrieve");
		LOG.debug("------------------------");
		LOG.debug("-workDiv-"+workDiv);
		LOG.debug("------------------------");
		switch(workDiv) {
			case "login":
				login(request,response);
				break;
				
			case "logout":
				logout(request,response);
				break;
			
			case "doRetrieve"://조회
				doRetrieve(request,response);	
				break;
				
			case "doSelectOne"://단건조회
				doSelectOne(request,response);	
				break;	
				
			case "doDelete"://삭제
				doDel(request,response);	
				break;			
				
			case "doUpdate"://수정
				doUpdate(request,response);	
				break;	
				
			case "doInsert"://등록
				doInsert(request,response);	
				break;		
			case "sexsualRatio"://남여비율
				sexsualRatio(request,response);	
				break;		
		}
	}
	
	protected void sexsualRatio(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LOG.debug("------------------------");
		LOG.debug("-sexsualRatio");	
		LOG.debug("------------------------");
		/*
		  ['여', 11],
          ['남', 5]
		 */
		List<SexsualVO> list = this.memberService.sexsualRatio();
		LOG.debug("------------------------");
		LOG.debug("-list"+list);	
		LOG.debug("------------------------");		
		
		Gson gson=new Gson();
		JsonArray  jArray=new JsonArray();
		
		for(SexsualVO vo:list) {
			JsonArray  cArray=new JsonArray();
			cArray.add(vo.getSex());
			cArray.add(vo.getCnt());
			
			//LOG.debug("-cArray"+cArray.toString());
			jArray.add(cArray);
		}
		
		//LOG.debug("-jArray"+jArray.toString());//jArray[["남",3],["여",8]]
		String gsonString = jArray.toString();
		LOG.debug("-gsonString"+gsonString);	
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter  out = response.getWriter();
		out.print(gsonString);			
	}
	
	
	protected void logout(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		if(null !=session && null != session.getAttribute("memberInfo")) {
			//session삭제
			session.invalidate();
		}
		
		RequestDispatcher  dispatcher= request.getRequestDispatcher("/main/main.jsp");
		dispatcher.forward(request, response);		
		
	}
	
	protected void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LOG.debug("------------------------");
		LOG.debug("-login");		
		
		String userId =StringUtil.nvl(request.getParameter("user_id"),"");
		String passwd =StringUtil.nvl(request.getParameter("passwd"),"");
		LOG.debug("-userId:"+userId);
		LOG.debug("-passwd:"+passwd);
		
		MemberVO  inVO =new MemberVO();
		inVO.setMemberId(userId);
		inVO.setPasswd(passwd);
		LOG.debug("-inVO:"+inVO);
		LOG.debug("------------------------");		
		MessageVO message = memberService.doLoginCheck(inVO);
		
		
		MemberVO  loginMember = null;
		String messageStr = "";		
		//id와 비번 존재: 
		if(message.getMsgId().equals("0")) {
			loginMember = (MemberVO) memberService.doSelectOne(inVO);
			HttpSession seesion = request.getSession();
			seesion.setAttribute("memberInfo", loginMember);
			
			messageStr = loginMember.getName()+"이 회원 로그인 되었습니다.";

		}else {
			messageStr = message.getMsgContents();
		}

		message.setMsgContents(messageStr);
		
		Gson gson=new Gson();
		
		String gsonString = gson.toJson(message);
		
		
		LOG.debug("-gsonString-"+gsonString);		
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter  out = response.getWriter();
		out.print(gsonString);		

		
	}
	
	protected void doInsert(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LOG.debug("------------------------");
		LOG.debug("-doInsert-");
		LOG.debug("------------------------");	
		
		
		String memberId  =StringUtil.nvl(request.getParameter("member_id"),"");
		String name  =StringUtil.nvl(request.getParameter("name"),"");
		String passwd  =StringUtil.nvl(request.getParameter("passwd"),"");
		String email  =StringUtil.nvl(request.getParameter("email"),"");
		String cellPhone  =StringUtil.nvl(request.getParameter("cell_phone"),"");
		String sex  =StringUtil.nvl(request.getParameter("sex"),"");
		String auth  =StringUtil.nvl(request.getParameter("auth"),"");
		
		
		MemberVO  param = new MemberVO();
		param.setMemberId(memberId);		
		param.setName(name);
		param.setPasswd(passwd);
		param.setEmail(email);
		param.setCellPhone(cellPhone);
		param.setSex(sex);
		param.setAuth(auth);
		param.setModId("Admin");
		param.setRegId("Admin");
		//TO-do
		//--session처리 

		LOG.debug("-param-"+param);		
		
		
		int flag = this.memberService.doInsert(param);
		
		MessageVO  messageVO = new MessageVO();
		String message = "";
		if(1==flag) {
			message = param.getName()+"이 회원 등록 되었습니다.";
		}else {
			message = "등록 실패";
		}
		messageVO.setMsgContents(message);
		messageVO.setMsgId(String.valueOf(flag));
		
		Gson gson=new Gson();
		
		String gsonString = gson.toJson(messageVO);
		
		
		LOG.debug("-gsonString-"+gsonString);		
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter  out = response.getWriter();
		out.print(gsonString);
	}
	
	
	protected void doUpdate(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LOG.debug("------------------------");
		LOG.debug("-doUpdate-");
		LOG.debug("------------------------");	
		
		
		String memberId  =StringUtil.nvl(request.getParameter("member_id"),"");
		String name  =StringUtil.nvl(request.getParameter("name"),"");
		String passwd  =StringUtil.nvl(request.getParameter("passwd"),"");
		String email  =StringUtil.nvl(request.getParameter("email"),"");
		String cellPhone  =StringUtil.nvl(request.getParameter("cell_phone"),"");
		String sex  =StringUtil.nvl(request.getParameter("sex"),"");
		String auth  =StringUtil.nvl(request.getParameter("auth"),"");
		
		
		MemberVO  param = new MemberVO();
		param.setMemberId(memberId);		
		param.setName(name);
		param.setPasswd(passwd);
		param.setEmail(email);
		param.setCellPhone(cellPhone);
		param.setSex(sex);
		param.setAuth(auth);
		param.setModId("Admin");
		//TO-do
		//--session처리 

		LOG.debug("-param-"+param);
		int flag = this.memberService.doUpdate(param);
		
		MessageVO  messageVO = new MessageVO();
		String message = "";
		if(1==flag) {
			message = "수정 되었습니다.";
		}else {
			message = "수정 실패";
		}
		messageVO.setMsgContents(message);
		messageVO.setMsgId(String.valueOf(flag));
		
		Gson gson=new Gson();
		
		String gsonString = gson.toJson(messageVO);
		
		
		LOG.debug("-gsonString-"+gsonString);		
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter  out = response.getWriter();
		out.print(gsonString);
	}
	
	
	protected void doDel(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LOG.debug("------------------------");
		LOG.debug("-doDelete-");
		LOG.debug("------------------------");	
		
		String memberId  =StringUtil.nvl(request.getParameter("member_id"),"");
		LOG.debug("-memberId-"+memberId);
		
		MemberVO  param = new MemberVO();
		param.setMemberId(memberId);
		
		LOG.debug("-param-"+param);		
		
		int flag = this.memberService.doDelete(param);
		
		MessageVO  messageVO = new MessageVO();
		String message = "";
		if(1==flag) {
			message = "삭제 되었습니다.";
		}else {
			message = "삭제 실패";
		}
		messageVO.setMsgContents(message);
		messageVO.setMsgId(String.valueOf(flag));
		
		Gson gson=new Gson();
		
		String gsonString = gson.toJson(messageVO);
		
		
		LOG.debug("-gsonString-"+gsonString);		
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter  out = response.getWriter();
		out.print(gsonString);
	}
	
	
	protected void doSelectOne(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LOG.debug("------------------------");
		LOG.debug("-doSelectOne-");
		LOG.debug("------------------------");		
		String memberId  =StringUtil.nvl(request.getParameter("member_id"),"");
		LOG.debug("-memberId-"+memberId);
		
		MemberVO  param = new MemberVO();
		param.setMemberId(memberId);
		
		LOG.debug("-param-"+param);
		
		MemberVO  outVO =(MemberVO) this.memberService.doSelectOne(param);
		LOG.debug("-param-"+param);
		
		//화면으로 데이터 전달
		request.setAttribute("vo", outVO);
		RequestDispatcher  dispatcher= request.getRequestDispatcher("/member/member_mng.jsp");
		dispatcher.forward(request, response);		
	}
	
	
	protected void doRetrieve(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		///member/member.do?work_div=doRetrieve
		String searchDiv  =StringUtil.nvl(request.getParameter("search_div"),"");
		String searchWord =StringUtil.nvl(request.getParameter("search_word"),"");
		String pageSize   =StringUtil.nvl(request.getParameter("page_size"),"10");
		String pageNum    =StringUtil.nvl(request.getParameter("page_num"),"1");
		
		LOG.debug("------------------------");
		LOG.debug("-searchDiv-"+searchDiv);
		LOG.debug("-searchWord-"+searchWord);
		LOG.debug("-pageSize-"+pageSize);
		LOG.debug("------------------------");		
		//service에 DTO전달
		SearchVO   param=new SearchVO();
		param.setSearchDiv(searchDiv);
		param.setSearchWord(searchWord);
		
		int pageSizeNum = Integer.parseInt(pageSize);
		param.setPageSize(pageSizeNum);
		param.setPageNum(Integer.parseInt(pageNum));
		
		LOG.debug("-param-"+param);
		
		List<MemberVO> list = (List<MemberVO>) this.memberService.doRetrieve(param);
		LOG.debug("-list.size-"+list.size());
		//해당화면에 DATA 전달!	
		LOG.debug("-list-"+list);
		
		//화면으로 데이터 전달
		request.setAttribute("list", list);
		//param전달	
		request.setAttribute("search", param);
		
		//총글수 
		MemberVO memberTotalCnt =(MemberVO)this.memberService.doTotalCnt(param);
		
		request.setAttribute("total_cnt", memberTotalCnt.getTotalCnt());
		
		RequestDispatcher  dispatcher= request.getRequestDispatcher("/member/member_list.jsp");
		dispatcher.forward(request, response);
				
	}
	

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
