/**
* <pre>
* com.sist.eclass.board.servie
* Class Name : BoardService.java
* Description: 게시판 비지니스 영역
* Author: sist
* Since: 2021/02/25
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2021/02/25 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.board.servie;

import java.util.List;

import org.apache.log4j.Logger;

import com.sist.eclass.board.dao.BoardDao;
import com.sist.eclass.board.domain.BoardVO;
import com.sist.eclass.cmn.DTO;
import com.sist.eclass.cmn.StringUtil;

/**
 * @author sist
 *
 */
public class BoardService {

	private final Logger LOG = Logger.getLogger(BoardService.class);
	private BoardDao dao;
	
	
	
	public BoardService() {
		dao = new BoardDao();
	}
	/**
	 * 목록 조회
	 * @param param
	 * @return List<BoardVO>
	 */
	public List<BoardVO> doRetrieve(DTO param){
		return dao.doRetrieve(param);
	}
	
	/**
	 * 수정
	 * @param param
	 * @return 성공:1, 실패:0
	 */
	public int doUpdate(DTO param) {
		return dao.doUpdate(param);
	}
	
	/**
	 * 게시글 삭제
	 * @param param
	 * @return 성공:1, 실패:0
	 */
	public int doDelete(DTO param) {
		return dao.doDelete(param);
	}
	
	
	
	/**
	 * 게시글 등록
	 * @param param
	 * @return 성공:1, 실패:0
	 */
	public int doInsert(DTO param) {
		BoardVO inVO=(BoardVO)param;
		
		int seqNum = dao.getSeq(); 
		inVO.setSeq(seqNum);
		//A 테이블
		
		//B 테이블에 seqNum
		
		
		return dao.doInsert(inVO);
	}
	
	
	/**
	 * 단건조회 + 조회Count증가 
	 * @param param
	 * @return
	 */
	public BoardVO doSelectOne(DTO param) {
		//조회Count증가 
		BoardVO inVO = (BoardVO) param;
		int flag = dao.doReadCnt(inVO);
		LOG.debug("==========================");
		LOG.debug("=조회Count flag="+flag);
		LOG.debug("==========================");
		//단건조회
		BoardVO outDATA = dao.doSelectOne(param);
		outDATA.setMsgFlag(flag);
		
		if(1==flag) {
			outDATA.setMsg("조회 Count증가 성공");
		}else {
			outDATA.setMsg("조회 Count증가 실패");
		}
		
		
		return outDATA;
	}
	
	
	
	
	
	
	
	
	
	
	
}
