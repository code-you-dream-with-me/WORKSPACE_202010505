/**
* <pre>
* com.sist.eclass.reply.domain
* Class Name : ReplyVO.java
* Description:
* Author: HB
* Since: 2021/03/13
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2021/03/13 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.reply.domain;

import com.sist.eclass.cmn.DTO;

/**
 * @author HB
 *
 */
public class ReplyVO extends DTO {
	
	private int repSeq;         //댓글순번
	private int seq;            //순번
	private String repContents; //댓글내용
	private String regId;       //등록자
	private String regDt;       //등록일
	
	public ReplyVO() {}

	/**
	 * @param repSeq
	 * @param seq
	 * @param repContents
	 * @param regId
	 * @param regDt
	 */
	public ReplyVO(int repSeq, int seq, String repContents, String regId, String regDt) {
		super();
		this.repSeq = repSeq;
		this.seq = seq;
		this.repContents = repContents;
		this.regId = regId;
		this.regDt = regDt;
	}

	/**
	 * @return the repSeq
	 */
	public int getRepSeq() {
		return repSeq;
	}

	/**
	 * @param repSeq the repSeq to set
	 */
	public void setRepSeq(int repSeq) {
		this.repSeq = repSeq;
	}

	/**
	 * @return the seq
	 */
	public int getSeq() {
		return seq;
	}

	/**
	 * @param seq the seq to set
	 */
	public void setSeq(int seq) {
		this.seq = seq;
	}

	/**
	 * @return the repContents
	 */
	public String getRepContents() {
		return repContents;
	}

	/**
	 * @param repContents the repContents to set
	 */
	public void setRepContents(String repContents) {
		this.repContents = repContents;
	}

	/**
	 * @return the regId
	 */
	public String getRegId() {
		return regId;
	}

	/**
	 * @param regId the regId to set
	 */
	public void setRegId(String regId) {
		this.regId = regId;
	}

	/**
	 * @return the regDt
	 */
	public String getRegDt() {
		return regDt;
	}

	/**
	 * @param regDt the regDt to set
	 */
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}

	@Override
	public String toString() {
		return "ReplyVO [repSeq=" + repSeq + ", seq=" + seq + ", repContents=" + repContents + ", regId=" + regId
				+ ", regDt=" + regDt + ", toString()=" + super.toString() + "]";
	}
	
	
}
