package com.sist.eclass.operator;

public class Operator14 {

	public static void main(String[] args) {
		//문자열의 비교 : ==대신 .equals()를 이용해서 비교해야 한다.													

		String str01 ="abc";
		
		String str02 =new String("abc");
		
		System.out.println("str01:"+str01);
		System.out.println("str02:"+str02);

		System.out.println("str01==str02:"+(str01==str02));
		System.out.println("str01.equals(str02):"+(str01.equals(str02)));
	}

}
