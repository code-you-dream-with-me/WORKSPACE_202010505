package com.sist.eclass;

public class Casting04 {

	public static void main(String[] args) {
//		실수형은 정수형보다 훨씬 큰 저장 범위를 갖기 떄문에, 정수형을 실수형으로 변환하는데 별 무리가 없다.																						
//		(실수형은 정밀도의 제한으로 인한 오차가 발생할 수 있다.)																						
		int   i  = 91234567;//8자리 int
		float f  = (float)i; 
		double d = (double)i;
		
		
		System.out.printf("i=%d\n", i);//i=91234567
		System.out.printf("f=%f\n", f);//f=91234568.000000
		System.out.printf("d=%f\n", d);//d=91234567.000000
		
		
		int f2 = (int) f; 
		System.out.printf("f2=%d\n", f2);//f2=91234568
		
		int df = (int) d;
		System.out.printf("df=%d\n", df);//df=91234567
		
		float f3 = 1.6666f;
		System.out.printf("f3=%f\n", f3);//f3=1.666600
		
		int   i3 = (int) f3;
		System.out.printf("i3=%d\n", i3);//i3=1
	}

}
