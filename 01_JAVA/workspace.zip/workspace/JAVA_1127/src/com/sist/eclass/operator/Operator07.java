package com.sist.eclass.operator;

public class Operator07 {

	public static void main(String[] args) {
		char ch01= 'a';
		
		int i = ch01+1;
		
		char ch02= (char)i;
		System.out.println("ch01="+ch01);//ch01=a
		System.out.println("i="+i);//i=98
		System.out.println("ch02="+ch02);//ch02=b
		
		char ch = 'a';
		//abcdefghijklmnopqrstuvwxyz
		for(int j=0;j<26;j++) {
			System.out.print(ch++);
		}
		
		System.out.println();
		
		ch = 'A';
		for(int j=0;j<26;j++) {
			System.out.print(ch++);
		}	
		
		System.out.println();
		ch = '0';
		for(int j=0;j<10;j++) {
			System.out.print(ch++);
		}		
	}

}
