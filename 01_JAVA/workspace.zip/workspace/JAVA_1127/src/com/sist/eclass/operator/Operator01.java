package com.sist.eclass.operator;

public class Operator01 {

	public static void main(String[] args) {
//		피연산자의 타입이 int보다 작은 타입이면 int로 변환												
//		
//		byte + short      '-> 						int + int -> int						
//		char + short      ->						int+ int -> int						
		
		byte x = 20;
		byte y = 10;
		
		//byte z = (x + y);//Type mismatch: cannot convert from int to byte
		byte z = (byte) (x + y);
		
		System.out.println("z="+z);

	}

}
