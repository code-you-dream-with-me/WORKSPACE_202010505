package com.sist.eclass.operator;

public class Operator05 {

	public static void main(String[] args) {
//		타입		설명						사용예
//      ==========================================================		
//		전위형		값이 참조되기 전에 증가	j=++i;			
//		후위형		값이 참조된 후에 증가		j=i++;			

		int i=5;
		int j=0;
		
		j=i++;//후위형
		
		System.out.println("i="+i+"\tj="+j);//i=6	j=5
		
		i=5;
		j=0;
		
		j=++i;//전위형
		System.out.println("i="+i+"\tj="+j);//i=6	j=6

	}

}
