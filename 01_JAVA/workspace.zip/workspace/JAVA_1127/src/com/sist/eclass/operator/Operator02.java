package com.sist.eclass.operator;

public class Operator02 {

	public static void main(String[] args) {
//		피연산자의 타입이 int보다 작은 타입이면 int로 변환												
//		
//		byte + short      '-> 						int + int -> int						
//		long = int * int	

		long a = 1_000_000 * 1_000_000;
		System.out.println("a="+a);
		
		long b = 1_000_000 * 1_000_000L;
		System.out.println("b="+b);
		
		int  i = 50;
		float  f  =10.f;
		
		System.out.println("i*f="+i*f);
		
		
		
	}

}
