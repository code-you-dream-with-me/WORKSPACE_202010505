package com.sist.eclass.operator;

public class Operator09 {

	public static void main(String[] args) {
		//버림
		float pi = 3.141592f;//3.141
		//1000/1000 
		
		float shotPi = (int)(pi*1000)/1000f;
		//(int)(3141.592f)
		//3141/1000f
		//3.141
		
		
		System.out.println("shotPi:"+shotPi);
		

	}

}
