package com.sist.eclass.operator;

public class Operator12 {

	public static void main(String[] args) {
//		나머지 연산자: %							
//		나누기한 나머지를 반환					
		int x = 10;
		int y = 8;
		
		System.out.println("x%y="+(x%y) );

	}

}
