package com.sist.eclass.operator;

public class Operator03 {

	public static void main(String[] args) {
		//산술연산자	+,-,/,*,%, <<, >>	사칙연산, 나머지(%)
		//---------------------------------------------
		int a  = 10;
		int b  = 4;
		
		System.out.printf("%d+%d=%d\n", a,b,a+b);
		System.out.printf("%d-%d=%d\n", a,b,a-b);
		System.out.printf("%d*%d=%d\n", a,b,a*b);
		
		System.out.printf("%d/%d=%d\n", a,b,a/b);//int/int = int
		
		System.out.printf("%d/%d=%f\n", a,b,a/(float)b);//int/(float)int = float

	}

}
