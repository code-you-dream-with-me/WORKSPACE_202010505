package com.sist.eclass.operator;

public class Operator11 {

	public static void main(String[] args) {
		//올림
		double pi = 3.141592;
		
		double shotPi = Math.round(pi*1000)/1000.0;		
		
		System.out.println("shotPi:"+shotPi);
		
	}

}
