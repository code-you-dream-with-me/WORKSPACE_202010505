package com.sist.eclass.operator;

public class Operator13 {

	public static void main(String[] args) {
//     =============================================		
//		비교연산자			설명	
//     =============================================		
//		==			두 값이 같으면 true 그렇치 않으면 false							
//		!=			두 값이 다르 true 그렇치 않으면 false							
//     ---------------------------------------------

		//비교 연산자도 연산을 수행하기 전에 형변환을 통해 두 피연산자의 타입을 일치 시키고
		//비교 한다. int보다 flaot이 표현할수 있는 범위가 크므로 int가 flaot 10.0f
		//변환 되어 비교 된다.
		System.out.printf("10 == 10.0f \t %b\n", 10 == 10.0f);//true
		System.out.printf("'0'== 0 \t %b\n"    , '0'== 0);//false
		System.out.printf("'A' == 65 \t %b\n"  , 'A'== 65 );//true
		System.out.printf("'A' > 'B' \t %b\n"  , 'A'> 'B');//false
				
	}

}
