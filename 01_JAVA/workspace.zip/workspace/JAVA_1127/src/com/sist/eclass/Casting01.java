package com.sist.eclass;

public class Casting01 {

	public static void main(String[] args) {
//		변환			               수식						              결과				
//		int -> char			(char)65						'A'				
//		char ->int		 	(int)'A'						65				
//		float -> int		(int)1.6f						1				
//		int ->float			(float)10						10.0f				
		
		System.out.println("int -> char:"+(char)65);
		System.out.println("char ->int:"+(int)'A');
		System.out.println("float -> int:"+(int)1.6f);
		System.out.println("int ->float:"+(float)10);
	}

}
