package com.sist.eclass;

public class Casting03 {

	public static void main(String[] args) {
//		Type	크기(byte)	정밀도
//      ==========================		
//		float	4	7자리
//		double	8	15자리

        float  f = 9.1234567f;
        double d = 9.1234567;
        
        double d01 = (double)f;
        
//      f=  9.123456954956055000
//		d=  9.123456700000000000
//		d01=9.123456954956055000        
        System.out.printf("f=%20.18f%n",f);
        System.out.printf("d=%20.18f%n",d);
        System.out.printf("d01=%20.18f%n",d01);
		
		
	}

}
