package com.sist.eclass.operator;

public class OperatorPrac02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		if(args.length !=1)
		{
			System.out.println("숫자를 입력하세요");
			System.exit(0);
		}
		
		String input1=args[0];
		System.out.println("input1:"+input1);
		
		
		float a=Float.parseFloat(input1);
		float b=(int)(a*1000)/1000f;
		System.out.println("실수 소수점 셋째 자리 반올림="+b);
	}
}
