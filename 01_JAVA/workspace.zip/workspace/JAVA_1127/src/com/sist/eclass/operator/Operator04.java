package com.sist.eclass.operator;

public class Operator04 {

	public static void main(String[] args) {
//		증감 연산자: ++,--											
//		증가 연산자(++): 피연산자의 값을 1증가									
//		감소 연산자(--) : 피연산자의 값을 1감소									
        
		int i =5;
		i++;//i=i+1;
		
		System.out.println("i="+i);//i=6
		
		i = 5;
		++i;
		System.out.println("i="+i);//i=6

	}

}
