package com.sist.eclass.operator;

public class Operator06 {

	public static void main(String[] args) {
		int a = 1_000_000;
		
		int result01 = a * a / a ;//쓰레기 값(a*a int  오버플로 발생)
		int result02 = a / a * a ;//a

		System.out.printf("%d * %d / %d = %d\n",a,a,a,result01);
		System.out.printf("%d * %d / %d = %d\n",a,a,a,result02);
		
	}

}
