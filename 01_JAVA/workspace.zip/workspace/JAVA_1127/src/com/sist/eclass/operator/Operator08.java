package com.sist.eclass.operator;

public class Operator08 {

	public static void main(String[] args) {
		// 소문자를 대문자로 바꾸기: a -> A
		
		char lowerCase = 'a';
		char upperCase = (char) (lowerCase - 32);
		System.out.println("lowerCase:"+lowerCase);
		System.out.println("upperCase:"+upperCase);
		
	}

}
