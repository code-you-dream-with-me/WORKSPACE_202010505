package com.sist.eclass07;

public class InterFaceTestMain {

	public static void main(String[] args) {
		A a=new A();
		a.methodA(new B());

	}

}
