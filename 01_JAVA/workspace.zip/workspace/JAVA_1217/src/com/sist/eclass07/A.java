package com.sist.eclass07;

public class A {

	//A class가 Bclass를 알고 있다.
	//강한 결합
	public void methodA(B b) {
		b.methodB();
	}
}
