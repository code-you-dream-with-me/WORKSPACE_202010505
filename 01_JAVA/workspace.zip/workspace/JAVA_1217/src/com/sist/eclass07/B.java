package com.sist.eclass07;

public class B {

	public void methodB() {
		System.out.println("B class methodB() ");
	}
}
