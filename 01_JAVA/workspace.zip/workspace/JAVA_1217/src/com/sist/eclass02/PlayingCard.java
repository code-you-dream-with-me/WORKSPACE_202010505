package com.sist.eclass02;

public interface PlayingCard {

	public static final int SPACE =4;
	int DIMOND =3;//public static final
	final int HEART =2;//public static final
	static int CROVER =1;//public static final
	
	public abstract String getCardNumber();
	String getKind();//public abstract
}
