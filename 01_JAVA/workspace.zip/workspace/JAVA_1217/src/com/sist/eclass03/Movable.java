package com.sist.eclass03;

public interface Movable {

	public abstract void move(int x, int y);
}
