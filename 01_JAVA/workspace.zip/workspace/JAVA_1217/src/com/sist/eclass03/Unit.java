package com.sist.eclass03;

public class Unit {
	int x;
	int y;
	int currentHP; //채력

}
