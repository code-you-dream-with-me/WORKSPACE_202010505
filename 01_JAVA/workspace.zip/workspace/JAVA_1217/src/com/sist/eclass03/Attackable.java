package com.sist.eclass03;

public interface Attackable {

	void attack(Unit u);
}
