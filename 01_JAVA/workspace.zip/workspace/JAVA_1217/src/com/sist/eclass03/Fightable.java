package com.sist.eclass03;

public interface Fightable extends Attackable, Movable {

}
