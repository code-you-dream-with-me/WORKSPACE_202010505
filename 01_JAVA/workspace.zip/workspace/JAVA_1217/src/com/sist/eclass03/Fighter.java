package com.sist.eclass03;

public  class Fighter extends Unit implements Fightable {

	public void move(int x, int y) {
		
	}

	public void attack(Unit u) {
		
	}
}
