package com.sist.eclass03;

public class FighterMain {

	public static void main(String[] args) {
//		instanceof연산자																	
//		
//		- 참조변수가 참조하는 인스턴스의 실제 타입을 체크 하는데 사용.																
//		- 이항연산자 왼쪽에는 참조변수를 오른쪽에는 타입클래스명,  연산결과는 true/false																
//																		
//		if(fe instanceof Car){																
//																		
//		}																
				
		Fighter f=new Fighter();
		
		if(f instanceof  Unit) {
			System.out.println("f는 Unit에 자손"+(f instanceof  Unit));
		}
		
		if(f instanceof  Fightable) {
			System.out.println("f는 Fightable을 구현"+(f instanceof  Fightable));
		}	
		
		if(f instanceof  Attackable) {
			System.out.println("f는 Attackable을 구현"+(f instanceof  Attackable));
		}		
		
		if(f instanceof  Movable) {
			System.out.println("f는 Movable을 구현"+(f instanceof  Movable));
		}	
		
		if(f instanceof  Object) {
			System.out.println("f는 Object을 구현"+(f instanceof  Object));
		}		
	}

}
