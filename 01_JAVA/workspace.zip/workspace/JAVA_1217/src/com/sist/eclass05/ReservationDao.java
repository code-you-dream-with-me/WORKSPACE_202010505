package com.sist.eclass05;

import java.util.Vector;

import com.sist.eclass.cmn.DataTObject;
import com.sist.eclass.cmn.WorkStd;

public class ReservationDao implements WorkStd {

	@Override
	public int doSave(DataTObject obj) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int doUpdate(DataTObject obj) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int doDelete(DataTObject obj) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public DataTObject doSelectOne(DataTObject obj) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Vector doSelectList(DataTObject obj) {
		// TODO Auto-generated method stub
		return null;
	}


}
