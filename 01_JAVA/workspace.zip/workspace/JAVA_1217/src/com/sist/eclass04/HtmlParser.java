package com.sist.eclass04;

public class HtmlParser implements Parseable {


	public void parse(String fileName) {
		System.out.println("HtmlParser parse수행");
		
	}

}
