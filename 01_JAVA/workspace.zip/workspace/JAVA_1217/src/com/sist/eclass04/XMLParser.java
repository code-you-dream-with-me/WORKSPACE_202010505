package com.sist.eclass04;

public class XMLParser implements Parseable {

	public void parse(String fileName) {
		System.out.println("XMLParser parse수행");
	}
}
