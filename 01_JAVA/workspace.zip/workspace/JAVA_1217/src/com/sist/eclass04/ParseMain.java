package com.sist.eclass04;

public class ParseMain {

	public static void main(String[] args) {
		//XMLParser implements Parseable
		Parseable parser =ParserManager.getParser("XML");
        parser.parse("move.xml");
        
        //HtmlParser implements Parseable
        parser =ParserManager.getParser("html");
        parser.parse("move.html");
	}

}
                         