package com.sist.eclass04;

public interface Parseable {

	/**
	 * 구문 분석 
	 * @param fileName
	 */
	public abstract void parse(String fileName);

}
