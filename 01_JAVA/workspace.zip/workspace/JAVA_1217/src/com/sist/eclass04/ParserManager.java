package com.sist.eclass04;

public class ParserManager {

	//type xml,html
	public static Parseable getParser(String type) {
		
		if(type.equalsIgnoreCase("XML")) {
			return new XMLParser();
		}else {
			return new HtmlParser();
		}
	}

}
