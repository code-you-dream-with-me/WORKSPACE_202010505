package com.sist.eclass.cmn;

public interface DataTObject {

}
