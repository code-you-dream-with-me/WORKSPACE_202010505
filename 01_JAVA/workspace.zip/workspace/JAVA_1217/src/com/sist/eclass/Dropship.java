package com.sist.eclass;

public class Dropship extends Unit {

	void load() {
		
	}
	
	void unload() {
		
	}
	
	@Override
	void move(int x, int y) {
		// TODO Auto-generated method stub
		
	}

}
