package com.sist.eclass.cmn;

import java.util.Vector;

/**
 * DAO 작업표준 
 *  모든 Dao는 WorkStd를 상속 받는다.
 * @author sist
 *
 */
public interface WorkStd {
    /**
     * 단건 등록 
     * @param obj
     * @return 1/0(1:성공,0:실패)
     */
    int doSave(DataTObject obj);

    /**
     * 수정 
     * @param obj
     * @return 1/0(1:성공,0:실패)
     */
    int doUpdate(DataTObject obj);	
    /**
     * 삭제
     * @param obj
     * @return 1/0(1:성공,0:실패)
     */
    int doDelete(DataTObject obj);
    
    /**
     * 단건 조회
     * @param obj
     * @return Object
     */
    DataTObject doSelectOne(DataTObject obj);
    /**
     * 목록 조회
     * @param obj
     * @return Vector<Object>
     */
    Vector doSelectList(DataTObject obj);
	
	
}
