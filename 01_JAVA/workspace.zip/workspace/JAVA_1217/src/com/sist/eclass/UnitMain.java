package com.sist.eclass;

public class UnitMain {

	public static void main(String[] args) {
		//추상클래스 객체 생성
		//상속받은 자식을 통해 객체 생성.
		Unit []group=new Unit[4];
		group[0] = new Marine();
		group[1] = new Tank();
		group[2] = new Tank();
		group[3] = new Dropship();
		
		for(int i=0;i<group.length;i++) {
			group[0].move(100, 200);
		}
		//Object 모든 클래스의 아버지
		Object[] group02=new Object[4];
		group02[0] = new Marine();
		group02[1] = new Tank();
		group02[2] = new Tank();
		group02[3] = new Dropship();		
		
	}

}
