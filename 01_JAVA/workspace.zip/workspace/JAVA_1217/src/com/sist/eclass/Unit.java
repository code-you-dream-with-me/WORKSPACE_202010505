package com.sist.eclass;

public abstract class Unit {
   int x;//현재 위치 좌표x
   int y;//현재 위치 좌표y
   
   abstract void move(int x, int y);
   
   void stop() {
	   //현재 위치 저장
   }
}
