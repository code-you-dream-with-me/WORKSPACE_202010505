package com.sist.eclass;

public class Marine extends Unit {

	void stimPack() {
		
	}
	
	@Override
	void move(int x, int y) {
		// 지정 위치로 이동
	}

}
