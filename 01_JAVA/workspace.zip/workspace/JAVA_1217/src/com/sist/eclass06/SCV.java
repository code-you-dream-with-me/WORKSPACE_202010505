package com.sist.eclass06;

public class SCV extends GroundUnit {

	public SCV() {
		super(60);
		hitPoint = MAX_HP;
	}
	
	/**
	 * - 서로 관계없는 클래스들에게 관계를 맺어 줄수 있다.															
		 상속관계에 있지 않고, 같은 조상을 가지고 있지 않은 서로 다른 클래스들에게															
		 하나의 인터페이스를 구현도록 함으로 관계를 맺어 줄수 있다.
	 * @param r
	 */
	void repair(Repaireable r) {
		
		if( r instanceof Unit) {
			  Unit u=(Unit) r;
			  
			  while(u.hitPoint !=u.MAX_HP) {
				  /*Unit HP증가 */
				  u.hitPoint++;
			  }
			  
			  System.out.println(u.toString()+"의 수리가 끝났습니다.");
			  
			  
		}
		
	}

}
