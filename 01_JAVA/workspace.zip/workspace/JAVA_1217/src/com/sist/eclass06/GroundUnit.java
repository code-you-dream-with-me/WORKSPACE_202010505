package com.sist.eclass06;

public class GroundUnit extends Unit {

	public GroundUnit(int hp) {
		super(hp);
	}

}
