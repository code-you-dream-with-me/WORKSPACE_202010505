package com.sist.eclass06;

public interface Repaireable {

}
