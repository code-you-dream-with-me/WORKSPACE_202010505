package com.sist.eclass06;

public class Dropship extends AirUnit implements Repaireable {

	public Dropship() {
		super(125);
		hitPoint = MAX_HP;
	}

//	@Override
//	public String toString() {
//		return "Dropship";
//	}
	
	
	
}
