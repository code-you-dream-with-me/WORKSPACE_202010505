package com.sist.eclass06;

public class Tank extends GroundUnit implements Repaireable {

	public Tank() {
		super(150);
		hitPoint = MAX_HP;
	}

	@Override
	public String toString() {
		return "Tank";
	}
	
	
	
	
}
