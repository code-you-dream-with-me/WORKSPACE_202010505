package com.sist.eclass06;

public class Marine extends GroundUnit  {

	public Marine() {
		super(40);
		hitPoint = MAX_HP;
	}
}
