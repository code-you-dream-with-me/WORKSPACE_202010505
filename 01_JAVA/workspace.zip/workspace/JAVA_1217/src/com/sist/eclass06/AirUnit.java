package com.sist.eclass06;

public class AirUnit extends Unit {

	public AirUnit(int hp) {
		super(hp);
	}
}
