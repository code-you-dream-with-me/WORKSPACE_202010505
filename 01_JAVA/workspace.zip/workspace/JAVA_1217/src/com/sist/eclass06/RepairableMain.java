package com.sist.eclass06;

public class RepairableMain {

	public static void main(String[] args) {
		Tank tank=new Tank();
		Dropship  dropship=new Dropship();
		SCV   scv=new SCV();
		
		//interface Repaireable 상속받지 않음
		Marine  marine=new Marine();
		
		scv.repair(tank);
		scv.repair(dropship);
//		scv.repair(marine);

	}

}
