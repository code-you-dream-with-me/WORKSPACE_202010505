package com.sist.eclass08;

public class A {

	//A class가 Bclass를 알고 있다.
	//강한 결합
	public void methodA(I i) {
		i.methodB();
	}
}
