package com.sist.eclass08;

public class InterFaceTestMain {

	public static void main(String[] args) {
		A a=new A();
		a.methodA(new B());

	}

}
