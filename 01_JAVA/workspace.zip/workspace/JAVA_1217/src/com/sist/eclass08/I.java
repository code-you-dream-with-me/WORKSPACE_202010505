package com.sist.eclass08;

public interface I {
	public void methodB();
}
