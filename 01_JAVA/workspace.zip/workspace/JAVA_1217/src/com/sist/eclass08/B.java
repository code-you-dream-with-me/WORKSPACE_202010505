package com.sist.eclass08;

public class B implements I{

	public void methodB() {
		System.out.println("B class methodB() ");
	}
}
