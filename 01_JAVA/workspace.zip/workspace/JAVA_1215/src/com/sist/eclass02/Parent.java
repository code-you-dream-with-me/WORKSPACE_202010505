package com.sist.eclass02;

public class Parent {
	int x=10;
}
