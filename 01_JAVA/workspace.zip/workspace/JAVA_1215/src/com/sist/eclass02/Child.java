package com.sist.eclass02;

public class Child extends Parent {
	int x = 20;
	
	void method() {
		System.out.println("x="+x);
		
		//child ��� this
		System.out.println("child ��� this:"+this.x);
		//parent ��� super
		System.out.println("parent ��� super:"+super.x);
	}
	
	public static void main(String []args) {
		Child c=new Child();
		c.method();
	}
	
}
