package com.sist.eclass04;

import java.text.SimpleDateFormat;
import java.util.Date;

//Ctrl+Shift+O  ��Ű�� ����
public class ImportTest02 {
	
	public static void main(String []args) {
		Date today=new Date();
		
		System.out.println("today:"+today);
		//yyyy/MM/dd
		//hh:mm:ss a
		SimpleDateFormat sdf01=new SimpleDateFormat("yyyy/MM/dd");
		System.out.println("yyyy/MM/dd:"+sdf01.format(today));
		
		SimpleDateFormat sdf02=new SimpleDateFormat("hh:mm:ss a");
		System.out.println("hh:mm:ss a:"+sdf02.format(today));
		
	}
}
