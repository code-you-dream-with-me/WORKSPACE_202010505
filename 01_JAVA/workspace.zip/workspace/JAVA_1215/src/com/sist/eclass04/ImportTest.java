package com.sist.eclass04;

public class ImportTest {
	java.util.Date  today=new java.util.Date();
}
