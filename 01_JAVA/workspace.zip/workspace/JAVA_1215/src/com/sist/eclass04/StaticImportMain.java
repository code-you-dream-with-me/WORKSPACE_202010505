package com.sist.eclass04;

import static java.lang.Math.PI;

public class StaticImportMain {

	public static void main(String[] args) {
		//System.out.println("Math.PI:"+Math.PI);
		
		System.out.println("PI:"+PI);
	}

}
