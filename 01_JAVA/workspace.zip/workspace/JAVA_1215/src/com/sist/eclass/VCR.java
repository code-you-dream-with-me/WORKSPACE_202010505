package com.sist.eclass;

public class VCR {
   boolean power;
   int counter = 0;
   
   void power() {
	   power =!power;
   }
   
   void play() {}
   
   void stop() {}
   
   void rew() {}
   
   void ff() {}
   
}
