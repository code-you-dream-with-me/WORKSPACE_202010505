package com.sist.eclass05;

public class Card extends Object {
    //The blank final field NUMBER may not have been initialized
	//������ ���� �ʱ�ȭ ����
	final int NUMBER;
	final String KIND;
	
	static int width=100;
	static int height=150;
	
	public Card(int number, String kIND) {
		NUMBER = number;
		KIND = kIND;
	}
	
	
	public Card() {
		this(1,"HEART");
	}
	
	
	public String toString() {
		return KIND+","+NUMBER;
	}
	
    
	
}
