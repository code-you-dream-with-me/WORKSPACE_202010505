package com.sist.eclass05;

public class CardMain  {

	public static void main(String[] args) {
		Card card=new Card(10,"HEART");
		//The final field Card.NUMBER cannot be assigned
		//card.NUMBER = 9;
		System.out.println("card.NUMBER:"+card.NUMBER);
		System.out.println("card.height:"+card.height);
		
		
		System.out.println("Card.height:"+Card.height);
		
		//card.toString():com.sist.eclass05.Card@15db9742
		System.out.println("card.toString():"+card.toString());
		

	}

}
