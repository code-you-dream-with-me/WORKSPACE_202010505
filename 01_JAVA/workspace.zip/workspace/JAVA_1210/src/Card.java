
public class Card {

	
}
