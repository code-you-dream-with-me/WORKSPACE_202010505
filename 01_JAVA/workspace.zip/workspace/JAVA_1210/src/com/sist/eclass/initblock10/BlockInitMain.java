package com.sist.eclass.initblock10;

public class BlockInitMain {
	static{ System.out.println("클래스 초기화 블럭"); 
	      //..
	
	      //
	} //클래스 초기화 블럭
	
	{
		System.out.println("인스턴스 초기화 블럭");
		
	} //인스턴스 초기화 블럭
	
	
	public BlockInitMain() {
		System.out.println("생성자 초기화 블럭");
	}

	public static void main(String[] args) {
		System.out.println("BlockInitMain main()");
		
		BlockInitMain  bi=new BlockInitMain();
//		클래스 초기화 블럭
//		BlockInitMain main()
//		인스턴스 초기화 블럭
//		생성자 초기화 블럭		
		System.out.println("=======================");
		BlockInitMain  bi02=new BlockInitMain();

//		=======================
//		인스턴스 초기화 블럭
//		생성자 초기화 블럭		
	}

}
