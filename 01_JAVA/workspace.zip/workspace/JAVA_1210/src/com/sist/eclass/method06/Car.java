package com.sist.eclass.method06;

public class Car {

	String color;//색상
	String gearType;//기어타입
	int    door;//
	//default 생성자
	public Car() {}
	
	//인자 3개 생성자
	public Car(String c, String g, int d) {
		color = c;
		gearType = g;
		door = d;
	}
	
}


