package com.sist.eclass.method02;

public class TestClass {

	//인스턴스 메서드
	void instanceMethod() {}
	//클래스 메서드(static)
	static void staticMethod() {}
	
	//인스턴스 메서드:인스턴스 메서드(OK),클래스 메서드(static)(OK)
	void instanceMethodCall() {
		instanceMethod();
		staticMethod();
	}
	
	//클래스 메서드(static)
	static void staticMethodCall() {
		staticMethod();
		//instanceMethod();
	}
	
}
