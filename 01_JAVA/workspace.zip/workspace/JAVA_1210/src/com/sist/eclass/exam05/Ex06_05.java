package com.sist.eclass.exam05;

public class Ex06_05 {

	public static void main(String[] args) {
		Student  s=new Student("홍길동", 1, 1, 100, 60, 76);
		
		System.out.println(s.info());

	}

}
