package com.sist.eclass.method02;

public class TestClassMain {

	public static void main(String[] args) {
		TestClass testClass=new TestClass();
		testClass.instanceMethod();
		
		//위 두줄을 한줄로 처리가능.
		new TestClass().instanceMethod();
		
		
	}

}
