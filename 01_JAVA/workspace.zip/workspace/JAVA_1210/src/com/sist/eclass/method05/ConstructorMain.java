package com.sist.eclass.method05;

public class ConstructorMain {

	public static void main(String[] args) {
//		기본생성자(default constructor)																			
//		-사용자가 명기 적으로 만들지 않으면,컴파일러가 생성.																
//		-클래스 이름과 동일하고 인자가 없다.																
//																		
															
		
		Data01 d01=new Data01();//

//		* 사용자가 인자가 있는 생성자를 만들면, 컴파일러가 생성자를 만들어 주지 않는다.																
//		( 사용자가 생성자를 만들면 Default생성자도 생성하시오.)	
//		Data02 d02=new Data02();
		
	}

}
