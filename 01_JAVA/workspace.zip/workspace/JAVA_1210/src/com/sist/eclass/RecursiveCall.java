package com.sist.eclass;
import org.apache.log4j.*;

public class RecursiveCall {
	final static Logger LOG =Logger.getLogger(RecursiveCall.class);
	public static void main(String[] args) {

		//LOG.info("Log4j Info");
		//main(null);
		int result=factorial(20);
		//LOG.info("result:"+result);
	}

	//4!=4*3*2*1
	static int factorial(int n) {
		int result =0;
		if(n==1) {
			result =1;
		}else {
			result = n * factorial(n-1);
		}
		LOG.info("result:"+result);
		return result;
	}
}
