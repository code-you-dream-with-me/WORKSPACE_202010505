package com.sist.eclass.method06;


public class CarMain {

	public static void main(String[] args) {
		Car  car01=new Car();
		car01.color = "Red";
		car01.gearType="Auto";
		car01.door = 2;

		Car  car02=new Car("Blue","Manual",4);
		
		
		System.out.println("car01.color="+car01.color
				+"\tcar01.gearType="+car01.gearType
				+"\tcar01.door="+car01.door
				);
		
		System.out.println("car02.color="+car02.color
				+"\tcar02.gearType="+car02.gearType
				+"\tcar02.door="+car02.door
				);
	}

}

