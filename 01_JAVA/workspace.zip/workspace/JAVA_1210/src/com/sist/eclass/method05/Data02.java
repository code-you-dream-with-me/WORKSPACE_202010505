package com.sist.eclass.method05;

public class Data02 {
	int value;
	
//	public Data02() {
//		
//	}
	
	//default생성자 없음.
	public Data02(int x) {
		value = x;
	}
}
