package com.sist.eclass.method;

public class MyMathMain {

	public static void main(String[] args) {
		//클래스 메서드 호출
		System.out.println("MyMath.add(9, 11):"+MyMath.add(9, 11));
		System.out.println("MyMath.subtract(9, 11):"+MyMath.subtract(9, 11));
		
		//인스턴스 메서드 호출
		MyMath  mm=new MyMath();
		mm.a = 11L;
		mm.b = 14L;
		System.out.println("mm.add():"+mm.add());
		System.out.println("mm.subtract():"+mm.subtract());
	}

}
