package com.sist.eclass.exam;

public class Ex06_02 {

//섯다
//https://woodforest.tistory.com/221
	
	public static void main(String[] args) {
		SutdaCard  card01=new SutdaCard(3,false);
		SutdaCard  card02=new SutdaCard();
		
		System.out.println(card01.info());
		System.out.println(card02.info());

	}

}
