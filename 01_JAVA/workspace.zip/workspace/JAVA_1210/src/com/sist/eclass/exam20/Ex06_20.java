package com.sist.eclass.exam20;

import java.util.Arrays;

public class Ex06_20 {

	static int[] shuffle(int[] arr) {
		if(null == arr || arr.length<=0) {//배열에 대한 밸리데이션
			return arr;
		}
		
		for(int i=0;i<arr.length;i++) {
			int n =(int)(Math.random()*arr.length);
			
			int tmp = arr[i];
			arr[i]  = arr[n];
			arr[n]  = tmp;
		}
		
		
		return arr;
	}
	
	public static void main(String[] args) {
		int[] original= {1,2,3,4,5,6,7,8,9};
		System.out.println(Arrays.toString(original));
		
		int[] result = shuffle(original);
		System.out.println(Arrays.toString(original));
		

	}

}
