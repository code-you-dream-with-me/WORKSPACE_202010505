package com.sist.eclass.exam23;

public class Ex06_23 {

	
	static int max(int[] arr) {
	  
		
		int maxValue = 0;
		if(null ==arr || arr.length ==0) {
			return -999_999;
		}
		
		maxValue = arr[0];
		for(int i=0;i<arr.length;i++) {
			if(maxValue < arr[i]) {//최대값 : 최대보다 크면
				maxValue = arr[i];
			}
		}
		
		return maxValue;
	}
	
	public static void main(String[] args) {
		int[] data = {3,2,9,4,7};
		System.out.println(java.util.Arrays.toString(data));
		System.out.println(" 최대값:"+max(data)); 
		System.out.println(" 최대값:"+max(null)); 
		System.out.println(" 최대값:"+max(new int[]{})); // 크기가 0인 배열 

	}

}
