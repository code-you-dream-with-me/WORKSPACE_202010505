package com.sist.eclass.method03;

public class OverloadingMain {

	public static void main(String[] args) {
//		하나의 클래스에 같은 이름의 메서드를 여러 개 정의 사용.													
//		ex)	System.out.print();										
//													
//오버로딩의 조건													
// 		-메서드 이름이 같아야 한다.											
//		-매개변수의 타입,개수,순서가 달라야 한다.											
//		(리턴 타입은 오버로딩에 영향을 주지 않는다.)											
		MyMath02 mm=new MyMath02();
		System.out.println(mm.add(9, 11));
		System.out.println(mm.add(9, 11L));
		System.out.println(mm.add(9L, 11L));

		int []arr= {9,11,14};
		System.out.println(mm.add(arr));
		
	}

}
