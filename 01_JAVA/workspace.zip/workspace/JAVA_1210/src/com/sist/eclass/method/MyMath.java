package com.sist.eclass.method;

public class MyMath {
	long a;
	long b;
	//인스턴스 변수 a,b를 이용해 연산하므로 매개변수 불필요.
	long add() {
		return a+b;
	}
	
	long subtract() {
		return a-b;
	}
	
	//클래스 메서드
	static long add(long x, long y) {
		return x+y;
	}
	
	static long subtract(long x, long y) {
		return x-y;
	}	
	
}
