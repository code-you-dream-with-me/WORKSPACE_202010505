package com.sist.eclass.method03;

public class MyMath02 {
	/**
	 * int + int
	 * @param a
	 * @param b
	 * @return a+b
	 */
	int add(int a, int b) {
		System.out.println("int add(int a, int b)");
		return a+b;
	}
	
	/**
	 * long + long
	 * @param a
	 * @param b
	 * @return a+b
	 */
	long add(long a, long b) {
		System.out.println("long add(long a, long b)");
		return a+b;
	}
	
	/**
	 * int + long
	 * @param a
	 * @param b
	 * @return a+b
	 */
	long add(int a, long b) {
		System.out.println("long add(int a, long b)");
		return a+b;
	}	
	
	int add(int[] arr) {
	
		System.out.println("int add(int[] arr)");
		int result = 0;
		for(int tmp:arr) {
			result+=tmp;
		}
		
		return result;
	}
	
	
	
	
}

