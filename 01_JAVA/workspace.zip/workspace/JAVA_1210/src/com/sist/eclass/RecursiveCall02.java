package com.sist.eclass;
import org.apache.log4j.*;

public class RecursiveCall02 {
	final static Logger LOG =Logger.getLogger(RecursiveCall02.class);
	public static void main(String[] args) {

		//LOG.info("Log4j Info");
		//main(null);
		int n = 21;
		long result = 0;
		for(int i=1;i<=n;i++) {
			result=factorial(i);
			
			if(result ==-1) {
				System.out.println("휴효 하지 않습니다.(0<=n<=20)"+n);
				break;
			}
			System.out.printf("%2d!=%20d\n",i,result);
		}
  
	}

	//4!=4*3*2*1
	static long factorial(int n) {
		if(n<=0 || n>20)return -1;
		
		long result =0;
		if(n==1) {
			result =1;
		}else {
			result = n * factorial(n-1);
			//LOG.info("result:"+result);
		}
		
		return result;
	}
}
