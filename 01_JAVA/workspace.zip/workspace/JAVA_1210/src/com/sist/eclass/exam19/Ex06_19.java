package com.sist.eclass.exam19;

public class Ex06_19 {

	public static void change(String str) {
		str+="456";
	}
	
	
	public static void main(String[] args) {
		String str = "ABCD123";
		System.out.println("main:"+str);
		change(str);
		System.out.println("After change main:"+str);
		
	}

}
