package com.sist.eclass.exam07;

public class Ex06_07 {

	public static void main(String[] args) {
		MyPoint p=new MyPoint(1, 1);
		
		System.out.println(p.getDistance(2, 2));

	}

}
