package com.sist.eclass.method05;

public class Data01 {
	int value;
}
