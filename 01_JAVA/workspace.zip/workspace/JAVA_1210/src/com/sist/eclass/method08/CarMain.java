package com.sist.eclass.method08;

public class CarMain {

	public static void main(String[] args) {
		Car car01=new Car();
		Car car02=new Car("Blue");
		
		
		System.out.println("car01.color="+car01.color
				+"\tcar01.gearType="+car01.gearType
				+"\tcar01.door="+car01.door
				);

		System.out.println("car02.color="+car02.color
				+"\tcar02.gearType="+car02.gearType
				+"\tcar02.door="+car02.door
				);		
	}

}
