package com.sist.eclass.var09;

public class InitTest {

	int x;       //인스턴스 변수
	int y = x;   //인스턴스 변수
	
	public InitTest() {
		// TODO Auto-generated constructor stub
	}
	
	void method01() {
		int i=0;
		//The local variable i may not have been initialized
		int j=i;
	}

}
