package com.sist.eclass.method07;

public class Car {
	String color;//색상
	String gearType;//기어타입
	int    door;//
	//default 생성자
	public Car() {
		//System.out.println();
		//Constructor call must be the first statement in a constructor
		this("흰색","Auto",4);
		
	}
	
	public Car(String color) {
		this(color,"Auto",4);
	}
	
	//인자 3개 생성자
	public Car(String c, String g, int d) {
		color = c;
		gearType = g;
		door = d;
	}
	
}
