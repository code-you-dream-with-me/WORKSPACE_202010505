package com.sist.eclass.method04;

public class VarArgsMain {

	public static void main(String[] args) {
		// 동적인 매개변수 지정				
//		-가변 인자는 항상 마지막 매개변수 이어야 한다.		
//		-인자가 있어도 되고, 심지어 없어도 된다.											
//      가변인자가 선언되 메서드를 호출할 때마다 배열이 새로 생성된다. 효율이 좋치 못하다.         
		String []strArray = {"100","200","300"};
		System.out.println(concaterate("-",strArray));
		System.out.println(concaterate("",strArray));
		System.out.println(concaterate(",",strArray));
		
		//동적인 매개변수 지정
		System.out.println(concaterate(",",new String[] {"1","2","3","4","5"}));
		//-인자가 있어도 되고, 심지어 없어도 된다.	
		System.out.println(concaterate(","));
	}

	/**
	 * 
	 * @param delim :-
	 * @param args  : 9,11,14
	 * @return 9-11-14-
	 */
	static String concaterate(String delim,String... args) {
		String result ="";
		
		for(String str:args) {
			result+= str + delim;
		}
		
		return result;
	}
}
