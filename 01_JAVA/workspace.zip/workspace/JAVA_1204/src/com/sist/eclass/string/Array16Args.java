package com.sist.eclass.string;

public class Array16Args {

	public static void main(String[] args) {
		// 5 + 7
		// 5 - 7
		// 5 x 7
		// 5 / 7
		
		if(null !=args && args.length !=3) {
			System.out.println("사용방법: NUM1 + NUM2");
			System.exit(0);
		}

		int num1 = Integer.parseInt(args[0]);
		char op  = args[1].charAt(0);
		int num2 = Integer.parseInt(args[2]);
		int result = 0;
		System.out.println("num1:"+num1);
		System.out.println("op:"+op);
		System.out.println("num2:"+num2);
		
		
		switch(op) {
		case '+':
			result = num1+num2;
			break;
		case '-':
			result = num1-num2;
			break;
		case 'x':
			result = num1*num2;
			break;		
		case '/':
			float fResult = num1/(float)num2;
			System.out.println("fResult:"+fResult);
			break;				
		default:
			System.out.println("연산 기호를 확인 하세요.");
			break;
		}
		
		System.out.println("result:"+result);
		
		
		
		
		
		
		
		
		
		
	}

}
