package com.sist.eclass;

public class Array02SumAvg {

	public static void main(String[] args) {
		// 총합과 평균
		int score[] = {100,88,100,100,90};
		
		int sum = 0;//총합
		float avg = 0.0f;//평균
		
		for(int i=0;i<score.length;i++) {
			
			sum+=score[i];
		}
		
		avg = sum/(float)score.length;
		System.out.println("sum="+sum);
		System.out.println("avg="+avg);
		
		
	}

}
