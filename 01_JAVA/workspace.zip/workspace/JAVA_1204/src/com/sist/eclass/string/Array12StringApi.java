package com.sist.eclass.string;

import java.util.Arrays;

public class Array12StringApi {

	public static void main(String[] args) {
		String str = "ABCDE";
		
		System.out.println("str.length():"+str.length());
		for(int i=0;i<str.length();i++) {
			char ch = str.charAt(i);
			System.out.println(i+","+ch);
		}
		
		//String -> char[]
		char[] chArr = str.toCharArray();
		System.out.println(Arrays.toString(chArr));
		
		//char[] -> String
		String str02=new String(chArr);
		System.out.println("str02:"+str02);
		 
		String  str03 = "0123456";
		//begin index, end index
		String  tmp   = str03.substring(1, 4);
		System.out.println("str03.substring(1, 4):"+tmp);
		
		if("0123456".equals(str03)) {
			System.out.println("같다.");
		}else {
			System.out.println("다르다.");
		}
		
		
		

	}

}
