package com.sist.eclass;

public class Array08ShuffleSort {

	public static void main(String[] args) {
		// 1~45 사이에서 중복되지 않은 숫자 6개 추출
		
		//중복되지 않게 숫자 1~45 배열 생성
		int[] ball=new int[45];
		
		
		for(int i=0;i<ball.length;i++) {
			ball[i] = i+1;
			//System.out.println(ball[i]);
		}
		
		//자리바꿈
		for(int j=0;j<6;j++) {
			int n = (int)(Math.random()*45);//0<=x<45
			System.out.println(n);
			
			int tmp = ball[j];
			ball[j] = ball[n];
			ball[n] = tmp;
		}
		
		//배열 ball의 앞에서 부터 6개 출력,
		for(int i=0;i<6;i++) {
			System.out.printf("ball[%d]=%d\n",i,ball[i]);
		}

	}
//	ball[0]=8
//	ball[1]=27
//	ball[2]=41
//	ball[3]=33
//	ball[4]=16
//	ball[5]=17
	
//	ball[0]=34
//	ball[1]=18
//	ball[2]=2
//	ball[3]=45
//	ball[4]=6
//	ball[5]=28	
}
