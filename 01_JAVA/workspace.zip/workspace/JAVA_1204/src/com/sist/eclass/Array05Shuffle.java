package com.sist.eclass;

public class Array05Shuffle {

	public static void main(String[] args) {
		// 섞기(shuffle)
		
		int[] numArray=new int[10];
		
		//0~9할당
		for(int i=0;i<numArray.length;i++) {
			numArray[i]=i;
			System.out.print(numArray[i]);
		}
		
		System.out.println();
		
		for(int i=0;i<50;i++) {
			//0<=x<10
			int n = (int)(Math.random()*10);
			
			int tmp = numArray[0];
			numArray[0] = numArray[n];
			numArray[n] = tmp;
		}
		
		//shuffle이후
		for(int i=0;i<numArray.length;i++) {
			numArray[i]=i;
			System.out.print(numArray[i]);
		}		
		
		
		

	}

}
