package com.sist.eclass.string;

public class Array13StringMorse {

	public static void main(String[] args) {
		String source =  "ABA";
		
		String []morse= {".－","－...","－.－.","－.."
						," ."," ..－.","－－.","...."
						,".."
						,".－－－"
						,"－.－"
						,".－.."
						,"－－"
						,"－."
						,"－－－"
						,".－－."
						,"－－.－"
						,".－."
						,"..."
						,"－"
						,"..－"
						,"...－"
						,".－－"
						,"－..－"
						,"－.－－"
						,"－－.."};
		String   result = "";
		for(int i=0;i<source.length();i++) {
			char ch = source.charAt(i);
			//System.out.println(ch);
			//System.out.println(ch-'A');
			result+=morse[ch-'A']+"\t";
		}
		System.out.println("result:"+result);
		

	}

}
