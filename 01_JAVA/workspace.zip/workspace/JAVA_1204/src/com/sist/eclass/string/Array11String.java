package com.sist.eclass.string;

public class Array11String {

	public static void main(String[] args) {
		char [] hex = {'C','A','F','E','5'};
		//char -> hex code변환
		//0~15
		String[] binary = { "0000",
				            "0001",
				            "0010",
				            "0011",
				            "0100",
				            "0101",
				            "0110",
				            "0111",
				            "1000",
				            "1001",
				            "1010",
				            "1011",
				            "1100",
				            "1101",
				            "1110",
				            "1111",				            
		};
		
		//                   result:1100 1010 1111 1110	
		String result = "";//CAFE ->1100 1010 1111 1110
		
		for(int i=0;i<hex.length;i++) {
			System.out.printf("hex[%d]=%c\n",i,hex[i]);
			if(hex[i]>='0' && hex[i]<='9') {
				int tmp = (hex[i]-'0');//'2' - '0' =2
				result+=binary[tmp]+"\t";
			}else {
				int tmp=(hex[i]-'A')+10;
				result+=binary[tmp]+"\t";
				//System.out.println(tmp);
			}
		}
		
		System.out.println("result:"+result);
		
		
		
		
		
		
		
		
		
		
		

	}

}
