package com.sist.eclass;

public class Array03MaxMin {

	public static void main(String[] args) {
		// 최대값과 최소값 구하기!
		
		int score[] = {88,66,99,100,77,90};
		
		int max =score[0];
		int min =score[0];
		
		for(int i=0;i<score.length;i++) {
			
			if(score[i]>max) {//최대값 처리
				max = score[i];
			}
			
			if(score[i]<min) {//최소값
				min = score[i];
			}
			
			
		}
		
		System.out.println("max:"+max);
		System.out.println("min:"+min);
		
		
		

	}

}
