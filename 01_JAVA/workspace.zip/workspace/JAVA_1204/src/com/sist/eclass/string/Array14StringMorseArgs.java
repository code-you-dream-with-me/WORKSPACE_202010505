package com.sist.eclass.string;

public class Array14StringMorseArgs {

	public static void main(String[] args) {
		
		if(args.length!=1) {
			System.out.println("알파벳 문자를 입력 하세요.");
			System.exit(0);
		}
		
		String source =  args[0];
		System.out.println("source:"+source);
		source = source.toUpperCase();
		String []morse= {".－","－...","－.－.","－.."
						," ."," ..－.","－－.","...."
						,".."
						,".－－－"
						,"－.－"
						,".－.."
						,"－－"
						,"－."
						,"－－－"
						,".－－."
						,"－－.－"
						,".－."
						,"..."
						,"－"
						,"..－"
						,"...－"
						,".－－"
						,"－..－"
						,"－.－－"
						,"－－.."};
		String   result = "";
		for(int i=0;i<source.length();i++) {
			char ch = source.charAt(i);
			//System.out.println(ch);
			//System.out.println(ch-'A');
			result+=morse[ch-'A']+"\t";
		}
		System.out.println("result:"+result);
		

	}

}
