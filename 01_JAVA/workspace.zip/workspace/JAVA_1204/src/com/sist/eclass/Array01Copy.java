package com.sist.eclass;

public class Array01Copy {

	public static void main(String[] args) {
//		System.arraycopy( num,0,newNum,0,num.length)																
//		num[0] 에서			newNum[0]에				num.length 게만큼 copy					
//      char[] abc ;
//		abc =new char[4];
//      char[0] ='A';
//      char[1] ='B';
//      char[2] ='C';
//      char[3] ='D';
		
		char[] abc = {'A','B','C','D'};
		char[] num = {'0','1','2','3','4','5','6','7','8','9'};
		
		char[] result=new char[abc.length+num.length];
		
		
		for(int i=0;i<abc.length;i++) {
			System.out.println(abc[i]);
		}
		
		System.arraycopy(abc, 0, result, 0, abc.length);
		
		System.arraycopy(num, 0, result, abc.length, num.length);
		
		//향상된 for
		for(char tmp:result) {
			System.out.print(tmp);
		}
		
		

	}

}
