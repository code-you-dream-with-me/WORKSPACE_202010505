package com.sist.eclass.exam;

import java.util.Arrays;

public class Exam5_5 {

	public static void main(String[] args) {
		int []ballArray= {1,2,3,4,5,6,7,8,9};
		int []ball3=new int[3];
		//ballArray구해서 자리 바꿈을 한다.
		for(int i=0;i<ballArray.length;i++) {
			
			int j=(int)(Math.random()*ball3.length);
			int tmp = 0;
			tmp = ballArray[i];
			ballArray[i] = ballArray[j];
			ballArray[j] = tmp;
			
		}
		
		
		System.out.println(Arrays.toString(ballArray));
		System.out.println("ball3:"+Arrays.toString(ball3));
		
		//ballArray copy 3개의 수를 ball3로 복사한다.
		System.arraycopy(ballArray, 0, ball3, 0, ball3.length);
		
		for(int i=0;i<ball3.length;i++) {
			System.out.print(ball3[i]);
		}
		
		

	}

}
