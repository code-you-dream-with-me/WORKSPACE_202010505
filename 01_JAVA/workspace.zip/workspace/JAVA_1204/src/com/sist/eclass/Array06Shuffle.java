package com.sist.eclass;

public class Array06Shuffle {

	public static void main(String[] args) {
		// 1~45 사이에서 중복되지 않은 숫자 6개 추출
		int[] ball=new int[45];
		
		for(int i=0;i<ball.length;i++) {
			ball[i] = i+1;
		
		}
		//자리바꿈
		for(int j=0;j<6;j++) {
			int n = (int)(Math.random()*45);//0<=x<45
			System.out.println(n);
			
			int tmp = ball[j];
			ball[j] = ball[n];
			ball[n] = tmp;
		}
		
		//소트전,
		for(int i=0;i<6;i++) {
			System.out.printf("ball[%d]=%d\n",i,ball[i]);
		}
		//버블 sort
		for(int i=0;i<6-1;i++) {
			for(int j=0;j<6-1-i;j++) {
				if(ball[j] > ball[j+1]) {//앞에 값이 크면 자리를 바꾸어라
					 int tmp = ball[j];
					 ball[j] = ball[j+1];
					 ball[j+1] = tmp;
				}
			}		
		}	
		
		System.out.println();
		//버블 소트 이후
		for(int i=0;i<6;i++) {
			System.out.printf("ball[%d]=%d\n",i,ball[i]);
		}		

	}
//	ball[0]=8
//	ball[1]=27
//	ball[2]=41
//	ball[3]=33
//	ball[4]=16
//	ball[5]=17
	
//	ball[0]=34
//	ball[1]=18
//	ball[2]=2
//	ball[3]=45
//	ball[4]=6
//	ball[5]=28	
}
