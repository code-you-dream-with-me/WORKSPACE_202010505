package com.sist.eclass.string;

public class Array10String {

	public static void main(String[] args) {
		String [] name =new String[3];						
		name[0] = "Kim";
		name[1] = "Lee";
		name[2] = "Park";
		
		for(int i=0;i<name.length;i++) {
			System.out.printf("name[%d]=%s\n",i,name[i]);
		}

		
		String tmp = name[1];
		System.out.println("tmp:"+tmp);
		
		name[1] = "Yu";
		//향상된 for
		for(String str:name) {
			System.out.println(str);
		}
		
	}

}
