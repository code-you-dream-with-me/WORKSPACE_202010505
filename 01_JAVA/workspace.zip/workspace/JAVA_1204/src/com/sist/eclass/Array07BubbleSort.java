package com.sist.eclass;

import java.util.Arrays;

public class Array07BubbleSort {

	public static void main(String[] args) {
		//버블 소트																																							
//		버블 정렬(bubble sort) 알고리즘의 구체적인 개념																																					
//		버블 정렬은 첫 번째 자료와 두 번째 자료를, 두 번째 자료와 세 번째 자료를, 세 번째와 네 번째를, … 이런 식으로 (마지막-1)번째 자료와 마지막 자료를 비교하여 교환하면서 자료를 정렬한다.																																					
//		1회전을 수행하고 나면 가장 큰 자료가 맨 뒤로 이동하므로 2회전에서는 맨 끝에 있는 자료는 정렬에서 제외되고, 2회전을 수행하고 나면 끝에서 두 번째 자료까지는 정렬에서 제외된다. 이렇게 정렬을 1회전 수행할 때마다 정렬에서 제외되는 데이터가 하나씩 늘어난다.																																					

		int [] numArr = {7,4,5,1,3};
		
		System.out.println(Arrays.toString(numArr));
		System.out.println("========================");
		for(int i=0;i<numArr.length-1;i++) {
			for(int j=0;j<numArr.length-1-i;j++) {
				//조건{
				// 자리바꿈
				//}
				if(numArr[j] > numArr[j+1]) {//앞에 값이 크면 자리를 바꾸어라
					 int tmp = numArr[j];
					 numArr[j] = numArr[j+1];
					 numArr[j+1] = tmp;
				}
			}
			System.out.println(Arrays.toString(numArr));
			
		}//for i
		
		System.out.println(Arrays.toString(numArr));
		
		

	}

}







