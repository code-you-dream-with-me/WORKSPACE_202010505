package com.sist.eclass.string;

public class Array15Args {

	public static void main(String[] args) {
		
		if(null !=args) {//param 없으면 찍지 마세요.
			System.out.println("args.length:"+args.length);
			for(int i=0;i<args.length;i++) {
				System.out.println(args[i]);
			}
		}

	}

}
