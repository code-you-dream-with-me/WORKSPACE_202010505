package com.sist.eclass.rethrowing;

public class ReThrowingMain {

	public static void main(String[] args) {
		
		try {
			method01();
		} catch (Exception e) {
			System.out.println("main에서 예외처리!!!!");
			e.printStackTrace();
		}
		
	}
	
	static void method01() throws Exception {
		try {
			throw new Exception("ReThrowing 발생");
		}catch(Exception e) {
			System.out.println("method01()에서 예외 처리!");
			throw e;
		}
	}

}
