package com.sist.eclass.object07;

public class Circle implements Cloneable {
 //Cloneable 내용이 없음: 개발자가 상속을 받았으면 객체 copy를 허용 한다.
	
	Point p;//원점
	double r;//반지름
	
	public Circle(Point p, double r) {
		super();
		this.p = p;
		this.r = r;
	}
	
	/**
	 * 얕은복사
	 * @return
	 */
	public Circle shallowCopy() {
		
		Object obj = null;
		
		try {
			obj = super.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		
		return (Circle)obj;
	}
	
	
	
	public Circle deepCopy() {
		Object obj = null;
		
		try {
			obj = super.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}		
		
		Circle c = (Circle) obj;
		c.p = new Point(this.p.x, this.p.y);
		
		return c;
	}

	@Override
	public String toString() {
		return "Circle [p=" + p + ", r=" + r + "]";
	}
	
	
	
	
	
}
