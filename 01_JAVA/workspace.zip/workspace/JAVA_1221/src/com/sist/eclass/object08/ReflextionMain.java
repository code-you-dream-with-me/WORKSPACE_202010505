package com.sist.eclass.object08;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class ReflextionMain {

	public static void main(String[] args) {
//		리플렉션(Reflection)이란?
//				자바에서 제공하는 리플렉션(Reflection)은 C, C++과 같은 언어를 비롯한 다른 언어에서는 볼 수 없는 기능입니다. 
//		이미 로딩이 완료된 클래스에서 또 다른 클래스를 동적으로 로딩(Dynamic Loading)하여 생성자(Constructor), 멤버 필드(Member Variables) 
//		그리고 멤버 메서드(Member Method) 등을 사용할 수 있도록 합니다.
//
//		그러니까, 컴파일 시간(Compile Time)이 아니라 실행 시간(Run Time)에 동적으로 특정 클래스의 
//		정보를 객체화를 통해 분석 및 추출해낼 수 있는 프로그래밍 기법이라고 표현할 수 있습니다.
		
		
		Class<?> cls;
		try {
			cls = Class.forName("com.sist.eclass.object08.Card");
		
			// 객체 생성
			Object obj = cls.newInstance();
			
			//quizClass Method 객체 생성
			Method method = cls.getMethod("quizClass");
			//System.out.println(method.getName());
			
			//호출
			System.out.println(method.invoke(obj));
		
		} catch (Exception e) {
			//e.printStackTrace();
		}
	}

}
