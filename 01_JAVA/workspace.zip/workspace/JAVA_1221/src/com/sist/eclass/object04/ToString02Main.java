package com.sist.eclass.object04;
import java.util.Date;
public class ToString02Main {

	public static void main(String[] args) {
		String str=new String("eClass");
		Date  date=new Date();
		
		System.out.println("str:"+str.toString());
		System.out.println("date:"+date.toString());
	}
}
