package com.sist.eclass.object09.string;

public class StringEx01Main {

	public static void main(String[] args) {
		String str1="abc";
		String str2="abc";
		//'- 문자열의 비교 : equals사용('==' 금지)
		System.out.println("str1==str2=>"+(str1==str2));

		System.out.println("str1.equals(str2)=>"+(str1.equals(str2)));
		
		String str3=new String("abc");
		String str4=new String("abc");

		
		System.out.println("str3==str4=>"+(str3==str4));
		System.out.println("str3.equals(str4)=>"+(str3.equals(str4)));
	}

}
