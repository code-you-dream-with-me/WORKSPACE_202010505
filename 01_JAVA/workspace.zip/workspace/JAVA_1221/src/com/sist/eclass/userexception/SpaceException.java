package com.sist.eclass.userexception;

public class SpaceException extends Exception {

	public SpaceException(String msg) {
		super(msg);
	}
	
}
