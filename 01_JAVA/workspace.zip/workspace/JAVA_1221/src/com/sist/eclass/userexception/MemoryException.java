package com.sist.eclass.userexception;

public class MemoryException extends Exception {

	
	public MemoryException(String msg) {
		super(msg);
	}
}
