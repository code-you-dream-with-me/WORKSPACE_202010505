package com.sist.eclass.object07;

public class DeepShallowCopyMain {

	public static void main(String[] args) {
		Circle c01=new Circle(new Point(1,1), 2.0);
		
		Circle cs02 =c01.shallowCopy();
		
		//Point 새로은 객체를 생성.
		Circle cd03 =c01.deepCopy();
		
		System.out.println("c01:"+c01.toString());
		System.out.println("cs02:"+cs02.toString());
		System.out.println("cd03:"+cd03.toString());
		
		System.out.println("=====================");
		c01.p.x = 9;
		c01.p.y = 9;
		System.out.println("c01:"+c01.toString());
		System.out.println("cs02:"+cs02.toString());
		System.out.println("cd03:"+cd03.toString());
	}

}
//c01:Circle [p=Point [x=1, y=1], r=2.0]
//cs02:Circle [p=Point [x=1, y=1], r=2.0]
//cd03:Circle [p=Point [x=1, y=1], r=2.0]
//=====================
//c01:Circle [p=Point [x=9, y=9], r=2.0]
//cs02:Circle [p=Point [x=9, y=9], r=2.0]
//cd03:Circle [p=Point [x=1, y=1], r=2.0]