package com.sist.eclass.object08;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class ClassMain {

	public static void main(String[] args) throws NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException, ClassNotFoundException {
//		- 자신이 속한 클래스의 정보를 Class객를 반환하는 메서드									
//		( 메모리에 로딩된 클래스정보: Class)									
//		-Class 클래스당 1개만 존재, 클래스의 모든 정보를 담고 있다.									

//		Class obj01 = new Card().getClass();//생성된 객체로 부터
//		Class obj02 = Card.class;//클래스 리터럴로 부터 생성
//		Class obj03 = Class.forName("Card");//클래스 이름으로 부터,JDBC Driver연결시 사용.
//		Class obj04 =Card.class.newInstance();
//
//		리플렉션: 동적 객체 생성 사용.(Spring 기반 기술)

		Card c=new Card("HEART",3);
		
		System.out.println(c.toString());//Card [kind=HEART, number=3]
		try {
			Card c2=Card.class.newInstance();
			System.out.println(c2.toString());//Card [kind=SPACE, number=1]
			
			
			//메모리에 로딩된 클래스정보
			Class cObj = c.getClass();
			//com.sist.eclass.object08.Card
			System.out.println(cObj.getName());
			
			//public class com.sist.eclass.object08.Card
			System.out.println(cObj.toGenericString());
			
			//class com.sist.eclass.object08.Card
			System.out.println(cObj.toString());
			

			
			
			
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		
		
		
		
		
		
		
	}

}
