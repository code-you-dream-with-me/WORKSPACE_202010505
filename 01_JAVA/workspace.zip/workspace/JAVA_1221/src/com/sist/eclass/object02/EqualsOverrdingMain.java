package com.sist.eclass.object02;

public class EqualsOverrdingMain {

	public static void main(String[] args) {
		Person p01=new Person(900101234567L);
		Person p02=new Person(900101234567L);
		
		System.out.println("p01:"+p01);
		System.out.println("p02:"+p02);
		if(p01==p02) {
			System.out.println("p01과 p02는 같다.");
		}else {
			System.out.println("p01과 p02는 다르다.");
		}
		
		System.out.println("=========================");
		
		
		////Person equals 호출.
		if(p01.equals(p02)) {
			System.out.println("p01과 p02는 같다.");
		}else {
			System.out.println("p01과 p02는 다르다.");
		}
		

	}

}
