package com.sist.eclass.resource;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class WithResourceMain02 {

	public static void main(String[] args) {


//자동 자원 반납: try -with -resources문							
//		AutoCloseable이라는 인터페이스를 구현한 것이어야만 한다.											
//		(FileInputStream, DataInputStream…)											
// finally에서 명시적으로 자원 반납 불필요.
		try(FileInputStream fis=new FileInputStream("score.dat");
			DataInputStream dis =	new DataInputStream(fis)
				) {

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}

	}

}
