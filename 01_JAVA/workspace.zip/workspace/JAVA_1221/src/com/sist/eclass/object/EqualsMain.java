package com.sist.eclass.object;

public class EqualsMain {

	public static void main(String[] args) {
		Value v01=new Value(10);
		Value v02=new Value(10);
		
		//v01과 v02는 다르다.
		if(v01.equals(v02)) {
			System.out.println("v01과 v02는 같다.");
		}else {
			System.out.println("v01과 v02는 다르다.");
		}
		
		
		//v01과 v02는 같다.
		v02 = v01;
		if(v01.equals(v02)) {
			System.out.println("v01과 v02는 같다.");
		}else {
			System.out.println("v01과 v02는 다르다.");
		}		

	}

}
