package com.sist.eclass.object06;

public class CloneMain {

	public static void main(String[] args) {
		Point p=new Point(9,11);		
		Point copy = p.clone();

		System.out.println("org:"+p.toString());
		System.out.println("copy:"+copy);		
		
	}

}

