package com.sist.eclass.object04;

public class ToStringMain {

	public static void main(String[] args) {
		Card c01=new Card();
		Card c02=new Card();
		//public String toString() {
        //return getClass().getName() + "@" + Integer.toHexString(hashCode());
    
		/**
		 * c01과 c02는 다르다.
		 * com.sist.eclass.object04.Card@15db9742
           com.sist.eclass.object04.Card@6d06d69c
           c01 -> c01.toString()
		 */
		System.out.println(c01);
		System.out.println(c02.toString());
	}

}
