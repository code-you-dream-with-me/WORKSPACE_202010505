package com.sist.eclass.object09.string;

public class StringEx02Main {

	public static void main(String[] args) {
		String s01="AAA";
		String s02="AAA";
		String s03="BBB";
	}

}