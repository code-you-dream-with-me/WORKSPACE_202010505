package com.sist.eclass.finallyy;

public class FinallyMain {

	public static void main(String[] args) {

		//프로그램 설치, 파일을 시스템으로 복사, 설치가 완료되면
		//임시파일들 삭제(finally).
		try {
			statIntall();
			copyFiles();
		}catch(Exception e) {
			//deleteTempFiles();//예외가 발생한 경우 임시파일 삭제.
		}finally {
			deleteTempFiles();
		}
		
	}
	
	static void statIntall() {
		//프로그램 설치에 필요한 준비코드
	}
	
	static void copyFiles() {
		//프로그램을 시스템으로 copy
	}
	
	static void deleteTempFiles() {
		//임시파일들 삭제
	}
}


