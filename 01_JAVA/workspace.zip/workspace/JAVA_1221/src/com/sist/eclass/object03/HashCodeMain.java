package com.sist.eclass.object03;

public class HashCodeMain {
	/**
	 * -객체의 해시코드(int타입의 정수)를 반환하는 메서드(해시함수 사용) 다량의 데이터를 저장&검색하는 기법
	 * - Object클래스의 hashCode()는 객체의 내부주소를 반환 
	 * - equals를 오버라이딩하면, hashCode()를 같이 오버라이딩 해야 한다.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		String str01 = new String("abc");
		String str02 = new String("abc");
		// str01과 str02는 같다.
		System.out.println("str01.equals(str02):" + str01.equals(str02));

		System.out.println("str01.hashCode():" + str01.hashCode());
		System.out.println("str02.hashCode():" + str02.hashCode());

		
		System.out.println("str01:" + str01);
		System.out.println("str02:" + str02);
		
		//객체의 주소값으로 해시코드를 생성.
		System.out.println(System.identityHashCode(str01));//366712642
		System.out.println(System.identityHashCode(str02));//1829164700
		
		
	}

}
