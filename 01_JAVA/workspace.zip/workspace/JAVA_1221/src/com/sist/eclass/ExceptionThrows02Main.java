package com.sist.eclass;

public class ExceptionThrows02Main {

	public static void main(String[] args) {
		
		method01();
	}

	static void method01(){
		try {
			throw new Exception("method01() 발생");
		}catch(Exception e) {
			System.out.println("method01()에서 예외처리");
			e.printStackTrace();
		}
	}
}
//method01()에서 예외처리
//java.lang.Exception: method01() 발생
//	at com.sist.eclass.ExceptionThrows02Main.method01(ExceptionThrows02Main.java:12)
//	at com.sist.eclass.ExceptionThrows02Main.main(ExceptionThrows02Main.java:7)