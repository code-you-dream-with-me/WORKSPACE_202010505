package com.sist.eclass.object06;

public class Point implements Cloneable{

	int x;  
	int y;    
	public Point(int x, int y) {

		this.x = x;
		this.y = y;
	}
	
	
	
	
	/**
	 * protected -> public
	 * CloneNotSupportedException 예외처리
	 * 
	 * protected native Object clone() throws CloneNotSupportedException;
	 */
	@Override
	public Point clone()  {
		Object obj = null;
		try {
			obj = super.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		
		return (Point)obj;
	}





	@Override
	public String toString() {
		return "Point [x=" + x + ", y=" + y + "]";
	}
	
	
	
	
}
