package com.sist.eclass.object08;

//Ctrl+shift+R : 클래스 찾기
public class Card {
	String kind;
	int number;
	
	public Card() {
		this("SPACE",1);
	}
	
	public Card(String kind, int number) {
		super();
		this.kind = kind;
		this.number = number;
	}

	@Override
	public String toString() {
		return "Card [kind=" + kind + ", number=" + number + "]";
	}
	
	public String quizClass() {
		System.out.println("quizClass() 실행");
		return "Card.quizClass()";
	}
	
}
