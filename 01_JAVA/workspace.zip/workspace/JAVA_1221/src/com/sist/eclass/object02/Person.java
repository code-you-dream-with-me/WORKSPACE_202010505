package com.sist.eclass.object02;

public class Person {

	long id;
	String passwd;

	public Person(long id) {
		this.id = id;
	}

	//Object equals 오버라이딩.
	public boolean equals(Object obj) {
		if(null !=obj && obj instanceof Person) {
			return id == ((Person)obj).id;
		}else {
			return false;
		}
	}

	
	
}
