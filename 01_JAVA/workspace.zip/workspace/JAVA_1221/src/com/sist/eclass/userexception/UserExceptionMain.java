package com.sist.eclass.userexception;

public class UserExceptionMain {

	public static void main(String[] args) {
		try {
			statIntall();
			copyFiles();
		}catch(MemoryException e) {
			//deleteTempFiles();//예외가 발생한 경우 임시파일 삭제.
			System.out.println("main MemoryException 처리");
			e.printStackTrace();
		}finally {
			deleteTempFiles();
		}
		
	}
	
	static void statIntall() throws MemoryException {
		//프로그램 설치에 필요한 준비코드
		//예외 발생
		throw new MemoryException("메모리가 부족 합니다.\n 메모리를 확보해 주세요.");
	}
	
	static void copyFiles() {
		//프로그램을 시스템으로 copy
	}
	
	static void deleteTempFiles() {
		//임시파일들 삭제
	}

}
