package com.sist.eclass;

public class ExceptionThrowsMain {

	public static void main(String[] args)  {
		
		try {
			mehtod01();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	static void mehtod01() throws Exception{
		mehtod02();
	}
	
	static void mehtod02() throws Exception{
		throw new Exception("mehtod02 예외 발생");
	}
}
//Exception in thread "main" java.lang.Exception: mehtod02 예외 발생
//at com.sist.eclass.ExceptionThrowsMain.mehtod02(ExceptionThrowsMain.java:16)
//at com.sist.eclass.ExceptionThrowsMain.mehtod01(ExceptionThrowsMain.java:12)
//at com.sist.eclass.ExceptionThrowsMain.main(ExceptionThrowsMain.java:7)