package com.sist.eclass.object05;

public class CloneMain {

	public static void main(String[] args) {
		Point p=new Point(9,11);		
		Point copy = (Point) p.clone();

		System.out.println("org:"+p.toString());
		System.out.println("copy:"+copy);		
		
	}

}

