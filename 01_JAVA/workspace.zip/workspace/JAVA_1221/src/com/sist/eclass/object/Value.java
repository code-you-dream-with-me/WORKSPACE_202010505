package com.sist.eclass.object;

public class Value {
	int value ;
	
	public Value(int value) {
		this.value = value;
	}
}
