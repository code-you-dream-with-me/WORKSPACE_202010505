package com.sist.eclass.properties04;
import java.io.*;
import java.util.Properties;
public class PropertiesEx04Main {

	public static void main(String[] args) {
		// /JAVA_0106/eclass_dev.properties
		
		String propPath = "eclass_dev.properties";
		Properties  properties=new Properties();
		
		FileInputStream  fis = null;
		BufferedInputStream  bis= null;
		try {
			fis=new FileInputStream(propPath);
			bis=new BufferedInputStream(fis);
			
			//파일 read
			properties.load(bis);
			System.out.println("version:"+properties.getProperty("version"));
			System.out.println("class:"+properties.getProperty("class"));
		}catch(IOException e) {
			System.out.println("=====================");
			System.out.println("=IOException="+e.getMessage());
			System.out.println("=====================");
		}finally {
			if(null !=bis) {
				try {
					bis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		System.out.println("파일 Read:"+propPath);

	}

}
