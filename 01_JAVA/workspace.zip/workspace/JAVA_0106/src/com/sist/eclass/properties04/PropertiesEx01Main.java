package com.sist.eclass.properties04;
import java.util.Enumeration;
import java.util.Properties;
public class PropertiesEx01Main {

	public static void main(String[] args) {
//		Hashtable을 상속받아 구현,key,value를 (String,String)로 저장												
//		app의 환경설정에 관련된 속성, 다국어 처리												
		
		
		Properties  prop=new Properties();
		//properties에 추가
		prop.setProperty("language", "JAVA");
		prop.setProperty("WORKING DAY", "28");
		prop.setProperty("CLAS", "E");
		prop.setProperty("CLAS", "E2");
		
		//데이터 조회
		//KeyS
		Enumeration e =prop.propertyNames();
		while(e.hasMoreElements()) {
			String key = (String) e.nextElement();
			//value 가지고 오기
			System.out.println(key+","+prop.getProperty(key));
		}
		
		System.out.println(prop);
		
		prop.list(System.out);

	}

}
