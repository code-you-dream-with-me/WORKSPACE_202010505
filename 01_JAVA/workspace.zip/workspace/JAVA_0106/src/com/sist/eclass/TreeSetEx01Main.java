package com.sist.eclass;
import java.util.*;

public class TreeSetEx01Main {

	public static void main(String[] args) {
		//TreeSet 검색: subSet()을 이용한 범위 검색
		// 시작은 포함, 끝은 미포함.
		
		String from = "b";
		String to = "c";
		
		TreeSet  set=new TreeSet();
		set.add("abc");
		set.add("alien");
		set.add("bat");
		set.add("car");
		set.add("Car");
		set.add("disc");
		
		System.out.println(set);
		System.out.println(set.subSet(from, to));//c 미포함
		System.out.println(set.subSet(from, to+"c"));//c포함

	}

}
