package com.sist.eclass.hashmap;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
public class HashMapEx01Main {

	public static void main(String[] args) {
		HashMap  map =new HashMap();
		//데이터 추가
		//순서 유지 되지 않으며, 키는 중복을 허용하지 않고, 값은 중복을 허용.													
		map.put("JAVA", new Integer(90));
		map.put("ORACLE", new Integer(95));
		map.put("HTML", new Integer(85));
		map.put("JAVASCRIPT", new Integer(92));
		map.put("JSP", new Integer(91));
		map.put("SPRING", new Integer(98));
		
		//전체를 반복문 돌려서 출력
		int total = 0;
		Set set = map.entrySet();
		Iterator iter = set.iterator();
		//Entry:key,value로 값 출력
		while(iter.hasNext()) {
			Map.Entry entiry=(Entry) iter.next();
			System.out.println("과목:"+entiry.getKey()+","+entiry.getValue());
		}
		
		
		//key로 값 출력
		Set keys = map.keySet();
		//System.out.println(keys);
		Iterator keyIter = keys.iterator();
		while(keyIter.hasNext()) {
			String key = (String) keyIter.next();
			System.out.print(key);
			int value =  (int) map.get(key);
			System.out.println(","+value);
			
			total+=value;
		}
		System.out.println("총합:"+total);
		System.out.println("평균:"+ ( (float)total/map.size())  );
		
		Collection  col=map.values();
		System.out.println("최대값:"+Collections.max(col));
		System.out.println("최소값:"+Collections.min(col));

	}

}
