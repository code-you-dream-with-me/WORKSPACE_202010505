package com.sist.eclass.hashmap02;
import java.util.HashMap;
import java.util.Iterator;
public class HashMapEx02Main {

	public static void main(String[] args) {
		// 빈도수 구하기
		String[] data = {"A","K","A","A","D","A","K","K","Z","D"};
		
		HashMap map=new HashMap<String, Integer>();
		
		for(int i=0;i<data.length;i++) {
			//map key존재 파악
			if(map.containsKey(data[i])) {
				Integer value = (Integer) map.get(data[i]);
				
				map.put(data[i],new Integer(value.intValue()+1));
			}else {//신규로 추가
				map.put(data[i], new Integer(1));
				
			}
		}//for i
		
		
		Iterator iter = map.keySet().iterator();
		while(iter.hasNext()) {
			String key = (String) iter.next();
			System.out.println(key+" : "+printStar((Integer)map.get(key))+" "+map.get(key));
		}//--while
//		A : ****
//		D : **
//		Z : *
//		K : ***

	}//--main

	public static String printStar(int num) {
		char[]   sh=new char[num];
		for(int i=0;i<sh.length;i++) {
			sh[i]='*';
		}
		
		
		return new String(sh);
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
