package com.sist.eclass.treemap03;
import java.util.Iterator;
import java.util.TreeMap;
public class TreeMapEx01Main {

	public static void main(String[] args) {
//		이진 검색트리의 형태로 키와 값 쌍으로 저장.												
//		TreeSet처럼 데이터를 정렬(키)해서 저장(저장시간이 오래 걸린다.)												
//		TreeMap은 정렬이나 범위 검색에 유리												

		// 빈도수 구하기
		String[] data = {"A","K","A","A","D","A","K","K","Z","D"};
		
		TreeMap map=new TreeMap<String, Integer>();
		
		for(int i=0;i<data.length;i++) {
			//map key존재 파악
			if(map.containsKey(data[i])) {
				Integer value = (Integer) map.get(data[i]);
				
				map.put(data[i],new Integer(value.intValue()+1));
			}else {//신규로 추가
				map.put(data[i], new Integer(1));
				
			}
		}//for i
		
		
		Iterator iter = map.keySet().iterator();
		while(iter.hasNext()) {
			String key = (String) iter.next();
			System.out.println(key+" : "+printStar((Integer)map.get(key))+" "+map.get(key));
		}//--while
//		A : **** 4
//		D : ** 2
//		K : *** 3
//		Z : * 1

	}//--main

	public static String printStar(int num) {
		char[]   sh=new char[num];
		for(int i=0;i<sh.length;i++) {
			sh[i]='*';
		}
		
		
		return new String(sh);
	}
	
	
	
	
	
	
	
	

}
