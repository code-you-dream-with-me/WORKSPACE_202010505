package com.sist.eclass.properties04;
import java.util.Properties;
public class PropertiesEx02Main {

	public static void main(String[] args) {
		//java 시스템 properties read
		Properties sysProp = System.getProperties();
		System.out.println(sysProp.getProperty("java.version"));//1.8.0_251
		System.out.println(sysProp.getProperty("user.dir"));//D:\20201123_eClass\01_JAVA\workspace\JAVA_0106
		
		//내용 전체 출력
		sysProp.list(System.out);
		/*
		1.8.0_251
		D:\20201123_eClass\01_JAVA\workspace\JAVA_0106
		-- listing properties --
		java.runtime.name=Java(TM) SE Runtime Environment
		sun.boot.library.path=C:\Program Files\Java\jre1.8.0_251\bin
		java.vm.version=25.251-b08
		java.vm.vendor=Oracle Corporation
		java.vendor.url=http://java.oracle.com/
		path.separator=;
		java.vm.name=Java HotSpot(TM) 64-Bit Server VM
		file.encoding.pkg=sun.io
		user.script=
		user.country=KR
		sun.java.launcher=SUN_STANDARD
		sun.os.patch.level=
		java.vm.specification.name=Java Virtual Machine Specification
		user.dir=D:\20201123_eClass\01_JAVA\workspace\...
		java.runtime.version=1.8.0_251-b08
		java.awt.graphicsenv=sun.awt.Win32GraphicsEnvironment
		java.endorsed.dirs=C:\Program Files\Java\jre1.8.0_251\li...
		os.arch=amd64
		java.io.tmpdir=C:\Users\sist\AppData\Local\Temp\
		line.separator=

		java.vm.specification.vendor=Oracle Corporation
		user.variant=
		os.name=Windows 10
		sun.jnu.encoding=MS949
		java.library.path=C:\Program Files\Java\jre1.8.0_251\bi...
		java.specification.name=Java Platform API Specification
		java.class.version=52.0
		sun.management.compiler=HotSpot 64-Bit Tiered Compilers
		os.version=10.0
		user.home=C:\Users\sist
		user.timezone=
		java.awt.printerjob=sun.awt.windows.WPrinterJob
		file.encoding=UTF-8
		java.specification.version=1.8
		user.name=sist
		java.class.path=D:\20201123_eClass\01_JAVA\workspace\...
		java.vm.specification.version=1.8
		sun.arch.data.model=64
		java.home=C:\Program Files\Java\jre1.8.0_251
		sun.java.command=com.sist.eclass.properties04.Properti...
		java.specification.vendor=Oracle Corporation
		user.language=ko
		awt.toolkit=sun.awt.windows.WToolkit
		java.vm.info=mixed mode
		java.version=1.8.0_251
		java.ext.dirs=C:\Program Files\Java\jre1.8.0_251\li...
		sun.boot.class.path=C:\Program Files\Java\jre1.8.0_251\li...
		java.vendor=Oracle Corporation
		file.separator=\
		java.vendor.url.bug=http://bugreport.sun.com/bugreport/
		sun.cpu.endian=little
		sun.io.unicode.encoding=UnicodeLittle
		sun.desktop=windows
		sun.cpu.isalist=amd64
		*/
	}

}
