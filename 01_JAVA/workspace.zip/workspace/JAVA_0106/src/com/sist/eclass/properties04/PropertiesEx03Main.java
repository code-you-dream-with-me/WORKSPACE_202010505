package com.sist.eclass.properties04;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;
public class PropertiesEx03Main {

	public static void main(String[] args) {
		// 파일에 properites기록

		Properties  prop=new Properties();
		
		prop.setProperty("timeout", "10");
		prop.setProperty("class", "eClass반");
		prop.setProperty("version", "0.1");
		prop.setProperty("writer", "james");
		
		
		try {
			// ouput.properties
			prop.store(new FileOutputStream("ouput.properties"), "eClass Config");
			
			//xml
			prop.storeToXML(new FileOutputStream("ouput.xml"), "eClass Config");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("파일 ouput.properties 생성 새로고침 하세요");
	}

}
