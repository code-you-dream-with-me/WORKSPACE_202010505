package com.sist.eclass02;

public class Shape {
   String color = "black";
   
   void draw() {
	   System.out.printf("[color=%s]%n",color);
   }
}
