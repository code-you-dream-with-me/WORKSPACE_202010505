package com.sist.eclass;

public class CaptionTvMain {

	public static void main(String[] args) {
		CaptionTv cTv=new CaptionTv();
		cTv.channel = 11;
		cTv.channelUp();
		System.out.println(cTv.channel);
		cTv.displayCaption("0 Hello,world");
		
		cTv.caption = true;
		cTv.displayCaption("1 Hello,world"); 
	}

}