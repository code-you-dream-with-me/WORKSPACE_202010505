package com.sist.eclass;

import org.apache.log4j.Logger;

public class CaptionTv extends Tv{
	final Logger LOG = Logger.getLogger(CaptionTv.class);
	boolean caption;//ĸ�ǻ���
	
	void displayCaption(String text) {
		if(caption == true) {
			LOG.debug(text);
		}
	}

	

}
