package com.sist.eclass03;

import static com.sist.eclass03.Card.KIND_MAX;
import static com.sist.eclass03.Card.NUM_MAX;

public class Deck {
	final int CARD_NUM = 52;
	//final int CARD_NUM = KIND_MAX*NUM_MAX;
	Card cardArr[]=new Card[CARD_NUM];
	
	public Deck() {
		//52�� ī�� �ʱ�ȭ(����,����)
		int i = 0;
		//Card.KIND_MAX=4, Card.NUM_MAX =13
		System.out.println("Card.KIND_MAX:"+Card.KIND_MAX);
		System.out.println("Card.NUM_MAX:"+Card.NUM_MAX);
		for(int k=Card.KIND_MAX;k>0;k--) {
			for(int n=0;n<Card.NUM_MAX;n++) {
				cardArr[i++]=new Card(k, n+1);
				//System.out.println(i);
			}	
		}
	
	}   
	
	void shuffle() {//ī�� ���� ����
		
		for(int i=0;i<CARD_NUM;i++) {
			int r = (int)(Math.random()*CARD_NUM);
			Card tmp = cardArr[i];
			cardArr[i] = cardArr[r];
			cardArr[r] = tmp;
		}
		
		
		
	}
	
	Card pick(int index) {
		return cardArr[index];
	}
	
	Card pick() {
		
		int n = (int)(Math.random()*CARD_NUM);
		return pick(n);
	}

	
	
	
	
	
	
	
	
}
