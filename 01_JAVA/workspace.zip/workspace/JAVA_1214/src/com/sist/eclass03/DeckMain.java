package com.sist.eclass03;

public class DeckMain {

	public static void main(String[] args) {
		Deck  d=new Deck();
		Card  c= d.pick(0);
		
		System.out.println(c.toString());
		
		Card c01=d.pick();
		System.out.println(c01.toString());
		
		//ī�� ����
		d.shuffle();
		Card  c02= d.pick(0);
		System.out.println(c02.toString());
		
	}

}
