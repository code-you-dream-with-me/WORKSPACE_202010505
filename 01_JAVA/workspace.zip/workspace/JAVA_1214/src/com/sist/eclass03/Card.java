package com.sist.eclass03;

public class Card {
	int kind;
	int number;
	
	//���� ��
	public static final int KIND_MAX =4;
	//����
	public static final int NUM_MAX =13;
	
	//����:SPACE, DIMOND, HEART,CLOVER
	static final int SPACE = 4;
	static final int DIMOND = 3;
	static final int HEART = 2;
	static final int CLOVER = 1;
	
	public Card() {
		this(SPACE,1);
	}
	
	public Card(int kind,int number) {
		this.kind = kind;
		this.number = number;
	}
	
	public String toString() {
		//                [0] [1]      [2]        [3]    [4] 
		String[] kinds = {"","CLOVER", "DIMOND", "HEART","SPACE"};
		String numbers = "0123456789XJQK";
		
		return "kind:"+kinds[this.kind]+
				",number:"+numbers.charAt(this.number)  ;
	}

	
	

}
