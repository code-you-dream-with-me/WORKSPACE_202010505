/**
* <pre>
* com.sist.eclass.exam
* Class Name : Exam4_02.java
* Description:
* Author: james
* Since: 2020/12/02
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/02 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.exam;

import java.util.Scanner;

public class Exam4_14 {


	public static void main(String[] args) {
	    int answer = (int)(Math.random()*100)+1;//1~100사이의 임이의 값(0<=x<101)
	    int input  = 0;//사용자 입력 값
	    int count  = 0;//사용자 시도 횟수
	    
	    Scanner  scanner=new Scanner(System.in);
	    System.out.println("answer:"+answer);
	    do {
	    	count++;
	    	System.out.print("1~100사이 값을 입력 하세요.>>");
	    	input =scanner.nextInt();

	    	//answer>input
	    	//answer<input
	    	//answer==input{
	    	//break;
	    	//}
	    	if(answer>input) {
	    		System.out.println("입력 값이 작습니다.");
	    	}else if(answer<input) {
	    		System.out.println("입력 값이 크다.");
	    	}else if(answer==input) {
	    		System.out.println("맞췄 습니다.");
	    		System.out.println("시도 횟수는 "+count+"입니다.");
	    		break;
	    	}
	    	
	    }while(true);
	    
	    
	}//--main
}//--class








