/**
* <pre>
* com.sist.eclass.whiles
* Class Name : Flow13While.java
* Description:
* Author: james
* Since: 2020/12/02
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/02 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.whiles;

import java.util.Scanner;

/**
 * @author james
 *
 */
public class Flow13While {


	public static void main(String[] args) {
//		1 ~ 100사이 난수를 발생 													
//		숫자 맞추기													
//															
//		힌트로 입력된 숫자보다 크다/작다 메시지로 알려서 맞추기.		
		
//		System.out.println("Math.random():"+Math.random());//0.0<=x<1.0
//		System.out.println("Math.random()*100:"+(Math.random()*100));//0.0<=x<1.0
//		System.out.println("(int)Math.random()*100:"+(int)(Math.random()*100));//0.0<=x<1.0
//		System.out.println("(int)Math.random()*100+1:"+(int)(Math.random()*100+1));//0.0<=x<1.0

		int answer = 0;//답
		int input  = 0;//숫자 입력
		System.out.println("0/3="+(0/3));
		
		answer = (int)(Math.random()*100)+1;
		System.out.println("answer:"+answer);
		
		do {
			System.out.println("1 ~ 100사이 숫자를 입력 하세요.>>");
			Scanner scanner=new Scanner(System.in);
			input = scanner.nextInt();
			
			if(input>answer) {
				System.out.println("입력 숫자가 크다.");
			}else if(input<answer) {
				System.out.println("입력 숫자가 작다.");
				
			}
			
		}while(answer!=input);
		
		System.out.println("정답 입니다.\n프로그램 종료.");
		
	}

}
















