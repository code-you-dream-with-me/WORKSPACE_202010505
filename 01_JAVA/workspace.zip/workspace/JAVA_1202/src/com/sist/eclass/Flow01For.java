/**
* <pre>
* com.sist.eclass
* Class Name : Flow01For.java
* Description: for 별출력
* Author: james
* Since: 2020/12/02
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/02 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass;

public class Flow01For {

	public static void main(String[] args) {
//		*				
//		*	*			
//		*	*	*		
//		*	*	*	*	
//		*	*	*	*	*
		
		for(int i=1;i<=5;i++){
			
			for(int j=1;j<=i;j++) {
				System.out.print("*");
			}
			System.out.println();
			
		}

	}

}












