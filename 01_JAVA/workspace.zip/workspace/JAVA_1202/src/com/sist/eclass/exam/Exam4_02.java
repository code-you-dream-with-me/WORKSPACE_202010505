/**
* <pre>
* com.sist.eclass.exam
* Class Name : Exam4_02.java
* Description:
* Author: james
* Since: 2020/12/02
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/02 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.exam;


public class Exam4_02 {


	public static void main(String[] args) {
		int sum = 0;
		for(int i=1;i<=20;i++) {
			
			//System.out.println(i);
			//if(!(i%2==0 || i%3==0)) {
			if((i%2!=0 && i%3!=0)) { //== if(!(i%2==0 || i%3==0)) {
				System.out.println(i);
				sum+=i;
			}
		}
		
		System.out.printf("sum=%d",sum);
		
	}

}
