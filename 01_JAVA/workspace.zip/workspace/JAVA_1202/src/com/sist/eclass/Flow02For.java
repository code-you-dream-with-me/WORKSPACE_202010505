/**
* <pre>
* com.sist.eclass
* Class Name : Flow01For.java
* Description: for 별출력
* Author: james
* Since: 2020/12/02
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/02 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass;

import java.util.Scanner;

public class Flow02For {

	public static void main(String[] args) {
        int num = 0;//별 출력 숫자
        System.out.print("* 별 출력할 라인수를 입력 하세요.>>");
		Scanner scanner=new Scanner(System.in);
		
		num = scanner.nextInt();
		for(int i=1;i<=num;i++){
			
			for(int j=1;j<=i;j++) {
				System.out.print("*");
			}
			System.out.println();
			
		}

	}

}












