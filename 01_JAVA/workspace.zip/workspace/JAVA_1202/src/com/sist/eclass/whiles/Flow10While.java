/**
* <pre>
* com.sist.eclass.whiles
* Class Name : Flow08While.java
* Description: while
* Author: james
* Since: 2020/12/02
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/02 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.whiles;

public class Flow10While {

	public static void main(String[] args) {
//		while(조건){			
//			문장01;		
//			문장02;		
//			….		
//		}			

		int i =5;
		while(i != 0) {
			i--;
			System.out.println(i+"\t I can do it.");
		}
		
	}

}














