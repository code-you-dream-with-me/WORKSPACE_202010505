/**
* <pre>
* com.sist.eclass.exam
* Class Name : Exam4_02.java
* Description:
* Author: james
* Since: 2020/12/02
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/02 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.exam;


public class Exam4_13 {


	public static void main(String[] args) {
	    String value = "12o34";
	    char ch = ' ';
	    boolean isNumber = true;
	    
	    for(int i=0;i<value.length();i++) {
	    		ch = value.charAt(i);
	    		//System.out.println(ch);
	    		if( !(ch>='0' && ch<='9')) {
	    			System.out.println(ch);
	    			isNumber = false;
	    			break;
	    		}
	    }
	    
	    
	    if(isNumber==true) {
	    	System.out.println(value+"는 숫자 입니다.");
	    }else {
	    	System.out.println(value+"는 숫자가 아닙니다.");
	    }
	    
	    
	}//--main
}//--class








