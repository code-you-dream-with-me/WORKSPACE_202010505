/**
* <pre>
* com.sist.eclass.exam
* Class Name : Exam4_02.java
* Description:
* Author: james
* Since: 2020/12/02
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/02 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.exam;


public class Exam4_04 {


	public static void main(String[] args) {
//		1+(-2)+3+(-4)+……		
//		+  -   +  -
//		1. 1부터 n까지 1씩 증가 한다.(단 종료를 알 수 없다.)		
//				
//		2. 한번 씩 부호 반전이 일어 난다.		
//				(부호)1*i
//		3. 순서대로 더한 값이 100이상이 되면 for문을 벗어 나시오.		
//			break;
		int sum = 0;
		for(int i=1,s=1;true;i++,s=-s) {//조건식 생략;; true
			
			System.out.println(i+","+s);
			
			sum+=s*i;//sum=sum+(s*i)
			if(sum>=100) {
				System.out.println(sum);
				break;
			}
		}
		
	}

}








