/**
* <pre>
* com.sist.eclass.exam
* Class Name : Exam4_02.java
* Description:
* Author: james
* Since: 2020/12/02
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/02 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.exam;


public class Exam4_09 {


	public static void main(String[] args) {
//		[4-9] 숫자로 이루어진 문자열 str이 있을 때, 각 자리의 합을 더한 결과를 출력하는 코
//		드를 완성하라. 만일 문자열이 "12345"라면, ‘1+2+3+4+5’의 결과인 15를 출력이 출력되
//		어야 한다. (1)에 알맞은 코드를 넣으시오.
//		[Hint] String클래스의 charAt(int i)을 사용
//		문자		코드	
//========================		
//		0		48	
//		1		49	
//		2		50	
//		3		51	
//		4		52	
//		5		53	
//		6		54	
//		7		55	
//		8		56	
//		9		57	
		
		String str = "12345";
		int sum = 0;
		
		char zeroCh= '0';
		
		
		
		for(int i=0;i<str.length();i++) {
			char ch = str.charAt(i);
//			sum+=Integer.parseInt(ch+"");
			
			System.out.print("ch:"+ch);
			sum += ch - zeroCh;//49-48
			System.out.println("\t sum:"+sum);
			
		}

		System.out.println("sum="+sum);
		
	}

}








