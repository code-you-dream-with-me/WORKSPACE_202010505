/**
* <pre>
* com.sist.eclass.exam
* Class Name : Exam4_02.java
* Description:
* Author: james
* Since: 2020/12/02
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/02 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.exam;


public class Exam4_12 {


	public static void main(String[] args) {
	    //2,3,4
	    //2,3,4
	    //2,3,4
	    
	    //5,6,7
	    //5,6,7
	    //5,6,7
	    
	    //8,9
	    //8,9  
		
		//---------------------------
	    //1,1,1
	    //2,2,2
	    //3,3,3
	    
	    //1,1,1
	    //2,2,2
	    //3,3,3
	    
	    //1,1,1
	    //2,2,2
	    //3,3,3		
		
		for(int i=1;i<=9;i++) {
			
			for(int j=1;j<=3;j++) {
				
				int x = (j+1)+(i-1)/3*3;
				System.out.print(x);
				
				int y = (i%3==0)?3:i%3;
				//System.out.print(y);
				//System.out.print(x+"*"+y+"="+(x*y)+"\t");
				if(x==10) {//10단이면 출력 하지 않기.
					break;
				}
				
				System.out.printf("%d * %d = %d\t",x,y,(x*y));
			}
			
			System.out.println();
			if(i%3==0) {
				System.out.println();
			}
		}
		
		
	}//--main
}//--class








