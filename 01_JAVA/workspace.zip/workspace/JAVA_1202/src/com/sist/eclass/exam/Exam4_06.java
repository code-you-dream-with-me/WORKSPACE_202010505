/**
* <pre>
* com.sist.eclass.exam
* Class Name : Exam4_02.java
* Description:
* Author: james
* Since: 2020/12/02
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/02 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.exam;


public class Exam4_06 {


	public static void main(String[] args) {
		//1~6에 임이에 난수를 출력 하세요.
		//0.0<=x<1.0
		
		int value = (int)(Math.random()*6)+1;;
		
		System.out.println("value="+value);
				
		
	}

}








