/**
* <pre>
* com.sist.eclass
* Class Name : Flow04For.java
* Description:
* Author: james
* Since: 2020/12/02
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/02 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass;

public class Flow04For {


	public static void main(String[] args) {

		for(int i=1;i<=3;i++) {//3
			
			for(int j=1;j<=3;j++) {//3
				
				for(int k=1;k<=3;k++) {//3
					System.out.println(""+i+j+k);
				}
				
			}
		}

	}

}
//111
//112
//113
//121
//122
//123
//131
//132
//133

//211
//212
//213
//221
//222
//223
//231
//232
//233
//311
//312
//313
//321
//322
//323
//331
//332
//333