/**
* <pre>
* com.sist.eclass.exam
* Class Name : Exam4_Error.java
* Description:
* Author: james
* Since: 2020/12/02
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/02 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.exam;

/**
 * @author james
 *
 */
public class Exam4_Error {
	public static void main(String[] args) {
		// 숫자로 이루어진 문자열 str이 있을때,
		// 각 자리의 합을 더한 결과를 출력하는 코드를 완성하라
		// 만일 문자열이 "12345"라면,
		// '1+2+3+4+5'의 결과인 15를 출력이 출력되어야한다
		String str = "12345";
		int sum = 0;
		char zeroCh = '0';
		for (int i = 0; i < str.length(); i++)
		{
			char ch = str.charAt(i);
			sum += Integer.parseInt(ch + "");
//		    System.out.print("ch:"+ch);
//		    sum += ch - zeroCh;//49-48
//		    System.out.print("\t sum:"+sum);
		}
		System.out.println("sum:" + sum);
	}
}
