/**
* <pre>
* com.sist.eclass.exam
* Class Name : Exam4_02.java
* Description:
* Author: james
* Since: 2020/12/02
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/02 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.exam;


public class Exam4_08 {


	public static void main(String[] args) {
//		[4-8] 방정식 2x+4y=10의 모든 해를 구하시오. 단, x와 y는 정수이고 각각의 범위는
//		0<=x<=10, 0<=y<=10 이다.
//      2x+4y=10 -> 2*x+4*y ==10
		
		for(int x=0;x<=10;x++) {
			
			for(int y=0;y<=10;y++) {
				if(2*x+4*y ==10) {
					System.out.printf("x=%d,y=%d\n",x,y);
				}
			}
		}
		

		
		
	}

}








