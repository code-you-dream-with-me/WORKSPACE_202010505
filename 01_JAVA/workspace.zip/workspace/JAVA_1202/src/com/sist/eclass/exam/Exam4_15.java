/**
* <pre>
* com.sist.eclass.exam
* Class Name : Exam4_02.java
* Description:
* Author: james
* Since: 2020/12/02
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/02 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.exam;

import java.util.Scanner;

public class Exam4_15 {

	public static void main(String[] args) {
	   int number = 12327;
	   int tmp    = number;
	   
	   int result = 0; //변수 number를 거꾸로 변환해서 담을 변수
	   System.out.println(tmp);
	   while(tmp !=0) {
		   result =result*10 + tmp%10;// 0*10 + 1
		                              // 1*10 + 2
		   //System.out.println(result);
		   tmp=tmp/10;//자리수 이동
		   System.out.println(tmp);
	   }
	   
	   if(number == result) {
		   System.out.println(number+"는 회문수 입니다.");
	   }else {
		   System.out.println(number+"는 회문수가 아닙니다.");
	   }
	   
	   
	}//--main
}//--class








