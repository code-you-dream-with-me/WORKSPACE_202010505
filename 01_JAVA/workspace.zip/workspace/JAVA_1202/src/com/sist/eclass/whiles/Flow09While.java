/**
num* <pre>
* com.sist.eclass.whiles
* Class Name : Flow08While.java
* Description: while
* Author: james
* Since: 2020/12/02
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/02 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.whiles;

public class Flow09While {

	public static void main(String[] args) {
//		while(조건){			
//			문장01;		
//			문장02;		
//			….		
//		}			
//사용자로 부터 숫자를 입력 받고, 이 숫자의 각 자리의 합을 구하시오.
//12345 ->1+2+3+4+5=15

//마지막 자리 한자리 획득		
//12345%10	=	5
		
//마지막 한자리 제거(자리 이동)	
//12345/10	=	1234
		
		int num = 12345;
		int sum = 0;//누적 변수
		//System.out.println("12345%10="+(12345%10));
		//System.out.println("12345/10="+(12345/10));
		while(num !=0) {
			sum+=num%10;//num%10 나눈 나머지를 sum누적
			System.out.printf("sum=%3d, num=%5d\n",sum,num);
			num=num/10;//
			//num/=10;
		}
		
		System.out.println("sum="+sum);
		
		
		
	}

}














