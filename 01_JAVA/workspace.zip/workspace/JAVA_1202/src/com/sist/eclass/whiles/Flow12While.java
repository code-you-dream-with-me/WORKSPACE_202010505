/**
* <pre>
* com.sist.eclass.whiles
* Class Name : Flow12While.java
* Description:
* Author: james
* Since: 2020/12/02
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/02 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.whiles;

import java.util.Scanner;

/**
 * @author james
 *
 */
public class Flow12While {

	public static void main(String[] args) {
//		사용자로 부터 반복해서 숫자를 입력 받다가.										
//		0을 입력 받으면 프로그램을 종료 하고 										
//		그 때 까지 총합을 출력.										

		boolean flag = true;//while조건식
		int     sum  = 0;//누적 변수
		while(flag == true) {
			System.out.print(">>");
			Scanner scanner=new Scanner(System.in);
			
			int num = scanner.nextInt();
			
			if(0==num) {
				flag = false;
			}else {
				sum+=num;//sum=sum+num;
			}
			
		}
		System.out.println("sum="+sum);
		System.out.println("프로그램 종료.");
		
		
		

	}

}
