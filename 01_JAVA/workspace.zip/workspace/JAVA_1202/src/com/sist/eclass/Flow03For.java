/**
* <pre>
* com.sist.eclass
* Class Name : Flow03For.java
* Description: 구구단
* Author: james
* Since: 2020/12/02
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/02 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass;


public class Flow03For {


	public static void main(String[] args) {
		
//		i	j
//		2	1
//		3	2
//		4	3
//		..	..
//			
//			
//		9	9

		for(int i=2;i<=9;i++) {
			
			for(int j=1;j<=9;j++) {
				System.out.printf("%d * %d = %2d\n",i,j,(i*j));
			}
			
		}
		
		
		
	}

}
