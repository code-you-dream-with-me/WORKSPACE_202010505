/**
* <pre>
* com.sist.eclass
* Class Name : Flow07For.java
* Description:
* Author: james
* Since: 2020/12/02
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/02 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass;

/**
 * @author james
 *
 */
public class Flow07For {

	public static void main(String[] args) {
//		for(타입변수 : 배열 또는 컬렉션){								
//			문장01;							
//			문장02							
//		}								
		int arr[] = {9,11,14,45,49};
		
		for(int i=0;i<arr.length;i++) {
			System.out.printf("%2d ",arr[i]);
		}
		System.out.println();
		
		//enhanced for statement
		int sum = 0;
		for(int tmp   :arr) {
			sum+=tmp;
			System.out.printf("%2d ",tmp);
		}
		System.out.println();
		System.out.printf("sum=%d\n",sum);

	}

}
