/**
* <pre>
* com.sist.eclass.exam
* Class Name : Exam4_02.java
* Description:
* Author: james
* Since: 2020/12/02
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/02 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.exam;


public class Exam4_10 {


	public static void main(String[] args) {
//		[4-10] int타입의 변수 num 이 있을 때, 각 자리의 합을 더한 결과를 출력하는 코드를
//		완성하라. 만일 변수 num의 값이 56789라면, ‘5+6+7+8+9’의 결과인 35를 출력하라. (1)
//		에 알맞은 코드를 넣으시오.
//		[주의] 문자열로 변환하지 말고 숫자로만 처리해야 한다.
		
		int num = 56789;
		int sum = 0;
		
		//조건식
		//System.out.println("56789%10="+(56789%10));
		//System.out.println("56789/10="+(56789/10));
		while(num !=0) {
			sum+=num%10;//num%10 나눈 나머지를 sum누적
			System.out.printf("sum=%3d, num=%5d\n",sum,num);
			num=num/10;//
			//num/=10;
		}
		
		System.out.println("sum="+sum);		
		
		System.out.println("");
		
		
		
	}

}








