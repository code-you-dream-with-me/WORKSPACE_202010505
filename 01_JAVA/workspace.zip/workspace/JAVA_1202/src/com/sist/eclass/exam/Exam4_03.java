/**
* <pre>
* com.sist.eclass.exam
* Class Name : Exam4_02.java
* Description:
* Author: james
* Since: 2020/12/02
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/02 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.exam;


public class Exam4_03 {


	public static void main(String[] args) {
		int totalSum = 0;
		for(int i=1;i<=10;i++) {
			int subTotal = 0;
			for(int j=1;j<=i;j++) {
				subTotal +=j;
				System.out.printf("%d",j);
				
			}
			System.out.printf("=%d",subTotal);
			System.out.println();
			totalSum+=subTotal;//totalSum=totalSum+subTotal;
		}
		System.out.println("totalSum="+totalSum);
	}

}
