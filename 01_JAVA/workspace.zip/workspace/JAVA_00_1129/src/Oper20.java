
public class Oper20 {
//	논리 부정 연산		
//	
//	x	    !x
//	true	false
//	false	true
	
	
	public static void main(String[] args) {
		boolean b = true;
		System.out.printf("b=%b\n",b);
		
		System.out.printf("!b=%b\n",!b);
		//사용금지.
		//System.out.printf("!!b=%b\n",!!b);
		char ch ='C';
		System.out.printf("ch=%c%n",ch);
		// ch<'a' || ch>'z'
		System.out.printf("ch<'a' || ch>'z'=%b\n",
				ch<'a' || ch>'z');
		
		System.out.printf("!(ch<'a' || ch>'z')=%b\n",
				!(ch<'a' || ch>'z'));		
	}

}





