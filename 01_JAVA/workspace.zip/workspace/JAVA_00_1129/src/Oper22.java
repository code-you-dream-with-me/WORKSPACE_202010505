
public class Oper22 {
//	10진수	2진수							
//	10	    00001010
//	-11	    11110101
//	1	    00000001
//	-10								
	
	//양의 정수에 대한 음의 정수
	//양의 정수 p -> ~p+1
	public static void main(String []args) {
		int p = 10;
		//p =10 	00000000000000000000000000001010
		System.out.printf(" p  =%3d %s\n"
				,p,toBinaryString(p));
		//~p
		System.out.printf("~p  =%3d %s\n"
				,~p,toBinaryString(~p));
		//~p+1
		System.out.printf("~p+1=%3d %s\n"
				,~p+1,toBinaryString(~p+1));		
	}
	
	
	/**
	 * 10진 정수를 2진수 32비트로 변환
	 * @param int x
	 * @return 32bit string
	 */
	static String toBinaryString(int x) {
		String zero = "00000000000000000000000000000000";//32개
		String tmp  = zero + Integer.toBinaryString(x);
		int startIndex = tmp.length()-32;
		return tmp.substring(startIndex);
	}	
	
}

