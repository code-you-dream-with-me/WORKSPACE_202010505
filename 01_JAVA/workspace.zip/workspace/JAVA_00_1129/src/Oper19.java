import java.util.Scanner;

public class Oper19 {

	public static void main(String[] args) {
		// 1. data를 1(char) 입력 받는다.
		Scanner   scanner = new Scanner(System.in);
		System.out.println("문자를 하나 입력하세요.>");
		String input = scanner.nextLine();
		System.out.println("input: "+input);
		char ch = input.charAt(0);
		System.out.println("ch: "+ch);
				
		
		// 2. 비교한다.(ex) if(비교 논리연산 비교){}		
		//  2.1. 숫자인지 비교 한다.
		if('0'<=ch && ch <='9') {
			System.out.printf("입력(%c)하신 문자는 숫자입니다.\n"
					,ch);
		}
		//  2.2. 영문자(대문자||소문자)
		if(('A'<=ch && ch <='Z') 
				|| ('a'<=ch && ch <='z')) {
			System.out.printf("입력(%c)하신 문자는 영문자 입니다.\n"
					,ch);
		}
		

	}

}

