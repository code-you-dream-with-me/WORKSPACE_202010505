/**
 * 
 */


/**
 * @author sist
 *
 */
public class Oper18 {

	/**
	 * @Method Name:main
	 * @작성일: 2019. 11. 5.
	 * @작성자: sist
	 * @설명:
	 * @param args
	 */
	public static void main(String[] args) {
		// if(x>10 && x<20){}
		// i는 2배수 또는(||) 3의 배수->i%2==0 || i%3==0
		// i는 2의 배수 또는 3의 배수 단 6의 배수는 아니다.
		// ->(i%2==0 || i%3==0) && i%6!=0
		// 문자 ch는 숫자 이다.
		// ->'0'<=ch && ch<='9'

		// 문자ch 영문자이다.
		// ('a' <= ch && ch<='z') || ('A'<=ch && ch<='Z')
		//ctrl+sheet+f: 자바 소스 정리.
		int x = 0;
		char ch = ' ';
		
		x = 15;
		//x>10 && x<20 =true
		System.out.printf("x>10 && x<20 =%b\n"
				,x>10 && x<20);
		x = 6;
		//%%:%출력
		//x%2==0 || x%3==0 && x%6!=0
		System.out.printf("x%%2==0 || x%%3==0 && x%%6!=0 =%b\n"
				         ,x%2==0 || x%3==0 && x%6 !=0);
		
		System.out.printf("(x%%2==0 || x%%3==0) && x%%6!=0 =%b\n"
		         ,(x%2==0 || x%3==0) && x%6 !=0);		
		
		//문자 ch는 숫자 이다.
		ch = '1';
		System.out.printf("'0' <= ch && ch <='9' =%b\n"
				,'0' <= ch && ch <='9');
		
		ch = '0';
		System.out.printf("'A'<=ch && ch <='Z' =%b\n"
				,'A'<=ch && ch <='Z');
	}

}
