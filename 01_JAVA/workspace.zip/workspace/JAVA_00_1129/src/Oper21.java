
public class Oper21 {
//	0xAB	1	0	1	0	1	0	1	1
//	0xF		0	0	0	0	1	1	1	1
//---------------------------------------
//	|		1	0	1	0	1	1	1	1
//	&		0	0	0	0	1	0	1	1
//	^		1	0	1	0	0	1	0	0
	/**
	 * 10진 정수를 2진수 32비트로 변환
	 * @param int x
	 * @return 32bit string
	 */
	static String toBinaryString(int x) {
		String zero = "00000000000000000000000000000000";//32개
		String tmp  = zero + Integer.toBinaryString(x);//32+8
		//tmp.length
		System.out.println("tmp.length():"+tmp.length());
		Integer.toBinaryString(x);
		System.out.println("Integer.toBinaryString(x)"+Integer.toBinaryString(x).length());
		int startIndex = tmp.length()-32;
		return tmp.substring(startIndex);
	}
	
	
	public static void main(String[] args) {
		//00000000000000000000000010101011
		int x = 0xAB;//10101011
		int y = 0xF; //00001111
		//String intBitString = toBinaryString(x);
		//System.out.println("intBitString:"+intBitString);
		//x=0XAB 		 00000000000000000000000010101011
		System.out.printf("x=%#X \t\t %s\n"
				          ,x,toBinaryString(x));
		//y=0XF 		 00000000000000000000000000001111
		System.out.printf("y=%#X \t\t %s\n"
  				          ,y,toBinaryString(y));
		
		//| ->10101111
		System.out.printf("%#X | %#X =%#X \t %S\n"
				,x,y,x|y,toBinaryString(x|y));
		//& ->00001011
		//0XAB & 0XF =0XB 	 00000000000000000000000000001011
		System.out.printf("%#X & %#X =%#X \t %S\n"
				,x,y,x&y,toBinaryString(x&y));
		//^ ->10100100
		//0XAB ^ 0XF =0XA4 	 00000000000000000000000010100100
		System.out.printf("%#X ^ %#X =%#X \t %S\n"
				,x,y,x^y,toBinaryString(x^y));
		//x^y^y
		//00000000000000000000000010101011
		//간단한 암복호화에 사용 될수 있다.
		System.out.printf("%#X ^ %#X ^ %#X =%#X \t %S\n"
				,x,y,y,x^y^y,toBinaryString(x^y^y));		
	}

	
	
	
}






