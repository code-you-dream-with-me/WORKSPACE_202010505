/**
* <pre>
* com.sist.eclass.method
* Class Name : MethodCallMain.java
* Description:
* Author: james
* Since: 2020/12/09
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/09 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.method;

import org.apache.log4j.Logger;

/**
 * @author james
 *
 */
public class MethodCallMain {
	final static Logger LOG = Logger.getLogger(MethodCallMain.class);
	public static void main(String[] args) {
		MyMath myMath=new MyMath();
		//System.out.println(9/0);
		long  result01 = myMath.add(9, 11);
		long  result02 = myMath.subtract(9, 11);
		long  result03 = myMath.multiply(9L, 11L);
		double result04 = myMath.divide(9, 0);
		
		LOG.debug("result01="+result01);
		LOG.debug("result02="+result02);
		LOG.debug("result03="+result03);
		LOG.debug("result04="+result04);

	}

}
