/**
* <pre>
* com.sist.eclass.method
* Class Name : CallStackTest.java
* Description:
* Author: james
* Since: 2020/12/09
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/09 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.method;

import org.apache.log4j.Logger;

/**
 * @author james
 *
 */
public class CallStackTest {
	final static Logger  LOG = Logger.getLogger(CallStackTest.class);

	public static void main(String[] args) {
		LOG.debug("main() start");
		firstMethod();
		LOG.debug("main() end");
	}
	
	static void firstMethod() {
		LOG.debug("firstMethod() start");
		secondMethod();
		LOG.debug("firstMethod() end");
	}
	
	
	static void secondMethod() {
		LOG.debug("secondMethod() start");
		
		
	}

}
