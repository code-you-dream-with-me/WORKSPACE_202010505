/**
* <pre>
* com.sist.eclass.method01
* Class Name : Data.java
* Description:
* Author: james
* Since: 2020/12/09
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/09 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.method01;

/**
 * @author james
 *
 */
public class Data {
	int x;
}
