/**
* <pre>
* com.sist.eclass.method02
* Class Name : MyMathMain.java
* Description:
* Author: james
* Since: 2020/12/09
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/09 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.method02;

import org.apache.log4j.Logger;

/**
 * @author james
 *
 */
public class MyMathMain {

	final static Logger LOG = Logger.getLogger(MyMathMain.class);
	public static void main(String[] args) {
		MyMath myMath = new MyMath();
		long result01 = myMath.add(9, 11);
		long result02 = myMath.subtract(9, 11);
		long result03 = myMath.multiply(9, 11);
		double result04 = myMath.divide(9, 0);
		// 더블 나누기 더블은 무한대
		LOG.debug("result01 =" + result01);
		LOG.debug("result02 =" + result02);
		LOG.debug("result03 =" + result03);
		LOG.debug("result04 =" + result04);
	}
}
