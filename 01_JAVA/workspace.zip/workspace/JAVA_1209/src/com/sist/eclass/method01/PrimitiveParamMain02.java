/**
* <pre>
* com.sist.eclass.method01
* Class Name : PrimitiveParamMain.java
* Description:
* Author: james
* Since: 2020/12/09
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/09 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.method01;

import org.apache.log4j.Logger;

/**
 * @author james
 *
 */
public class PrimitiveParamMain02 {

	final static Logger LOG = Logger.getLogger(PrimitiveParamMain02.class);

	public static void main(String[] args) {
		Data d=new Data();
		d.x = 10;
		LOG.debug("main(): x="+d.x);
		
		change(d.x);
		LOG.debug("After main(): x="+d.x);

	}
	
	static void change(int x) {
		x = 1000;
		LOG.debug("change() x="+x);
	}
	

}
