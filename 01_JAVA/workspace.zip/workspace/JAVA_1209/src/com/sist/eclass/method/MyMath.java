/**
* <pre>
* com.sist.eclass.method
* Class Name : MyMath.java
* Description:
* Author: james
* Since: 2020/12/09
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/09 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.method;

/**
 * @author james
 *
 */
public class MyMath {
    /**
     * 더하기 
     * @param a
     * @param b
     * @return a+b
     */
	long add(long a, long b) {
		//메서드 body
		long result =0;
		result = a + b;
	    return result;
	}
	
	/**
	 * 빼기:a-b
	 * @param a
	 * @param b
	 * @return a-b
	 */
	long subtract(long a, long b)
	{
		return a-b;
	}
	
	/**
	 * 곱하기
	 * @param a
	 * @param b
	 * @return a*b
	 */
	long multiply(long a, long b) {
		return a*b;
	}
	
	/**
	 * 나누기(b는 0이 아니다.)
	 * @param a
	 * @param b
	 * @return a/b
	 */
	double	divide(double a, double b) {
		if(b==0) {
			System.out.println("0으로 나눌수 없습니다.");
			return 0;
		}
		return a/b;
	}
}

















