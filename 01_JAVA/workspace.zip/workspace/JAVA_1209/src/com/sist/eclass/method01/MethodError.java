/**
* <pre>
* com.sist.eclass.method01
* Class Name : MethodError.java
* Description:
* Author: james
* Since: 2020/12/09
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/09 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.method01;

/**
 * @author james
 *
 */
public class MethodError {

	public static void main(String[] args) {
		// 배열의 요소 출력:void printArr(int[] arr)
		// 배열 sort : void sortArr(int[] arr)
		// 배열의 요소 출력
		// 배열의 요소 sum: int sumArr(int[] arr)
		int[] arr = new int[] { 11, 9, 14, 45, 2 };
		printArr(arr);// 출력
		sortArr(arr);// sort
		printArr(arr);// sorting된 데이터가 유지됨
		System.out.println("sum = " + sumArr(arr));
	}// main

	/**
	 * 합계구하기
	 * 
	 * @param arr
	 * @return int(배열 합)
	 */
	static int sumArr(int[] arr) {
		int sum = 0;
		for (int value : arr) {
			sum += value;
		}
		return sum;
	}

	/**
	 * sort
	 * 
	 * @param arr
	 */
	static void sortArr(int[] arr) {
		for (int i = 0; i < arr.length - 1; i++) {
			for (int j = 0; j < arr.length - 1 - i; j++) {
				if (arr[j] > arr[j + 1]) {
					int tmp = arr[j];
					arr[j] = arr[j + 1];
					arr[j + 1] = tmp;
				}
			}
		}
	}

	/**
	 * 배열의 모든 요소 출력
	 * 
	 * @param arr
	 */
	static void printArr(int[] arr) {
		System.out.print("[");
		int j = 1;
		for (int i : arr) {
			// 배열의 마지막이면 ","을 지워라
			//System.out.print(i + ",");
			if (j == arr.length) {
				System.out.print(i);
			} else {
				System.out.print(i + ",");
			}
			j++;
		}
		System.out.println("]");
	}
}// class
