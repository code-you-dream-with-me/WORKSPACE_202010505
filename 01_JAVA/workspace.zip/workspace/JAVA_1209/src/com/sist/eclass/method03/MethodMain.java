/**
* <pre>
* com.sist.eclass.method03
* Class Name : MethodMain.java
* Description:
* Author: james
* Since: 2020/12/10
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/10 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.method03;

import org.apache.log4j.Logger;

/**
 * @author james
 *
 */
public class MethodMain {

    final static Logger  LOG = Logger.getLogger(MethodMain.class);
    
	public static void main(String[] args) {
		
		MethodMain methodMain=new MethodMain();
		//static method call
		//class 객체를 생성 하고 그 이름을 통해 호출
		int result = methodMain.add(9,11);
		LOG.debug("result:"+result);
		
		LOG.debug("=================================");
		//함수의 return 없이 값을 돌려 받기
		//레퍼런스를 이용
		int[]  result02= {0};
		methodMain.add(9, 11, result02);
		LOG.debug("result02[0]:"+result02[0]);
	}

	int add(int a,int b) {
		return a+b;
	}
	
	void  add(int a,int b,int[] result) {
		result[0] = a +b;
	}
	
	
	
	
	
}
