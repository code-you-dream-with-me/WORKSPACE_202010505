package com.sist.eclass.muti.exam;

public class Exam5_11 {

	public static void main(String[] args) {
		int[][] score = { { 100, 100, 100 }, { 20, 20, 20 }, { 30, 30, 30 }, { 40, 40, 40 }, { 50, 50, 50 } };

		int[][] result = new int[score.length+1][score[0].length+1];
//		System.out.println("result.length:"+result.length);
//		System.out.println("score[0].length+1:"+(score[0].length+1));
		
//		score[0][0]	score[0][1]	score[0][2]	()
//		score[1][0]	score[1][1]	score[1][2]	()
//		score[2][0]	score[2][1]	score[2][2]	()
//		score[3][0]	score[3][1]	score[3][2]	()
//		score[4][0]	score[4][1]	score[4][2]	()
//      (         ) (         ) (         ) ()		
		
		for(int i=0;i<score.length;i++) {
			int sum = 0;
			for(int j=0;j<score[i].length;j++) {
				result[i][j] = score[i][j];
				System.out.printf("score[%d][%d]\t",i,j);
				sum+=score[i][j];
			}
			System.out.println();
			//개인 sum
			result[i][score[i].length]=sum;
			result[result.length-1][0] += score[i][0];//국어
			result[result.length-1][1] += score[i][1];//영어
			result[result.length-1][2] += score[i][2];//수학
//			
//			//총합
			result[result.length-1][result[0].length-1]+=sum;
		}
		
		
		for(int i=0;i<result.length;i++) {
			for(int j=0;j<result[i].length;j++) {
				System.out.printf("%4d",result[i][j]);
			}
			System.out.println();
		}		
		
		
		
	}// --main

}// --class
