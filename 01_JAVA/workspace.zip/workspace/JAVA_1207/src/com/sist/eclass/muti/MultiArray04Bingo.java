package com.sist.eclass.muti;

import java.util.Scanner;

public class MultiArray04Bingo {

	public static void main(String[] args) {
//		5X5 빙고 만들기					
//		1	2	3	4	5
//	1	1	2	3	4	5
//	2	6	7	8	9	10
//	3	11	12	13	14	15
//	4	16	17	18	19	20
//	5	21	22	23	24	25
		final int SIZE = 5;//배열길이
		int x = 0;//좌표 x
		int y = 0;//좌표 y
		int num = 0;
		
		
		int[][] bingo=new int[SIZE][SIZE];
		
		//0으로 초기화 확인 
//		for(int i=0;i<bingo.length;i++) {
//			for(int j=0;j<bingo[i].length;j++) {
//				System.out.printf("%3d",bingo[i][j]);
//			}
//			System.out.println();
//		}
		
		System.out.println();
		//1~ 25초기화
		for(int i=0;i<bingo.length;i++) {
			for(int j=0;j<bingo[i].length;j++) {
				bingo[i][j]=i*SIZE+j+1;
				//System.out.printf("%3d",bingo[i][j]);
			}
			//System.out.println();
		}		
		
//		shuffle								
//		x	난수		(int)(Math.random()*5)				
//		y	난수		(int)(Math.random()*5)				

		for(int i=0;i<bingo.length;i++) {
			for(int j=0;j<bingo[i].length;j++) {
				x = (int)(Math.random()*5);//0<=x<5
				y = (int)(Math.random()*5);//0<=x<5
				
				//tmp 빈잔
				//x,y 난수
				//i,j 
				
				int tmp = bingo[i][j];
				bingo[i][j] = bingo[x][y];
				bingo[x][y] = tmp;
				
			}
		}	
		
//		System.out.println();
//		//1~ 25초기화
//		for(int i=0;i<bingo.length;i++) {
//			for(int j=0;j<bingo[i].length;j++) {
//				//bingo[i][j]=i*SIZE+j+1;
//				System.out.printf("%3d",bingo[i][j]);
//			}
//			System.out.println();
//		}		
		
		Scanner scanner=new Scanner(System.in);
		
		do {
			//빙고 출력
			for (int i = 0; i < bingo.length; i++) {
				for (int j = 0; j < bingo[i].length; j++) {
					System.out.printf("%3d", bingo[i][j]);
				}
				System.out.println();
			}			
			
			System.out.println();
			
			System.out.printf("1~%d의 숫자를 입력하세요.(종료:0)",SIZE*SIZE);
			num = scanner.nextInt();
			
			//입력 받은 숫자와 같은 숫자가 지정된 요소를 찾아 0으로 처리
			Outter:for (int i = 0; i < bingo.length; i++) {
				for (int j = 0; j < bingo[i].length; j++) {
					if(bingo[i][j] == num) {//num하가 같은 같이 있으면
						bingo[i][j]=0;
						break Outter;
					}
				}
			}	
			
			
		}while(num !=0);
		System.out.println("==============================");
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
