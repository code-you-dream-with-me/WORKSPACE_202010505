package com.sist.eclass.muti;

import java.util.Scanner;

public class MultiArray04Bingo02 {

	public static void main(String[] args) {
//		5X5 빙고 만들기			
		final int SIZE = 5;//배열길이
		int x = 0,y = 0,num = 0;
		int[][] bingo=new int[SIZE][SIZE];
		
		//1~ 25초기화
		for(int i=0;i<bingo.length;i++) {
			for(int j=0;j<bingo[i].length;j++) {
				bingo[i][j]=i*SIZE+j+1;
			}//초기화 j
		}//초기화 j
		
		for(int i=0;i<bingo.length;i++) {
			for(int j=0;j<bingo[i].length;j++) {
				x = (int)(Math.random()*5);//0<=x<5
				y = (int)(Math.random()*5);//0<=x<5		
				int tmp = bingo[i][j];
				bingo[i][j] = bingo[x][y];
				bingo[x][y] = tmp;
			}//shuffle j
		}//shuffle i	
		
		Scanner scanner=new Scanner(System.in);
		do {
			//빙고 출력
			for (int i = 0; i < bingo.length; i++) {
				for (int j = 0; j < bingo[i].length; j++) {
					System.out.printf("%3d", bingo[i][j]);
				}
				System.out.println();
			}			
			System.out.println();
			
			System.out.printf("1~%d의 숫자를 입력하세요.(종료:0)",SIZE*SIZE);
			num = scanner.nextInt();
			
			//입력 받은 숫자와 같은 숫자가 지정된 요소를 찾아 0으로 처리
			Outter:for (int i = 0; i < bingo.length; i++) {
				for (int j = 0; j < bingo[i].length; j++) {
					if(bingo[i][j] == num) {//num하가 같은 같이 있으면
						bingo[i][j]=0;
						break Outter;
					}
				}
			}	
			
		}while(num !=0);
		System.out.println("==============================");
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
