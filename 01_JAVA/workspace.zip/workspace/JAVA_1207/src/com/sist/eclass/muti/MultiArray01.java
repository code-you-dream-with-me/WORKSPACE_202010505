package com.sist.eclass.muti;

import org.apache.log4j.*;

public class MultiArray01 {

	final static Logger  LOG = Logger.getLogger(MultiArray01.class); 
	
	public static void main(String[] args) {
		LOG.debug("======================");
		int [][] score = {							
							{100,100,100},			
							{20,20,20},			
							{30,30,30},			
							{40,40,40},			
							{50,50,50}			
						 };				
		int sum = 0;
		
		LOG.debug("score.length:"+score.length);
		LOG.debug("score[0].length:"+score[0].length);
		
		for(int i=0;i<score.length;i++) {//행
			
			for(int j=0;j<score[i].length;j++) {//영
				System.out.printf("score[%d][%d]=%3d\t",i,j,score[i][j]);
				sum+=score[i][j];
			}
			System.out.println();
			
		}
		
		LOG.debug("sum="+sum);
		
		sum = 0;//총합 초기화
		for(int []tmp  :score) {//2차원 배열을 1차원 배열로
			for(int i  :tmp) {//1차원 배열을 값으로 
				sum+=i;
			}
		}
		LOG.debug("sum="+sum);
		
		
		
		
		
		
		LOG.debug("======================");
	}

}
