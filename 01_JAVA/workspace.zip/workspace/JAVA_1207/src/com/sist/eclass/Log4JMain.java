package com.sist.eclass;

import org.apache.log4j.Logger;

public class Log4JMain {

	final static Logger LOG = Logger.getLogger(Log4JMain.class);
	
	public static void main(String[] args) {
		//System.out.println("Hello, world.");
		LOG.debug("Hello, world.");
	}

}
