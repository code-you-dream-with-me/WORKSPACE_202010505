package com.sist.eclass.muti;
import java.util.Scanner;
public class MultiArray05Word {

	public static void main(String[] args) {
		String[][] words= {
				{"chair","의자"},
				{"computer","컴퓨터"},
				{"integer","정수"}
		};

		Scanner scanner=new Scanner(System.in);
		
		for(int i=0;i<words.length;i++) {
			//1.의자에 뜻은?
			System.out.printf("%d. %s의 뜻은?",(i+1),words[i][0]);
			String answer = scanner.nextLine();
			if(answer.equals(words[i][1])) {
				System.out.printf("정답 입니다.\n");
			}else {
				System.out.printf("오답 입니다.\n");
			}
			
		}//--for
		
		
		
	}//--main

}//--class
