package com.sist.eclass.muti;

import java.util.Scanner;
public class MultiArray03Use {

	public static void main(String[] args) {
//		입력한 2차원 좌표의 위치에 X를 표시								
//		//1,2,3,4,5,6,7,8,9,
//		{1,0,0,0,0,1,0,1,0},//1
//		{0,1,0,0,0,1,0,1,0},//2
//		{0,0,1,0,0,1,0,1,0},//3
//		{0,0,0,1,0,1,0,1,0},//4
//		{0,0,0,0,1,1,0,1,0},//5
//		{0,0,0,0,0,1,0,1,0},//6
//		{0,0,0,0,0,1,1,1,0},//7
//		{0,0,0,0,0,1,0,1,0},//8
//		{0,0,0,0,0,1,0,1,1} //9

		final int SIZE = 10;//상수는 모두 대문자로 변수이름 
		int x = 0;
		int y = 0;
		char[][]  board =new char[SIZE][SIZE];
		byte[][]  shipBboard= {
								//1,2,3,4,5,6,7,8,9,
								{1,0,0,0,0,1,0,1,0},//1
								{0,1,0,0,0,1,0,1,0},//2
								{0,0,1,0,0,1,0,1,0},//3
								{0,0,0,1,0,1,0,1,0},//4
								{0,0,0,0,1,1,0,1,0},//5
								{0,0,0,0,0,1,0,1,0},//6
								{0,0,0,0,0,1,1,1,0},//7
								{0,0,0,0,0,1,0,1,0},//8
								{0,0,0,0,0,1,0,1,1} //9				
							  };
		//1행에 행번호,1열에 열번호
		for(int i=1;i<SIZE;i++) {
			board[0][i]=(char)(i+'0');//1+48(열)
			board[i][0]=(char)(i+'0');//1+48(행)
		}
		
		Scanner scanner=new Scanner(System.in);//키보드 통한 입력
		
		while(true) {
			System.out.print("좌표를 입력하세요.(종료는 00)>>");
			//문자로 입력,1개씩 추출
			String input = scanner.nextLine();
			if(input.length()==2) {
				x=input.charAt(0)-'0';//char -> char[][]위치를 추출 
				y=input.charAt(1)-'0';//char -> char[][]위치를 추출
				
				if(0==x && 0==y) {
					System.out.println("프로그램을 종료 합니다.");
					break;
				}
			}
			
			if(input.length()!=2 || (x<=0 || x>=SIZE  ) || (y<=0 || y>=SIZE  ) ) {
				System.out.println("잘못 입력 하셨습니다. 다시 입력 해주세요.");
				continue;
			}
			//System.out.println("*****************");
			
			board[x][y]= (shipBboard[x-1][y-1]==1)?'O':'X';
			
			for(int i=0;i<board.length;i++) {
				for(int j=0;j<board[i].length;j++) {
					System.out.printf("%c",board[i][j]);
				}
				System.out.println();
			}			
			//board[x][y] 출력
//			for(int i=0;i<SIZE;i++) {
//				System.out.print(board[i]);
//				System.out.println();
//			}
			
		}
		System.out.println("========================");
		
		

		
		
	}

}
