package com.sist.eclass.generics02;

public interface Eatable {

}
