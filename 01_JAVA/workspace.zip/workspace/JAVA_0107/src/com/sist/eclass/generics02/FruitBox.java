package com.sist.eclass.generics02;


//Fruit의 자손이고 Eatable을 구현한 클래스만 올수 있다.
public class FruitBox<T extends Fruit & Eatable> extends Box<T> {

}
