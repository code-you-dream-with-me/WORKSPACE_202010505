package com.sist.eclass.generics02;

public class Apple extends Fruit {

	@Override
	public String toString() {
		return "Apple";
	}

}
