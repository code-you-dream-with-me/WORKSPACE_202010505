package com.sist.eclass.generics03;

public class Apple extends Fruit {

	@Override
	public String toString() {
		return "Apple";
	}

}
