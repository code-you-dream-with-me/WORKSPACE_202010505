package com.sist.eclass.generics;

public class Fruit {

	@Override
	public String toString() {
		return "Fruit";
	}

}
