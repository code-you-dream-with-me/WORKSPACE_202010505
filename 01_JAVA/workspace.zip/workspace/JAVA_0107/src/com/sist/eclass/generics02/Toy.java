package com.sist.eclass.generics02;

public class Toy {

	@Override
	public String toString() {
		return "Toy";
	}

}
