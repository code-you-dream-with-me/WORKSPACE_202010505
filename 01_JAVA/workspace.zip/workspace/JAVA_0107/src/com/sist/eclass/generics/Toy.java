package com.sist.eclass.generics;

public class Toy {

	@Override
	public String toString() {
		return "Toy";
	}

}
