package com.sist.eclass.generics02;

public class Grape extends Fruit {

	@Override
	public String toString() {
		return "Grape";
	}

}
