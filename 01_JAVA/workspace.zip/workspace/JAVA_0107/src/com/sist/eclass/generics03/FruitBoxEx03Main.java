package com.sist.eclass.generics03;

public class FruitBoxEx03Main {

	public static void main(String[] args) {
		FruitBox<Fruit> fruitBox=new FruitBox<Fruit>();
		FruitBox<Apple> appleBox=new FruitBox<Apple>();
		
		
		fruitBox.add(new Apple());
		fruitBox.add(new Grape());
		
		appleBox.add(new Apple());
		appleBox.add(new Apple());
		//appleBox.add(new Grape());
		
		System.out.println("Juicer.makeJuice(fruitBox)"+Juicer.makeJuice(fruitBox));
		System.out.println("Juicer.makeJuice(appleBox)"+Juicer.makeJuice(appleBox));
	}

}
