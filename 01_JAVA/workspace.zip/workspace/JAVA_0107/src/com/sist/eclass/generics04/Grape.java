package com.sist.eclass.generics04;

public class Grape extends Fruit {

	
	public Grape(String name,int weight) {
		super(name,weight);
	}
}
