package com.sist.eclass.generics02;

public class Fruit implements  Eatable{

	@Override
	public String toString() {
		return "Fruit";
	}

}
