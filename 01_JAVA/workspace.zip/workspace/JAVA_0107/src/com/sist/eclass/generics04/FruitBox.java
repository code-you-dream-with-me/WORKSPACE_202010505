package com.sist.eclass.generics04;



public class FruitBox<T extends Fruit > extends Box<T> {

}
