package com.sist.eclass.generics02;

public class FruitBoxEx02Main {

	public static void main(String[] args) {
//		- 타입에 종류를 제한 할수 있다.																	
//		ex) 지네릭 타입에 'extends'를 사용하면, 특정 타입의 자손들만 대입 할수 있게 제한.																	
//		- 인터페이스의 경우도 implements가 아닌 extends사용											

		
		FruitBox<Fruit>  fruitBox=new FruitBox<Fruit>();
		FruitBox<Apple>  appleBox=new FruitBox<Apple>();
		//Type mismatch: cannot convert from FruitBox<Apple> to FruitBox<Grape>
		//FruitBox<Grape>  grapeBox=new FruitBox<Apple>();
		
		//Bound mismatch: The type Toy is not a valid substitute for the bounded parameter <T extends Fruit & Eatable> of the type FruitBox<T>
		//FruitBox<Toy>  toyBox=new FruitBox<Toy>();
		
		
		fruitBox.add(new Fruit());
		fruitBox.add(new Apple());
		fruitBox.add(new Grape());
		
		
		appleBox.add(new Apple());
		appleBox.add(new Apple());
		//The method add(Apple) in the type Box<Apple> is not applicable for the arguments (Grape)
		//appleBox.add(new Grape());
		
		
		System.out.println("fruitBox:"+fruitBox);
		System.out.println("appleBox:"+appleBox);
	}

}
