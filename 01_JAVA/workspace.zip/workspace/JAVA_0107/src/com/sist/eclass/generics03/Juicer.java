package com.sist.eclass.generics03;

public class Juicer {

	
	
	static Juice makeJuice(FruitBox<? extends Fruit> box) {
		String name = "";
		
		for(Fruit f  :box.getList()) {
			name+=f.toString()+" ";
		}
		
		System.out.println("name:"+name);
		return new Juice(name);

	}
}
