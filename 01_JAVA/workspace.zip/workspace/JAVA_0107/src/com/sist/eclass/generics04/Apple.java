package com.sist.eclass.generics04;

public class Apple extends Fruit {

	
	public Apple(String name,int weight) {
		super(name,weight);
	}
	
}
