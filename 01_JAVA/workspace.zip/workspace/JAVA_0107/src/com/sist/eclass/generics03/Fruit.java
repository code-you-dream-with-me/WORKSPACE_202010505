package com.sist.eclass.generics03;

public class Fruit {

	@Override
	public String toString() {
		return "Fruit";
	}

}
