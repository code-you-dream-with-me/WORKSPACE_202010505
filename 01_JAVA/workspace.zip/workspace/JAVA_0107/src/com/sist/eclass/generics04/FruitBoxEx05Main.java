package com.sist.eclass.generics04;
import java.util.*;

public class FruitBoxEx05Main {

	public static void main(String[] args) {
//		Collections.sort()가 사용되었는데 이 메서드의 선언부는 다음과 같다.													
//		
//		static <T> void sort(List<T> list, Comparator<? super T> c)													
//		<? super T>는 T와 T의 조상들이 매개변수로 올 수 있다는 뜻이다. 													

		FruitBox<Apple> appleBox=new FruitBox<Apple>();
		
		
		appleBox.add(new Apple("GreenApple", 300));
		appleBox.add(new Apple("GreenApple", 100));
		appleBox.add(new Apple("GreenApple", 200));
		
		//sort before:[Fruit [name=GreenApple, weight=300], Fruit [name=GreenApple, weight=100], Fruit [name=GreenApple, weight=200]]
		System.out.println("sort before:"+appleBox );
		Collections.sort(appleBox.getList(), new AppleComp());
		//sort after:[Fruit [name=GreenApple, weight=300], Fruit [name=GreenApple, weight=200], Fruit [name=GreenApple, weight=100]]
		System.out.println("sort after:"+appleBox );
		
		//--------------------------------------------------
		FruitBox<Grape> grapeBox=new FruitBox<Grape>();
		
		grapeBox.add(new Grape("Green Grape", 400));
		grapeBox.add(new Grape("Green Grape", 100));
		grapeBox.add(new Grape("Green Grape", 200));
		
		System.out.println("sort before:"+grapeBox );
		Collections.sort(grapeBox.getList(), new GrapeComp());
		//sort after:[Fruit [name=Green Grape, weight=400], Fruit [name=Green Grape, weight=200], Fruit [name=Green Grape, weight=100]]
		System.out.println("sort after:"+grapeBox );
		
		//--------------------------------------------------------------
		//<? super T>는 T와 T의 조상들이 매개변수로 올 수 있다는 뜻이다. 			
		//--------------------------------------------------------------
		Collections.sort(appleBox.getList(), new FruitComp());
		System.out.println("<? super T> sort after:"+appleBox );
		
		
		Collections.sort(grapeBox.getList(), new FruitComp());
		System.out.println("<? super T> sort after:"+grapeBox );
		

	}

}
