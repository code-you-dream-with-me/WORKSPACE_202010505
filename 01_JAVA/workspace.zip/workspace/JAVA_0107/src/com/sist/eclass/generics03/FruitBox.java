package com.sist.eclass.generics03;



public class FruitBox<T extends Fruit > extends Box<T> {

}
