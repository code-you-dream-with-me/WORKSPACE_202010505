package com.sist.eclass.generics;

public class Apple extends Fruit {

	@Override
	public String toString() {
		return "Apple";
	}

}
