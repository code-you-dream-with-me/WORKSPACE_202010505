package com.sist.eclass.generics03;

public class Juice {
	String name;

	public Juice(String name) {
		this.name = name;
	}


	@Override
	public String toString() {
		return "Juice [name=" + name + "]";
	}
	
	
	
}
