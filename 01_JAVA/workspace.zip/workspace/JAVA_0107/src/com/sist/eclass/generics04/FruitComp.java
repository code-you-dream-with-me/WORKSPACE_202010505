package com.sist.eclass.generics04;

import java.util.Comparator;

public class FruitComp implements Comparator<Fruit> {

	@Override
	public int compare(Fruit o1, Fruit o2) {
		int sortValue = 0;
		System.out.println(o2.weight+"-"+ o1.weight);
		sortValue = o2.weight - o1.weight;
		
		return sortValue;
	}

}
