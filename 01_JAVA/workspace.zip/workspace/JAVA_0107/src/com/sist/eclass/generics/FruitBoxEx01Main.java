package com.sist.eclass.generics;

public class FruitBoxEx01Main {

	public static void main(String[] args) {
		Box<Fruit>  fruitBox=new Box<Fruit>();//OK
		Box<Apple>  appleBox=new Box<Apple>();//OK
		Box<Toy>    toyBox=new Box<Toy>();//OK
		
		//Type mismatch: cannot convert from Box<Grape> to Box<Apple>
		//Box<Apple>  grapeBox=new Box<Grape>();

		//Fruit과 Apple은 상속관계로 추가 가능
		fruitBox.add(new Fruit());
		fruitBox.add(new Apple());//OK
		
		appleBox.add(new Apple());
		appleBox.add(new Apple());
		//The method add(Apple) in the type Box<Apple> is not applicable for the arguments (Toy)
		//appleBox.add(new Toy());
		
		
		
		toyBox.add(new Toy());
		//The method add(Toy) in the type Box<Toy> is not applicable for the arguments (Apple)
		//toyBox.add(new Apple());
		
		System.out.println("fruitBox:"+fruitBox);
		System.out.println("appleBox:"+appleBox);
		System.out.println("toyBox:"+toyBox);
	}

}
