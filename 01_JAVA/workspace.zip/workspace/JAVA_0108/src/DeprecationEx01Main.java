

public class DeprecationEx01Main {
    //컴파일러가 보여주는 경고 메시지를 나타나지 않게 해준다.
	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		NewClass newClass=new NewClass();

		newClass.oldFiled =10;
		
		System.out.println(newClass.getOldFiled());
	}
   
}
//D:\20201123_eClass\01_JAVA\workspace\JAVA_0108\src>javac -Xlint:deprecation DeprecationEx01Main.java
//D:\20201123_eClass\01_JAVA\workspace\JAVA_0108\src>javac -Xlint:deprecation DeprecationEx01Main.java
//DeprecationEx01Main.java:8: warning: [deprecation] oldFiled in NewClass has been deprecated
//                newClass.oldFiled =10;
//                        ^
//DeprecationEx01Main.java:10: warning: [deprecation] getOldFiled() in NewClass has been deprecated
//                System.out.println(newClass.getOldFiled());
//                                           ^
//2 warnings

