package com.sist.eclass04.anno;

public class Parent {

	void parentMethod() {
		
	}
	
}
