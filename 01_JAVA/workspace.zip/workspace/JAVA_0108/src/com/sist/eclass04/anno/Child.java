package com.sist.eclass04.anno;

public class Child extends Parent {
    //@Override									
	//컴파일러에게 오버라이딩하는 메서드라는 것을 알린다.
	
	@Override
    void parentMethod() {
		
	}
	
}
