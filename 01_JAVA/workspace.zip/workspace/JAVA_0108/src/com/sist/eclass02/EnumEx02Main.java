package com.sist.eclass02;

public class EnumEx02Main {

	public static void main(String[] args) {
		for(Direction d :Direction.values()) {
			System.out.printf("%s=%d,%s\n",d.name(),d.getValue(),d.getSymbol());
		}

		System.out.println("=========================");
		
		Direction  d01 = Direction.EAST;
		System.out.printf("d01=%s,%d,%s \n",d01.name(),d01.getValue(),d01.getSymbol());
		
		System.out.println("=========================");
		Direction  d02 = Direction.of(4);
		System.out.printf("d02=%s,%d,%s \n",d02.name(),d02.getValue(),d02.getSymbol());
		
	}

}
