package com.sist.eclass02;

public enum Direction {
	EAST(1,">"),SOUTH(2,"V"),WEST(3,"<"),NORTH(4,"^");
	
	
	private static final Direction[] DIR_ARR=Direction.values();
	
	private final int value;
	private final String symbol;
	
	
	private Direction(int value, String symbol) {
		this.value = value;
		this.symbol = symbol;
	}
	
	
	public static Direction of(int dir) {
		if(dir<1 || dir>4) {
			throw new IllegalArgumentException("Invalid value:"+dir);
		}
	    //DIR_ARR 배열 -1 해서 value와 일치
		return DIR_ARR[dir-1];
	}
	
	
	public int getValue() {
		return value;
	}
	
	public String getSymbol() {
		return symbol;
	}
	
	//이름과 Simple출력
	//EAST+>
	public String toString() {
		return name()+getSymbol();
	}
	
	
}
