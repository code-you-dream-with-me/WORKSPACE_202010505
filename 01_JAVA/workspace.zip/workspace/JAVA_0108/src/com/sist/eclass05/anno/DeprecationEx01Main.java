package com.sist.eclass05.anno;

public class DeprecationEx01Main {

	public static void main(String[] args) {
		NewClass newClass=new NewClass();

		newClass.oldFiled =10;
		
		System.out.println(newClass.getOldFiled());
	}
   
}
