package com.sist.eclass03;

public class EnumEx03Main {

	public static void main(String[] args) {
		
		System.out.println("Transportation.BUS.fare(100)"+Transportation.BUS.fare(100));
		System.out.println("Transportation.TRAIN.fare(100)"+Transportation.TRAIN.fare(100));
		System.out.println("Transportation.SHIP.fare(100)"+Transportation.SHIP.fare(100));
		System.out.println("Transportation.AIRPLANE.fare(100)"+Transportation.AIRPLANE.fare(100));
		
	}

}
