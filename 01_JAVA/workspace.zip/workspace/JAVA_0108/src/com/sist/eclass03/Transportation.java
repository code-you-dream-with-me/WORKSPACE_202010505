package com.sist.eclass03;

public enum Transportation {
//운송 수단별 요금 계산: BUS,TRAIN,SHIP,AIRPLANE
//요금계산:추상메서드 
	BUS(100) {
		@Override
		int fare(int distance) {
			return distance*BASIC_FARE;
		}
	},
	TRAIN(150) {
		@Override
		int fare(int distance) {
			return distance*BASIC_FARE;
		}
	},
	SHIP(50) {
		@Override
		int fare(int distance) {
			return distance*BASIC_FARE;
		}
	},
	AIRPLANE(200) {
		@Override
		int fare(int distance) {
			return distance*BASIC_FARE;
		}
	}
	
	
	;
	
	protected final int BASIC_FARE;//각 상수에서 접근 할수 있도록 접근 지정자 지정.
	
	Transportation(int basic_fare){
		BASIC_FARE = basic_fare;
	}

	public int getBASIC_FARE() {
		return BASIC_FARE;
	}
	
	/**
	 * 거리에 따른 요금 계산
	 * @param distance
	 * @return
	 */
	abstract int fare(int distance);
	
	
}
