package com.sist.eclass01;

public enum Direction {
//	관련된 상수들을 묶어 놓은것. Java는 타입의 안전한 열겨형을 재공(JDK1.5부터 추가)																
//	열거형이 갖는 값뿐만 아니라 타입까지 관리해 논리적 오류를 줄일 수 있다.		
	EAST,SOUTH,WEST,NORTH					
}
