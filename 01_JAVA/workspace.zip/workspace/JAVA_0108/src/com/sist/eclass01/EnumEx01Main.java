package com.sist.eclass01;

public class EnumEx01Main {

	public static void main(String[] args) {
		//Enum객체 생성
		Direction  d01 = Direction.EAST;
		Direction  d02 = Direction.valueOf("WEST");
		Direction  d03 = Enum.valueOf(Direction.class, "EAST");
		
				
		System.out.println("d01:"+d01);
		System.out.println("d02:"+d02);
		System.out.println("d03:"+d03);
		
		//값비교
		System.out.println("d01==d02?"+(d01==d02));//false
		System.out.println("d01==d03?"+(d01==d03));//true
		
		System.out.println("d01.equals(d03)?"+(d01.equals(d03)));//true
		//순서:0
		System.out.println("d01.compareTo(d03)?"+(d01.compareTo(d03)));//0		
		System.out.println("d01.compareTo(d02)?"+(d01.compareTo(d02)));//-2
		
		//Direction.EAST - > EAST
		switch(d01) {
			case EAST:
				System.out.println("The direction is EAST.");
				break;
			case SOUTH:
				System.out.println("The direction is SOUTH.");
				break;		
			case WEST:
				System.out.println("The direction is WEST.");
				break;
			case NORTH:
				System.out.println("The direction is NORTH.");
				break;
			default:
				System.out.println("Invalid direction.");
				break;
		}
		
		//상수값 전체 출력
		Direction []dArr = Direction.values();
		
		for(Direction d :dArr) {
			System.out.printf("%s=%d\n",d.name(),d.ordinal());
		}
//		EAST=0
//		SOUTH=1
//		WEST=2
//		NORTH=3		
		
		
		
		
		
		
		
		
		
	}

}
