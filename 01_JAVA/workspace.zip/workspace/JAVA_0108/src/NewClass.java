

public class NewClass {

	int newFiled;

	public int getNewFiled() {
		return newFiled;
	}
	
	@Deprecated
	int oldFiled;

	@Deprecated
	public int getOldFiled() {
		return oldFiled;
	}
}
