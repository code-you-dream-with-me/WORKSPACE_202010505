/**
* <pre>
* com.sist.eclass
* Class Name : Flow08Switch.java
* Description:
* Author: james
* Since: 2020/12/01
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/01 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass;

import java.util.Scanner;

public class Flow09Switch {

	public static void main(String[] args) {
		//switch case문 내에 중접 조건문 가능(if,switch)
		//if -> switch case로 전환
		
		//1. 점수를 입력 받는다.
		//2. 점수에 해당되는 학점을 구한다.
		//3. opt
		
		int score = 0;//점수
		char grade= ' ';//학점 
		char opt  = ' ';//'+'
		
		System.out.println("점수를 입력하세요.>>");
		Scanner scanner=new Scanner(System.in);
		
		score = scanner.nextInt();
		
		System.out.println("score:"+score);
		System.out.println("score/10:"+score/10);
		
		switch(score/10) {
		case 10: case 9:
			grade = 'A';
			if(score>=95) {
				opt ='+';
			}
			break;
			
		case 8:
			grade = 'B';	
			if(score>=85) {
				opt ='+';
			}			
			break;
			
		case 7:
			grade = 'C';	
			if(score>=75) {
				opt ='+';
			}			
			break;		
			
		case 6:
			grade = 'D';
			if(score>=65) {
				opt ='+';
			}			
			break;		
						
		default:
			grade ='F';
			break;
			
		}
		
		System.out.printf("당신의 학점은 %c%c(%d) 입니다.",grade,opt,score);
		

	}

}
