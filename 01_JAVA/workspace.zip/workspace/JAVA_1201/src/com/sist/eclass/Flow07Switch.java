/**
* <pre>
* com.sist.eclass
* Class Name : Flow07Switch.java
* Description:
* Author: james
* Since: 2020/12/01
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/01 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass;

import java.util.Scanner;

/**
 * @author james
 *
 */
public class Flow07Switch {

	public static void main(String[] args) {
		//주민번호를 입력받아 성별을 구하세요.
		//801224-3112222
		
		//1.주민번호를 입력 받는다.
		//2.주민번호에서 성별에 해당하는 문자를 잘라낸다.
		//3.switch case 남(1,3)여(2,4)를 표기한다.

		//1.
		String regNo = "";//주민번호
		System.out.print("주민번호를 입력 하세요.>>");
		Scanner scanner=new Scanner(System.in);
		regNo = scanner.nextLine();
		
		//2.
		char  gender = regNo.charAt(7);
		System.out.println("gender:"+gender);
		
		//3.
		switch(gender) {
		case '1': case '3':
			System.out.println("남자");
			break;
		case '2': case '4':
			System.out.println("여자");
			break;
		default:
			System.out.println("유효하지 않는 주민번호 입니다.");
			break;
		
		}
		
		
	}

}





