/**
* <pre>
* com.sist.eclass
* Class Name : Flow08Switch.java
* Description:
* Author: james
* Since: 2020/12/01
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/01 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass;

import java.util.Scanner;

public class Flow08Switch {

	public static void main(String[] args) {
		//if -> switch case로 전환
		
		//1. 점수를 입력 받는다.
		//2. 점수에 해당되는 학점을 구한다.
		
		int score = 0;//점수
		char grade= ' ';//학점 
		
		System.out.println("점수를 입력하세요.>>");
		Scanner scanner=new Scanner(System.in);
		
		score = scanner.nextInt();
		
		System.out.println("score:"+score);
		System.out.println("score/10:"+score/10);
		
		switch(score/10) {
		case 10: case 9:
			grade = 'A';
			break;
			
		case 8:
			grade = 'B';	
			break;
			
		case 7:
			grade = 'C';	
			break;		
			
		case 6:
			grade = 'D';	
			break;		
						
		default:
			grade ='F';
			break;
			
		}
		
		System.out.printf("당신의 학점은 %c(%d) 입니다.",grade,score);
		

	}

}
