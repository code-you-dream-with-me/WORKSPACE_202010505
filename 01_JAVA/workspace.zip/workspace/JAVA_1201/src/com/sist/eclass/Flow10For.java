/**
* <pre>
* com.sist.eclass
* Class Name : Flow10For.java
* Description: for반복문: 끝을 알수 있는 경우 사용.
* Author: james
* Since: 2020/12/01
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/01 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass;


public class Flow10For {

	public static void main(String[] args) {

		for(int i=1;i<=5;i++) {
			System.out.println(i);//i값 출력
		}
		
		for(int i=1;i<=5;i++) {
			System.out.print(i);//i값 출력
		}		
	}

}
