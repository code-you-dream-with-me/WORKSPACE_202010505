/**
* <pre>
* com.sist.eclass
* Class Name : Flow10For.java
* Description: for반복문: 끝을 알수 있는 경우 사용.
* Author: james
* Since: 2020/12/01
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/01 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass;


public class Flow12For {

	public static void main(String[] args) {
		//i : 1->10
		//j : 10->1
//		   형식화된 출력 : printf	
//		   ========================
//		    지시자	설명
//		    %b	불리언 형식으로 출력
//		    %d	10진(decimal) 정수 형식으로 출력
//		    %o	8진수(octal) 형식으로 출력
//		    %x, %X	16진(hexa) 정수 형식으로 출력
//		    %f	부동 소수점(floating point) 형식으로 출력
//		    %e, %E	지수(exponent) 형식으로 출력
//		    %c	문자(charater)로 출력
//		    %s	문자열(String)로 출력
//		   ------------------------
//		   System.out.printf("출력 서식",출력할 내용);	
//        n : 출력할 전체 자리수 지정(오른쪽 정렬).  예) %3d, 전체자리수가 3인 정수
		
		
		for(int i=1,j=10;i<=10;i++,j--) {
			System.out.printf("%2d \t %2d\n",i,j);
		}

	}

}
