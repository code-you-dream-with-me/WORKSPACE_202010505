/**
* <pre>
* com.sist.eclass
* Class Name : Flow03IfElseIfElse.java
* Description: if(조건){ }else if(조건){ } else{} 
* Author: james
* Since: 2020/12/01
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/01 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass;

import java.util.Scanner;

public class Flow03IfElseIfElse {

	public static void main(String[] args) {
		/*
		 * 성적을 입력 받아 grade를 출력
		 */

		int score  = 0;    //점수 저장용
		char grade = ' ';  //학점 저장용(공백으로 초기화)
		
		System.out.println("점수를 입력 하세요>>");

		Scanner scanner = new Scanner(System.in);
		score = scanner.nextInt();//숫자 값을 입력 받아 score에 할당.
		
		if(score>=90) {//score 90점 이상이면 :grade='A'
			grade = 'A';
		//else if(score>=80 && score<90)	
		}else if(score>=80) {//score 80점 이상이면 :grade='B'
			grade ='B';
		}else if(score>=70) {//score 70점 이상이면 :grade='C'
			grade ='C';
		}else if(score>=60) {//score 80점 이상이면 :grade='D'
			grade ='D';
		}else {//나머지 모든것은 D
			grade ='F';
		}
		System.out.println("당신의 점수는 "+score+" 입니다.");
		System.out.println("당신의 학점은 "+grade+" 입니다.");
		
		
		
		
	}

}























