/**
* <pre>
* com.sist.eclass
* Class Name : Flow06Switch.java
* Description: 가위, 바위, 보 게임
* Author: james
* Since: 2020/12/01
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/01 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass;

import java.util.Scanner;

public class Flow06Switch {

	public static void main(String[] args) {
		//0.0<= x <1.0  =>  1<=x<4
		//0.0*3   <=Math.random()*3< 1.0*3 => 0.0<=x<3.0
		//(int)0.0<=x<(int)3.0             => 0<=x<3
		//0+1<=x<3+1                       => 1<=x<4
		
//		System.out.println("Math.random():"+Math.random());
//		System.out.println("Math.random()*3:"+Math.random()*3);
//		System.out.println("(int)(Math.random()*3):"+(int)(Math.random()*3));
		System.out.println("(int)(Math.random()*3+1):"+(int)(Math.random()*3+1));
		
		//1. 사용자에게 가위(1),바위(2),보(3) 입력 받기
		//2. 컴퓨터에게 입력 : 난수발생(1 ~3)
		//3. switch(사용자-컴퓨터){   }
		
		int user = 0;//사용자
		int com  = 0;//컴퓨터
		
		System.out.print("가위(1),바위(2),보(3)를 입력 하세요.(사용자)>>");
		Scanner  scanner = new Scanner(System.in);
		
		user = scanner.nextInt();//사용자에게 숫자 하나 입력 
		
		com  = (int)(Math.random()*3)+1;//컴퓨터 1<=x<4
		System.out.println("컴퓨터:"+com);
		System.out.println("사용자:"+user);
		
		switch(user-com) {
		case 2:case -1:
			System.out.println("컴퓨터 승!");
			break;
		case -2: case 1:
			System.out.println("사용자 승!");
			break;			
		
		case 0:
			System.out.println("무승부 !");
			break;
			
		}
		
		
		
		
		

	}

}
