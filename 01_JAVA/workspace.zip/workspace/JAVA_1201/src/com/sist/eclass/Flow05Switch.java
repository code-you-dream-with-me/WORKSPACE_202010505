/**
* <pre>
* com.sist.eclass
* Class Name : Flow05Switch.java
* Description: switch ~ case문
* Author: james
* Since: 2020/12/01
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/01 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass;

import java.util.Scanner;

public class Flow05Switch {

	public static void main(String[] args) {
//		2.1.switch문 : 단 하나의 조건식으로 많은 경우의 수를 처리 할수 있고 표현식도 간결.													
//		
//		1. 조건식은 계산 한다.										
//		2. 조건식의 결과와 일치하는 case문으로 이동										
//		3.이후 문장들을 수행 한다.										
//		4. break문 switch문의 끝을 만나면 전체를 벗어난다.										
//
//		switch문의 제약조건										
//		1. switch문의 조건식 결과는 정수 또는 문자열이어야 한다.									
//		2. case문에 값은 정수상수 또는 문자열만 가능하며, 중복되지 않아야 한다.	

//      월을 입력 받아 봄(3,4,5),여름(6,7,8),가을(9,10,11), 겨울(12,1,2)을 출력
		int month = 0;// 월

		System.out.print("월을 입력 하세요.>>");
		Scanner scanner = new Scanner(System.in);
		month = scanner.nextInt();

		switch (month) {
		case 3:case 4:case 5: // 봄
			System.out.println("현재의 계절은 봄 입니다.");
			break;
			
		case 6:case 7:case 8: // 여름
			System.out.println("현재의 계절은 여름 입니다.");
			break;	

		case 9:case 10:case 11: // 가을
			System.out.println("현재의 계절은 가을 입니다.");
			break;				

		case 12:case 1:case 2: // 겨울
			System.out.println("현재의 계절은 겨울 입니다.");
			break;				

		default:
			System.out.println("1~12사이 월을 입력 하세요.");
			System.out.printf("당신이 입력한 월은 %d 입니다.\n",month);
			break;
		}// --switch end

	}

}
