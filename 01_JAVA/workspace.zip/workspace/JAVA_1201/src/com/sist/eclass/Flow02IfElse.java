/**
* <pre>
* com.sist.eclass
* Class Name : Flow02IfElse.java
* Description: if else
* Author: james
* Since: 2020/12/01
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/01 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass;

import java.util.Scanner;

public class Flow02IfElse {

	public static void main(String[] args) {
		int input = 0;
		
		System.out.print("숫자를 하나 입력 하세요.>>");
		
		Scanner  scanner=new Scanner(System.in);
		String tmp = scanner.nextLine();//화면을 통해 입력 받은 데이터를 tmp에 저장
		
		//System.out.println("tmp:"+tmp);
		input = Integer.parseInt(tmp);
		
		/*
		 * 숫자가 0인지 확인: 조건 둘중 하나는 무조건 수행.
		 */
		if(input==0) {
			System.out.println("=================");
			System.out.println("입력하신 숫자는 0입니다.");
			System.out.println("=================");
		}else {
			System.out.println("=================");
			System.out.println("입력하신 숫자는 0이 아닙니다.");
			System.out.println("input="+input);
			System.out.println("=================");			
		}
		
		
		
	}

}
