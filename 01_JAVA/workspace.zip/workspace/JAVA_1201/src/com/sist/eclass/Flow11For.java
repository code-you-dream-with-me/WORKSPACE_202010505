/**
* <pre>
* com.sist.eclass
* Class Name : Flow10For.java
* Description: for반복문: 끝을 알수 있는 경우 사용.
* Author: james
* Since: 2020/12/01
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/01 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass;


public class Flow11For {

	public static void main(String[] args) {
		//1 ~ 10 합계를 출력 하세요.
		int sum = 0;//초기화
		
		for(int i=1;i<=10;i++) {
			sum +=i;//sum=sum+i;
			System.out.printf("1부터 %2d 까지의 합:%2d\n",i,sum);
		}

	}

}
