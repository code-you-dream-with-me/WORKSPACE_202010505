/**
* <pre>
* com.sist.eclass
* Class Name : Flow13NestFor.java
* Description: 이중 for문
* Author: james
* Since: 2020/12/01
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/01 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass;


public class Flow13NestFor {

	public static void main(String[] args) {
//		for문 안에 또 다른 for 문이 오는것.							
//		
//		for(int i=1;i<=5;i++){						
//			문장01;					
//								
//			for(int j=1;j<=5;j++){					
//				문장01_01;				
//								
//			}					
//								
//		}						

		for(int i=1;i<=5;i++) {
			for(int j=1;j<=5;j++) {
				System.out.print("*");
			}
			System.out.println();
			
		}
		
		

	}

}








