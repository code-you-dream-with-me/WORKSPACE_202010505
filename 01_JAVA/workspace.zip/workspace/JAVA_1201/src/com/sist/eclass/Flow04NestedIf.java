/**
* <pre>
* com.sist.eclass
* Class Name : Flow04NestedIf.java
* Description: 중첩 IF 
* Author: james
* Since: 2020/12/01
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/01 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass;

import java.util.Scanner;

public class Flow04NestedIf {

	public static void main(String[] args) {
		int score = 0;// 점수
		char grade = ' ';// 학점
		char opt = ' ';// +

		System.out.println("성적을 입력 하세요.>>");
		Scanner scanner=new Scanner(System.in);
		
		score = scanner.nextInt();
		
		if(score>=90) {
			grade = 'A';
			if(score>=95) {
				opt ='+';
			}
		}else if(score>=80) {
			grade ='B';
			if(score>=85) {
				opt ='+';
			}
		}else if(score>=70) {
			grade ='C';
			if(score>=75) {
				opt='+';
			}
		}else if(score>=60) {
			grade ='D';
			if(score>=65) {
				opt='+';
			}
		}else {
			grade ='F';
		}
		
		System.out.printf("당신에 점수는 %d 입니다.\n",score);
		System.out.printf("당신에 학점은 %c%c 입니다.\n",grade,opt);
		
		
	}

}







