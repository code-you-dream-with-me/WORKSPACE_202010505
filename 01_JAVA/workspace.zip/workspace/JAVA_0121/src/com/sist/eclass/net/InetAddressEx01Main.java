package com.sist.eclass.net;
import java.net.*;

public class InetAddressEx01Main {

	public static void main(String[] args) {
		//InetAddress : IP를 다루는 클래스
		InetAddress  ip = null;
		
		try {
			ip = InetAddress.getByName("www.naver.com");
			System.out.println("getHostName: "+ip.getHostName());
			System.out.println("getHostAddress: "+ip.getHostAddress());
			
			System.out.println("hostname/ip: "+ip.toString());
		} catch (UnknownHostException e) {
			System.out.println("======================");
			System.out.println("=UnknownHostException="+e.getMessage());
			System.out.println("======================");
			e.printStackTrace();
		}
		
		
		try {
			ip=InetAddress.getLocalHost();
			System.out.println("getHostName: "+ip.getHostName());		
			System.out.println("getHostAddress: "+ip.getHostAddress());
		} catch (UnknownHostException e) {
			System.out.println("======================");
			System.out.println("=UnknownHostException="+e.getMessage());
			System.out.println("======================");
			e.printStackTrace();
		}
		
		InetAddress[] ipArr = null;
		
		try {
			ipArr = InetAddress.getAllByName("naver.com");
			
			for(InetAddress inetAddr :ipArr) {
				System.out.println(inetAddr);
			}
			
			
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}

}
//getHostName: www.naver.com
//getHostAddress: 125.209.222.141
//hostname/ip: www.naver.com/125.209.222.141
//getHostName: DESKTOP-Q1UE5SF
//getHostAddress: 211.238.142.124
//naver.com/125.209.222.142
//naver.com/223.130.195.95
//naver.com/223.130.195.200
//naver.com/125.209.222.141
