package com.sist.eclass.net.url;
import java.net.*;
public class URLEx01Main {

	public static void main(String[] args) {
// URL(Uniform Resource Location)
		
//https://www.naver.com:443															
//http://www.sist.co.kr:80/index.do															
//		
//프로토콜://호스트명:포트번호/경로명/파일명?쿼리스트리#참조															
//		
//프로토콜: 자원에 접근하기 위해 서버와 통신하는데 사용되는 통신규약 ex)http,https,ftp															
//호스트명: 자원을 제공하기 위한 서버이름(www.naver.com)															
//포트번호: 통신에 사용되는서버 포트(서비스 구분)															
//경로명: 접근하려는 자원에 저장된 서버상 위치															
//파일명: 접근하려는 자원의 이름															
//쿼리스트리:URL에서 ?이후의 부분(name=홍길동)															
//참조( anchor):URL에서 #이후의 부분	
		try {
			URL  url=new URL("http://www.cgv.co.kr:80/movies/");
			System.out.println("getAuthority:"+url.getAuthority());//www.cgv.co.kr
			System.out.println("getPort:"+url.getPort());//80
			System.out.println("getDefaultPort:"+url.getDefaultPort());//80
			System.out.println("getProtocol:"+url.getProtocol());//http
			System.out.println("getHost:"+url.getHost());//www.cgv.co.kr
			//http://www.cgv.co.kr:80/movies/
			System.out.println("toURI:"+url.toURI());
			
		} catch (MalformedURLException e) {
			System.out.println("============================");
			System.out.println("=MalformedURLException="+e.getMessage());
			System.out.println("============================");
			e.printStackTrace();
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}

}
