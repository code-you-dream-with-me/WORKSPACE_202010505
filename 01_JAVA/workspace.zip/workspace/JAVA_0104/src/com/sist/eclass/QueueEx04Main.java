package com.sist.eclass;
import java.io.*;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Queue;
import java.util.Scanner;
public class QueueEx04Main {
	
	static Queue q=new LinkedList();
	static final int MAX_SIZE =5;
    //------------------------------------
	// 명령어 5개 입력
	// 1. q종료
	// 2. 명령어 입력
	// 3. queue에 offer을 이용해 입력
	// 4. history를 입력 하면 명령어(queue) 목록을 보여줌
	// 5. help입력하면 도움말
//	help입력하면 도움말을 볼수 있습니다.
//	>>top
//	command:top
//	>>ls
//	command:ls
//	>>pwd
//	command:pwd
//	>>history
//	command:history
//	1.top
//	2.ls
//	3.pwd
//	4.history
//	>>mkdir java
//	command:mkdir java
//	>>dir
//	command:dir
//	>>history
//	command:history
//	1.pwd
//	2.history
//	3.mkdir java
//	4.dir
//	5.history
//	>>q
//	command:q
//	프로그램 종료	
	//------------------------------------
	
	
	public static void main(String[] args) {
		System.out.println("help입력하면 도움말을 볼수 있습니다.");
		while(true) {
			System.out.print(">>");
			Scanner  s =new Scanner(System.in);
			String command = s.nextLine().trim();
			System.out.println("command:"+command);
			
			if("q".equalsIgnoreCase(command)) {//종료
				System.out.println("프로그램 종료");
				System.exit(0);
			}else if("help".equalsIgnoreCase(command)) {//help
				System.out.println("명령어 5개 입력                                ");
				System.out.println("1. q종료                                    ");
				System.out.println("2. 명령어 입력                                 ");
				System.out.println("3. queue에 offer을 이용해 입력                  ");
				System.out.println("4. history를 입력 하면 명령어(queue) 목록을 보여줌   ");
				System.out.println("5. help입력하면 도움말                          ");
			}else if("history".equalsIgnoreCase(command)) {//history: queue내용 출력
				int i =0;//명령어 Num
				
				//history명령어 저장
				save(command);
				//queue내용 출력
				LinkedList   tmp = (LinkedList) q;
				ListIterator  iter = tmp.listIterator();
				
				while(iter.hasNext()) {
					System.out.println(++i+"."+iter.next());
				}
				
			}else {//명령어 저장
				save(command);
			}
			
			
		}//--while

	}//--main
	
	public static void save(String input) {
		//queue
		if(!"".equals(input)) {
			q.offer(input);
		}
		
		//queue 의 최대 크기를 넘으면 제일먼저 입력된 것을 삭제한다.
		if(q.size()>MAX_SIZE) {
			q.remove();
		}
		
		
		
		
	}
	
	
	
	
	
	
	

}//--class
