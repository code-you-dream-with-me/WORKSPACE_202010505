package com.sist.eclass;
import java.util.*;

public class StackQueueEx01Main {
//	스택은 마지막에 저장한 데이터를 가장 먼저 꺼내는 구조 LIFO(Last In First Out)													
//	큐는 처음에 저장한 데이터를 가장 먼저 꺼내는 구조 FIFO(First In First Out)													

	public static void main(String[] args) {
		Stack  st =new Stack();
		
		st.push(0);
		st.push(1);
		st.push(2);
		
		
		System.out.println("=======statck==============");
		while(!st.empty()) {
			System.out.println(st.pop());
		}
//		=======statck==============
//				2
//				1
//				0
		//Stack은 구현하여 제공.
		//Queue는 인터페이스로 정의만 제공 별도의 클래스를 제공하고 있지 않다.
		//
		System.out.println("=======queue==============");
		
		Queue queue = new LinkedList();
		queue.offer(0);
		queue.offer(1);
		queue.offer(2);
		
		while(!queue.isEmpty()) {
			System.out.println(queue.poll());
		}
//		=======queue==============
//				0
//				1
//				2		
		
	}

}
