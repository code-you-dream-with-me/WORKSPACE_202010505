package com.sist.eclass;

import java.util.Stack;

public class StackEx03Main {
	//stack LIFO구조 활용
	static Stack back =new Stack();
	static Stack forward =new Stack();
	
	public static void goURL(String url) {
		back.push(url);
		//forward clear
		if(!forward.empty()) {
			forward.clear();
		}
	}
	
	//back,forward 상태값
	public static void status() {
		System.out.println("back:"+back);
		System.out.println("forward:"+forward);
		System.out.println("back:"+back.peek());
		System.out.println();
	}
	
	//back
	public static void goBack() {
		if(!back.empty()) {
			forward.push(back.pop());
		}
	}
	
	//
	public static void goForward() {
		if(!forward.empty()) {
			back.push(forward.pop());
		}
	}
	
	public static void main(String[] args) {
		goURL("1.SIST");
		goURL("2.네이버");
		goURL("3.다음");
		goURL("4.구글");
		status();
		
		goBack();
		status();
		
		goBack();
		status();
		
		goForward();
		status();
		
		goURL("https://cafe.naver.com/kndjang");
		System.out.println("새로운 주소로 이동");
		status();
	}

}
