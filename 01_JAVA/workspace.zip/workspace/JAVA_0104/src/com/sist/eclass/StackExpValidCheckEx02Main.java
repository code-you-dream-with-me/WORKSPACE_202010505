package com.sist.eclass;
import java.util.*;
public class StackExpValidCheckEx02Main {

	public static void main(String[] args) {
		// Stack  -> push("("), pop(")"); -> isEmpty():괄호일치
		//((2+3)*1+3
		if(args.length !=1) {
			System.out.println("사용:((2+3)*1+3");
			System.exit(0);
		}
		
		Stack st=new Stack();
		String param = args[0];
		System.out.println("param:"+param);
		
		for(int i=0;i<param.length();i++) {
			char ch = param.charAt(i);
			System.out.println(ch);
			
			if(ch =='(') {
				st.push(ch);
			}else if(ch == ')') {
				st.pop();
			}
		}
		
		//가로 check
		if(st.isEmpty() ==true) {
			System.out.println("괄호 일치");
		}else {
			System.out.println("괄호 불일치");
		}
		
		
		
		
		
		
		

	}

}
