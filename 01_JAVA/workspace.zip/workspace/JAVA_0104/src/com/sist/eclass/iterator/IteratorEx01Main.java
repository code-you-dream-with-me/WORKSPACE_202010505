package com.sist.eclass.iterator;
import java.util.*;
public class IteratorEx01Main {

	public static void main(String[] args) {
		//모두 컬렉션에 저장된 요소를 접근하는데 사용되는 인터페이스.
		ArrayList list=new ArrayList();
		list.add(9);
		list.add(11);
		list.add(14);
		list.add(45);
		
		Iterator iter = list.iterator();
		while(iter.hasNext()) {
			Object obj = iter.next();
			System.out.println(obj);
		}

	}

}
