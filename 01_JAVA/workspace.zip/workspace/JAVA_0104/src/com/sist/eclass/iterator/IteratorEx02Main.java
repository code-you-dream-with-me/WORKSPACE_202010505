package com.sist.eclass.iterator;
import java.util.*;
public class IteratorEx02Main {

	public static void main(String[] args) {
//		 ListIterator												
//		 iterator에 양방향 조회기능 추가(List를 구현한 경우만 사용가능)												

		ArrayList list=new ArrayList();
		list.add(9);
		list.add(11);
		list.add(14);
		list.add(45);   

//		Iterator iter = list.iterator();
//		System.out.println("====Iterator=====");
//		while(iter.hasNext()) {
//			System.out.println(iter.next());
//		}

		
		ListIterator listIter = list.listIterator();
		
		//단방향으로 read
		while(listIter.hasNext()) {
			System.out.print(listIter.next()+",");
		}
		
		
		System.out.println("====ListIterator=====");
		System.out.println("====list.size====="+list.size());
		System.out.println("====listIter.hasPrevious()====="+listIter.hasPrevious());
		//역방향으로 read
		while(listIter.hasPrevious()) {
			System.out.print(listIter.previous()+",");
		}
//		9,11,14,45,====ListIterator=====
//		====list.size=====4
//		====listIter.hasPrevious()=====true
//		45,14,11,9,
		
	}

}
