package com.sist.eclass.iterator;
import java.util.*;
public class IteratorEx03Main {

	public static void main(String[] args) {
		// outlook 에서 mail copy, copy delete구현
		// iterator remove()

	}

}
