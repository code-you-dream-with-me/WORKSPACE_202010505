package com.sist.eclass.lambdaex02;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class LambdaEx06Main {

	public static void main(String[] args) {
		// Predicate<T> T타입의 인자를 받고 결과 boolean을 리턴 

		Predicate<Integer> isBiggerThan = num->num>5;
		
		System.out.println(isBiggerThan.test(2));
	}

}
