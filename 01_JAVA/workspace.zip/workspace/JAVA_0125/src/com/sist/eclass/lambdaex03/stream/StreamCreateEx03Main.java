package com.sist.eclass.lambdaex03.stream;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class StreamCreateEx03Main {

	public static void main(String[] args) {
		List<String> subArrayList = Arrays.asList("java","oracle","html","jsp","javascript","spring");

		//stream생성
		//map: 스트림요소 변환
		//Function<T, R>는 T타입의 인자를 받고, R타입의 객체를 리턴합니다.
		Stream<String> streams = subArrayList.stream().map(x->x.concat("'s"));
		
		//최종연산:stream내용 출력
		////Consumer<T>는 T 타입의 객체를 인자로 받고 리턴 값은 없습니다.		
		streams.forEach(x->System.out.println(x));
		
	}

}
