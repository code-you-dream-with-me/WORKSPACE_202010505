package com.sist.eclass.lambda;

//람다식을 사용하기 위해서는 구현 Interface
//1개의 추상 메서드 를 가지고 있다.


@FunctionalInterface  //람다식 인터페이스 
public interface ELambdaInterface {

	public int mathPlus(int x,int y);
	
}
