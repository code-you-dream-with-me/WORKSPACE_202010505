package com.sist.eclass.time.format;
import java.time.*;
import java.time.format.*;
public class DateFormatterEx02Main {

	public static void main(String[] args) {
		LocalDate   date=LocalDate.parse("2021-01-25");
		LocalTime   time=LocalTime.parse("11:25:51");
		System.out.println("date:"+date);
		System.out.println("time:"+time);
		//----------------------------------------------
		DateTimeFormatter  p=DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS") ;
		LocalDateTime  dataTime=LocalDateTime.parse("2021-01-25 11:25:51.250", p);
		System.out.println("dataTime:"+dataTime);
		
		
	}

}
//date:2021-01-25
//time:11:25:51
//dataTime:2021-01-25T11:25:51.250