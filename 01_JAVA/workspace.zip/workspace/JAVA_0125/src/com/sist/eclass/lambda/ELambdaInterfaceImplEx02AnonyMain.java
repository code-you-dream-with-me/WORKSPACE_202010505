package com.sist.eclass.lambda;

public class ELambdaInterfaceImplEx02AnonyMain {

	public static void main(String[] args) {
		//무명 inner class
		ELambdaInterface  elambdaInter=new ELambdaInterface() {
			@Override
			public int mathPlus(int x, int y) {
				return x+y;
			}
		};	
		System.out.println(elambdaInter.mathPlus(10, 12));
	}
}
