package com.sist.eclass.lambdaex02;

public class LambdaEx03Main {

	public static void main(String[] args) {
		// Runnable은 인자를 받지 않고, 반환값도 없는 인터 페이스
//		@FunctionalInterface
//		public interface Runnable {
//		    public abstract void run();
//		}		
		Runnable runnable = ()->System.out.println("run annything!");

		runnable.run();
	}

}
