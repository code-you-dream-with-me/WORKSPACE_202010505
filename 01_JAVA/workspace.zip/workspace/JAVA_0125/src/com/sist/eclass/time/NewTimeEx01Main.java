package com.sist.eclass.time;
import java.time.*;
import java.time.temporal.*;
public class NewTimeEx01Main {
//	JDK1.8에 추가 Data,Calendar의 단점 개선.																		
//	
//	날짜	+	시간	  	->		날짜 & 시간											
//	LocalDate +LocalTime						LocalDateTime									
//	time-zoner				->	  	LocalDateTime				+	시간대		-> ZonedDateTime				
//																		
//	날짜		~		날짜		-> Period											
//	시간		~		시간		-> Duration											
//																		
//	객체생성																	
//		1. now()현재기준으로 날짜,시간,시간대																
//		LocalDate  date = LocalDate.now();																
//		LocalTime  time = LocalTime.now();																
//		LocalDateTime  localDate=LocalDateTime.now();																
//		ZonedDateTime dateTImeZone=ZonedDateTime.now();																
//																		
//		2. of() : 특정 날짜 Set																
//		LocalDate  date = LocalDate.of(2021,1,25);																
//		LocalTime  time = LocalTime.of(10,45,10);																
//		LocalDateTime  localDate=LocalDateTime.of(date,time)																
//		ZonedDateTime dateTImeZone=ZonedDateTime.of(localDate,ZoneId.of("Asia/Seoul"));																

	public static void main(String[] args) {

		LocalDate  today=LocalDate.now();
		LocalTime  now=LocalTime.now();
		
		System.out.println("today:"+today.toString());
		System.out.println("now:"+now.toString());
		//---------------------------------------------
		LocalDate  birthDate= LocalDate.of(2000, 12, 31);
		LocalTime  birthTime= LocalTime.of(11, 27, 10);
		
		System.out.println("birthDate:"+birthDate.toString());
		System.out.println("birthTime:"+birthTime.toString());

		
	}

}
