package com.sist.eclass.lambdaex02;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;

public class LambdaEx05Main {

	public static void main(String[] args) {
		// Function<T,R> T타입의 인자를 받고, R타입의 객체를 리턴합니다. 

		Function<Integer, Integer> multiply = (value)->value*2;
		
		System.out.println(multiply.apply(10));
	}

}
