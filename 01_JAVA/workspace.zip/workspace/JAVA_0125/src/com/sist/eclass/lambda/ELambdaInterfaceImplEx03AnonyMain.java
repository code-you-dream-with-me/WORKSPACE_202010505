package com.sist.eclass.lambda;

public class ELambdaInterfaceImplEx03AnonyMain {

	public static void main(String[] args) {
		//람다식
		//ELambdaInterface elambdaInter=(int x, int y)->{return x+y;};
		//param type예상되면 생략 가능.
		ELambdaInterface elambdaInter=(x, y)->{return x+y;};
		
		System.out.println(elambdaInter.mathPlus(10, 12));
	}

}
