package com.sist.eclass.lambda;

public class ELambdaInterfaceImplEx01Main {

	public static void main(String[] args) {
		ELambdaInterface elambdaInter = new ELambdaInterfaceImpl();
		
		System.out.println(elambdaInter.mathPlus(10, 12));
	}

}
