package com.sist.eclass.time;
import java.time.*;

public class NewTImeEx02Main {
//	객체생성																	
//	1. now()현재기준으로 날짜,시간,시간대										
//	LocalDateTime  localDate=LocalDateTime.now();																
//	ZonedDateTime dateTImeZone=ZonedDateTime.now();																
//																	
//	2. of() : 특정 날짜 Set														
//	LocalDateTime  localDate=LocalDateTime.of(date,time)																
//	ZonedDateTime dateTImeZone=ZonedDateTime.of(localDate,ZoneId.of("Asia/Seoul"));	
	public static void main(String[] args) {

		LocalDate  date=LocalDate.now();
		LocalTime  time=LocalTime.now();
		
		System.out.println("date:"+date);
		System.out.println("time:"+time);
		//--------------------------------------------
		LocalDateTime dt=LocalDateTime.of(date, time);
		System.out.println("LocalDateTime:"+dt);

		//--------------------------------------------
		
		ZonedDateTime seoulTime=ZonedDateTime.now();
		System.out.println("seoulTime:"+seoulTime);
		
		ZoneId  nyId = ZoneId.of("America/New_York");
		
		
		ZonedDateTime nyTime=ZonedDateTime.now().withZoneSameInstant(nyId);
		System.out.println("nyTime:"+nyTime);
		
		
		
		
		
		
	}

}
