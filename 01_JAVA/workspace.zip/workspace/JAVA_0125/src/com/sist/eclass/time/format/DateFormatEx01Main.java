package com.sist.eclass.time.format;
import java.time.*;
import java.time.format.*;

public class DateFormatEx01Main {

	public static void main(String[] args) {
		ZonedDateTime  zdateTime=ZonedDateTime.now();
		
		String[] patternArr= { "yyyy/MM/dd HH:mm:ss"
				,"yy년 MM월 dd일 E요일"
				,"yyyy-MM-dd HH:mm:ss.SSS Z VV"
		};
		
		for(String p:patternArr) {
			DateTimeFormatter  formatter=DateTimeFormatter.ofPattern(p);
			System.out.println(zdateTime.format(formatter));
		}

	}

}
//2021/01/25 11:25:51
//21년 01월 25일 월요일
//2021-01-25 11:25:51.250 +0900 Asia/Seoul