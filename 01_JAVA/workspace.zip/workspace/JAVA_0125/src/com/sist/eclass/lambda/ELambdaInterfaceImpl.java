package com.sist.eclass.lambda;

public class ELambdaInterfaceImpl implements ELambdaInterface {

	@Override
	public int mathPlus(int x, int y) {
		
		return x+y;
	}

}
