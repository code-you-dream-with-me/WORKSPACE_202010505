package com.sist.eclass.lambdaex02;

import java.util.Objects;
import java.util.function.Consumer;

public class LambdaEx04Main {

	public static void main(String[] args) {
		// Consumer<T> T타입의 객체를 인자로 받고 리턴값은 없습니다.
//		@FunctionalInterface
//		public interface Consumer<T> {
//
//		    void accept(T t);
//
//		    default Consumer<T> andThen(Consumer<? super T> after) {
//		        Objects.requireNonNull(after);
//		        return (T t) -> { accept(t); after.accept(t); };
//		    }
//		}	
		Consumer<String> printString = text->System.out.println("Miss "+text+"?");
		

		printString.accept("me");
	}

}
