package com.sist.eclass.lambdaex03.stream;

import java.util.*;
import java.util.stream.Stream;

public class StreamCreateEx01Main {

	public static void main(String[] args) {
		//기존 방식: for 데이터 처리
		List<String> subArrayList = Arrays.asList("java","oracle","html","jsp","javascript","spring");
		
		long count = 0;
		for(String sub:subArrayList) {
			if(sub.contains("j")) {
				count++;
			}
		}

		System.out.println("count:"+count);
		
		//jdk1.8 stream
		//for,if을 걷어낸 직관적인 코딩이 가능.
		count = 0;
		count = subArrayList.stream().filter(i->i.contains("j")).count();
		System.out.println("count:"+count);
	}

}
