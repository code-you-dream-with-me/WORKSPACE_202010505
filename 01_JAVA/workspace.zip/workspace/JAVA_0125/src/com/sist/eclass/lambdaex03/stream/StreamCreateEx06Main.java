package com.sist.eclass.lambdaex03.stream;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class StreamCreateEx06Main {

	public static void main(String[] args) {
		List<Integer>  dataArrays=Arrays.asList(1,2,3,4,5,6,7,8,9,10,11,12,13);
		
		//skip : Stream 일정 개수의 데이터를 가져와 새로운 스트림을 리턴 
//		Stream<Integer>  calData = dataArrays.stream().limit(3);
//		
//		calData.forEach(x->System.out.println(x));
		
		
		Stream<Integer>  calData02 =dataArrays.stream();
		//calData02.forEach(x->System.out.println(x));
		
		Stream<Integer>  calData03 =calData02.skip(5).limit(3);
		calData03.forEach(x->System.out.println(x));
	}

}
