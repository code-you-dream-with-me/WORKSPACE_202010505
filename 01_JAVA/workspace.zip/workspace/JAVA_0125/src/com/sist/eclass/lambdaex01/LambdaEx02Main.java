package com.sist.eclass.lambdaex01;
import java.util.*;
public class LambdaEx02Main {

	public static void main(String[] args) {
		List<Integer>  list=new ArrayList<Integer>();
		
		for(int i=0;i<10;i++) {
			list.add(i);
		}
		
		//System.out.println(list);
		
		//list의 모든 요소를 람다식으로 표현
		list.forEach(i->System.out.print(i+","));
		System.out.println();
		//list에 2또는 3에 배수 제거 출력
//		list.removeIf(i->i%2==0 || i%3==0);
//		System.out.println(list);
		
		list.replaceAll(i->i*10);
		System.out.println(list);

	}

}
