package com.sist.eclass02;

public class InnerClassMain {

	class InstanceInner{
		int iv;
		//The field cv cannot be declared static in a non-static inner type, 
		//unless initialized with a constant expression
		//static int cv=100;
		final static int CONST = 100;//final 이 사용되면 상수화 되어 어떤 경우라도 static사용 가능
	}
	
	static class StaticInner{
		int iv = 200;
		static int cv = 200;
	}
	
	
	void method() {
		class LocalInner{
			int iv;
			//The field cv cannot be declared static in a non-static inner type, 
			//unless initialized with a constant expression
			//static int cv=100;
			final static int CONST = 100;//final 이 사용되면 상수화 되어 어떤 경우라도 static사용 가능
		}		
	}
	
	
	public static void main(String[] args) {
		System.out.println(InstanceInner.CONST);
		System.out.println(StaticInner.cv);
	}

}
