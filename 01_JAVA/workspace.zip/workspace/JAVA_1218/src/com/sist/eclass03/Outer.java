package com.sist.eclass03;

public class Outer {

	class InstanceInner{
		int iv = 10;
	}
	
	static class StaticInner{
		int iv = 200;
		static int cv = 20;
	}
	
	void method() {
		class LocalInner{
			int iv = 300;
		}
	}
	
	
}
