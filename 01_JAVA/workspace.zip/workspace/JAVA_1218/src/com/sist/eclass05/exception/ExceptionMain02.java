package com.sist.eclass05.exception;

public class ExceptionMain02 {

	public static void main(String[] args) {
		
		int number = 100;
		int result = 0;
		System.out.println("1-------------------");
		//number /0
		//System.out.println(number/0);
		for(int i=0;i<10;i++) {
			try {
				result = number / (int)(Math.random()*10);
				System.out.println("result:"+result);
			}catch(ArithmeticException a) {
				System.out.println("0 by zero");
			}
		}
		
		System.out.println("2-------------------");
	}

}
