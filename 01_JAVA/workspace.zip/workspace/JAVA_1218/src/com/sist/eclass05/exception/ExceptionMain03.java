package com.sist.eclass05.exception;

public class ExceptionMain03 {

	public static void main(String[] args) {
//		2. 예외 미발생										
//		1. catch블럭을 거치지 않고, 수행을 계속한다.									

		System.out.println("1");
		System.out.println(2);
		
		try {
			System.out.println(3);
			System.out.println(4);
		}catch(Exception e) {
			System.out.println(5);
		}
		
		System.out.println(6);

	}

}
//1
//2
//3
//4
//6