package com.sist.eclass05.exception;

public class ExceptionMain05 {

	public static void main(String[] args) {
//		1. 예외 발생																				
//		1.1. 발생한 예외와 일치하는 catch블럭이 있는지 확인한다.																			
//		1.2. 일치하는 catch블럭을 찾게 되면, 그 catch블럭내 문장을 수행하고 전체 try~catch문을 빠려나가서 																			
//			그 다음 문장을 수행 한다.																		
									

		System.out.println("1");
		System.out.println(2);
		
		try {
			System.out.println(3);
			System.out.println(7/0);
			System.out.println(4);
		}catch(ArithmeticException e) {
			if(e instanceof ArithmeticException) {
				System.out.println(5+": e instanceof ArithmeticException->"+(e instanceof ArithmeticException));
				//발생한 예외 클래스에서 인스턴스에 저장된 메시지를 얻을 수 있다.
				//e.getMessage():/ by zero
				System.out.println("e.getMessage():"+e.getMessage());
				
				//예외 발생당시의 call stack에 있던 메서드의 정보와 예외 메시지를 같이 출력
				//java.lang.ArithmeticException: / by zero
//				at com.sist.eclass05.exception.ExceptionMain05.main(ExceptionMain05.java:17)
				//e.printStackTrace();
				
			}
		}catch(Exception e) { //그 이외에 알지 못하는 모든 예외
			System.out.println(51);
		}
		
		System.out.println(6);

	}

}
//1
//2
//3
//5
//6
