package com.sist.eclass05.exception;

public class ExceptionMain04 {

	public static void main(String[] args) {
//		1. 예외 발생																				
//		1.1. 발생한 예외와 일치하는 catch블럭이 있는지 확인한다.																			
//		1.2. 일치하는 catch블럭을 찾게 되면, 그 catch블럭내 문장을 수행하고 전체 try~catch문을 빠려나가서 																			
//			그 다음 문장을 수행 한다.																		
									

		System.out.println("1");
		System.out.println(2);
		
		try {
			System.out.println(3);
			System.out.println(7/0);
			System.out.println(4);
		}catch(Exception e) {
			System.out.println(5);
		}
		
		System.out.println(6);

	}

}
//1
//2
//3
//5
//6
//1
//2
//3
//4
//6