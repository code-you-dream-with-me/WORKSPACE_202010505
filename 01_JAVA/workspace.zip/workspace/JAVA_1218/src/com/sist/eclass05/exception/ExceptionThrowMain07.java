package com.sist.eclass05.exception;

public class ExceptionThrowMain07 {
	/**
	 * 예외 발생 시키기 : 개발자가 의도적으로 발생 시킨다. 1. 예외 클래스를 선언 한다. ArithmeticException a=new
	 * ArithmeticException();
	 * 
	 * 2. throw 키워드를 통해 예외를 발생 시킨다. ArithmeticException a=new ArithmeticException();
	 * throw a;
	 * 
	 */
	public static void main(String[] args) {
		// Unhandled exception type Exception

		// (예외처리를 하지 않으면
		// 컴파일이 않된다.)
		// Checked Exception
		// throw new Exception("개발자가 예외 발생 함.");

		// RuntimeException
		// UnChecked Exception : 컴파일 된다.
		throw new RuntimeException("개발자가 예외 발생 함.");

	}

}
