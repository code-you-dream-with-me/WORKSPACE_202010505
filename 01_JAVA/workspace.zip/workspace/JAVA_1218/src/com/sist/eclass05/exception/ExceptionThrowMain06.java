package com.sist.eclass05.exception;

public class ExceptionThrowMain06 {
/**
 * 예외 발생 시키기 : 개발자가 의도적으로 발생 시킨다.
 * 1. 예외 클래스를 선언 한다.
   ArithmeticException a=new    ArithmeticException();

2. throw 키워드를 통해 예외를 발생 시킨다.
    ArithmeticException a=new    ArithmeticException();
    throw a;

 */
	public static void main(String[] args) {
		try {
//			Exception  ex01=new Exception("개발자가 예외 발생 함.");
//			throw ex01;
			throw new Exception("개발자가 예외 발생 함.");
		}catch(Exception e) {
			System.out.println("getMessage:"+e.getMessage());
			e.printStackTrace();
		}

	}

}
