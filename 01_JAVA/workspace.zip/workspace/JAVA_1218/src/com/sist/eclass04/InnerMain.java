package com.sist.eclass04;

import java.awt.Button;

public class InnerMain {

	public static void main(String[] args) {
		Button b=new Button("Start");
		
        b.addActionListener(new EventHandler());
	}

}
