package com.sist.eclass;

public interface MyInterface2 {
	
	default void method1() {
		System.out.println("method1() MyInterface2");
		
	}
	
	static void staticMethod() {
		System.out.println("staticMethod() MyInterface2");
	}
	
	
}
