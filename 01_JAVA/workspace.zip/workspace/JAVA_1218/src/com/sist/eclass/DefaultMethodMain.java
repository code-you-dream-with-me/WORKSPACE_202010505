package com.sist.eclass;

public class DefaultMethodMain {

	public static void main(String[] args) {
//		-디폴트 메서드가 기존의 메서드와 충돌하는 경우 												
//		   1. 여러 인터페이스의 디폴트 메서드간 충돌 												
//		       -인터페이스를 구현한 클래스에서 디폴트 메서드를 오버라이딩 해야 한다.												
//		   2. 디폴트 메서드와 조상 클래스의 메서드간 충돌 												
//		       -조상 클래스의 메서가 상속되고, 디폴트 메서드는 무시된다.												

		Child c=new Child();
		//1. 여러 인터페이스의 디폴트 메서드간 충돌
		//-인터페이스를 구현한 클래스에서 디폴트 메서드를 오버라이딩 해야 한다.
		c.method1();
//		   2. 디폴트 메서드와 조상 클래스의 메서드간 충돌 												
//	       -조상 클래스의 메서가 상속되고, 디폴트 메서드는 무시된다.		
		c.method2();
		
		MyInterface.staticMethod();
		MyInterface2.staticMethod();	
	}

}
