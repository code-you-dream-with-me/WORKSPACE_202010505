package com.sist.eclass;

public class Child extends Parent implements MyInterface,MyInterface2 {

	@Override 
	public void disp() {

	}

	@Override
	public void method1() {
		System.out.println("method1() Child");
	}

//	Duplicate default methods named method1 with the parameters () and () are inherited from the types MyInterface2 and MyInterface
    
}
