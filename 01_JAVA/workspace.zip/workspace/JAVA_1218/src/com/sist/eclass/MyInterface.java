package com.sist.eclass;

public interface MyInterface {
	/**
	 * 인터페이스에 추상 메서드
	 */
	void disp();
	
	default void method1() {
		System.out.println("method1() MyInterface");
		
	}
	
	default void method2() {
		System.out.println("method2() MyInterface");
		
	}	
	
	static void staticMethod() {
		System.out.println("staticMethod() MyInterface");
	}
	
	
}
