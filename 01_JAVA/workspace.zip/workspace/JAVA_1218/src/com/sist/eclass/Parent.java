package com.sist.eclass;

public class Parent {
	
	public void method2() {
		System.out.println("method2() is Parent");
	}
}
