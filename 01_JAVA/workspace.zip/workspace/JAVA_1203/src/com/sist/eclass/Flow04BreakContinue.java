/**
* <pre>
* com.sist.eclass
* Class Name : Flow04BreakContinue.java
* Description:
* Author: james
* Since: 2020/12/03
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/03 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass;

import java.util.Scanner;

public class Flow04BreakContinue {

	public static void main(String[] args) {
		// 0을 입력 하면 프로그램 종료(break)
		// 1~3 메뉴 생성, 4이상이면 메뉴다시 선택.(continue)

		int menu = 0;// menu
		int num = 0;

		while (true) {
			System.out.println("(1) square");
			System.out.println("(2) square root");
			System.out.println("(3) log");
			System.out.print("원하는 메뉴(1~3)를 선택 하세요(종료:0)");

			Scanner scanner = new Scanner(System.in);

			menu = scanner.nextInt();
			if (menu == 0) {
				System.out.println("프로그램을 종료 합니다.");
				break;
			} else if (!(menu >= 1 && menu <= 3)) {//
				System.out.println("메뉴를 다시 선택 하세요.");
				continue;
			}

			System.out.println("선택 하신 메뉴는 " + menu + "입니다.");
		}

	}

}
