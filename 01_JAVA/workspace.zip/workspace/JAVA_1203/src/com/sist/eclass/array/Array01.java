/**
* <pre>
* com.sist.eclass.array
* Class Name : Array01.java
* Description: 배열
* Author: james
* Since: 2020/12/03
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/03 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.array;

public class Array01 {

	public static void main(String[] args) {
//		5.배열(array)													
//		
//		같은 타입의 여러 변수를 하나의 묶음으로 다루는 것.											
//		많은 양의 값(데이터)를 다룰 때 유용하다.											
//		배열의 각 요소는 서로 독립적이다.											

		// int[] score;
		// score = new int[5];

		// 5.1. 배열의 선언과 사용
		int[] score = new int[5];

		// 배열에 값 할당.
		score[0] = 10;
		score[1] = 20;
		score[2] = 30;
		score[3] = 40;
		score[4] = 50;
		// System.out.println("score[1]:"+score[1]);

		System.out.println("score.length:" + score.length);
		// 배열에 출력
		for (int i = 0; i < score.length; i++) {
			System.out.printf("score[%d]=%d\n", i, score[i]);
		}

		System.out.println(score[7]);
		/*
		 * Exception in thread "main" java.lang.ArrayIndexOutOfBoundsException: 7 at
		 * com.sist.eclass.array.Array01.main(Array01.java:50)
		 */

	}

}
