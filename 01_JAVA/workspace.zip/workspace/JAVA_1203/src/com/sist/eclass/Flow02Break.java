/**
* <pre>
* com.sist.eclass
* Class Name : Flow02Break.java
* Description:
* Author: james
* Since: 2020/12/03
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/03 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass;

/**
 * @author james
 *
 */
public class Flow02Break {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
//		break문													
//		
//		자신이 포함된 하나의 반복문을 빠져 나온다.												
//		주로 if문과 같이 사용해서 특정 조건이 되면 반복문을 벗어나게 한다.												
//		숫자를 1부터 계속 더해 나가서 몇까지 더하면 100을 넘는지 알아내기.

		int i = 0;// 증감 변수
		int sum = 0;//

		while (true) {
			if (sum > 100) {
				break;
			}
			++i;
			sum += i;
			System.out.println(sum);
		} // --while

		System.out.println("i=" + i);
		System.out.println("sum=" + sum);

	}// --main

}// --class
