/**
* <pre>
* com.sist.eclass
* Class Name : Flow05NamedFor.java
* Description:
* Author: james
* Since: 2020/12/03
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/03 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass;

public class Flow05NamedFor {

	public static void main(String[] args) {
		// for Loop1이라는 이름 부여

		Loop1: for (int i = 2; i <= 9; i++) {

			for (int j = 1; j <= 9; j++) {
				// if(j==5) {break Loop1;}

				if (j == 5) {
					continue Loop1;
				}
				System.out.printf("%d * %d =%2d\n", i, j, (i * j));
			}

		}

	}

}
