/**
* <pre>
* com.sist.eclass
* Class Name : Flow03Continue.java
* Description:
* Author: james
* Since: 2020/12/03
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/03 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass;

public class Flow03Continue {

	public static void main(String[] args) {
//		continue문		
//		
//		자신이 포함된 반복문의 끝으로 이동.(다음 반복으로 이동)	
//		contine문 이하 문장들은 수행되지 않는다.	

		// 1~10 사이 3의 배수가 아닌 수를 출력 하세요.
		// i%3==0

		for (int i = 1; i <= 10; i++) {

			if (i % 3 == 0) {
				continue;
			}

			System.out.println(i);
		}

	}

}
