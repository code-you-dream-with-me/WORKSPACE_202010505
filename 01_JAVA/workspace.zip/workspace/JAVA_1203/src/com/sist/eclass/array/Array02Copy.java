/**
* <pre>
* com.sist.eclass.array
* Class Name : Array02Copy.java
* Description:
* Author: james
* Since: 2020/12/03
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2020/12/03 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.array;

/**
 * @author james
 *
 */
public class Array02Copy {

	public static void main(String[] args) {
//		배열은 한번 선언되고 나면 길이를 변경할 수 없다.											
//		
//		1. 더 큰 배열을 새로 생성 한다.											
//		2. 기존 배열의 내용을 새로운 배열로 복사한다.											
//		3. 주소번지 더큰 배열 주소로 변경한다.											

		int arr[] = new int[5];

		// 배열에 값 할당.
		for (int i = 0; i < arr.length; i++) {
			arr[i] = (i + 1);
		}

//		//값 출력
//		for(int i=0;i<arr.length;i++) {
//			System.out.println(arr[i]);
//		}

		int tmp[] = new int[arr.length * 2];

		// 2. 기존 배열의 내용을 새로운 배열로 복사한다.
		for (int i = 0; i < arr.length; i++) {
			tmp[i] = arr[i];
		}

//		for (int i = 0; i < tmp.length; i++) {
//			System.out.println(tmp[i]);
//		}

		// 3. 주소번지 더큰 배열 주소로 변경한다.
		arr = tmp;
		System.out.println("arr.length:" + arr.length);
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}

	}

}
