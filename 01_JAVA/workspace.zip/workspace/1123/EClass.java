public class EClass
{
        public static void main(String []args)
        {
                System.out.println("Java 2����");
            
        }
    
}