package com.sist.eclass.set03;
import java.util.*;
public class HashSetEx04Main {

	public static void main(String[] args) {
		// HashSet 합집합,교집합,차집합
		//A:1,2,3,4,5
		//B:4,5,6,7,8
		
		//합집합(AUB):1,2,3,4,5,6,7,8
        //교집합(A∩B):4,5
		//차집합(A-B):1,2,3
		
		HashSet setA=new HashSet();
		HashSet setB=new HashSet();
		
		//setA
		for(int i=1;i<6;i++) {
			setA.add(i);
		}
		System.out.println("setA:"+setA);
		//setB
		for(int i=4;i<9;i++) {
			setB.add(i);
		}		
		System.out.println("setB:"+setB);
		
		//합집합(AUB):1,2,3,4,5,6,7,8
		HashSet setHap=new HashSet();
		Iterator itA = setA.iterator();
		Iterator itB = setB.iterator();
		
		while(itA.hasNext()) {
			setHap.add(itA.next());
		}
		while(itB.hasNext()) {
			setHap.add(itB.next());
		}		
		System.out.println("합집합(AUB):"+setHap);
		
		//교집합(A∩B):4,5
		HashSet setKyo=new HashSet();
		
		itB = setB.iterator();
		while(itB.hasNext()) {
			Object obj = itB.next();
			//setA에 있는 것만 추가
			if(setA.contains(obj)==true) {
				setKyo.add(obj);
			}
		}
		System.out.println("교집합(A∩B):"+setKyo);
		
		//차집합(A-B):1,2,3
		HashSet setChar = new HashSet();
		itA = setA.iterator();
		while(itA.hasNext()) {
			Object obj = itA.next();
			//setB에 없는것
			if(!setB.contains(obj)) {
				setChar.add(obj);
			}
		}
		System.out.println("차집합(A-B):"+setChar);
		
	}
//	setA:[1, 2, 3, 4, 5]
//	setB:[4, 5, 6, 7, 8]
//	합집합(AUB):[1, 2, 3, 4, 5, 6, 7, 8]
//	교집합(A∩B):[4, 5]
//	차집합(A-B):[1, 2, 3]
}











