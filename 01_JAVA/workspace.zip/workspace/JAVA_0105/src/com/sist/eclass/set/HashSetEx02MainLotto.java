package com.sist.eclass.set;
import java.util.*;
public class HashSetEx02MainLotto {

	public static void main(String[] args) {
		//중복제거
		HashSet set=new HashSet();

		//중복제거 1~45 6 난수 
		for(int i=0;set.size()<6;i++) {
			//0.0<=x<1.0
			int num = (int)(Math.random()*45)+1;
			System.out.println(num);
			set.add(num);
		}
		//정렬(x)
		System.out.println(set);
		
		List list = new LinkedList(set);
		Collections.sort(list);
		//정렬: ASC
		//[5, 8, 11, 17, 23, 39]
		System.out.println(list);
		
	}

}
