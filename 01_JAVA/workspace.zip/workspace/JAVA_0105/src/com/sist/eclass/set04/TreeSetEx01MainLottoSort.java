package com.sist.eclass.set04;
import java.util.*;
public class TreeSetEx01MainLottoSort {

	public static void main(String[] args) {
		// Lotto sort
		Set set = new TreeSet();
		
		for(int i=0;set.size()<6;i++) {
			int num = (int)(Math.random()*45)+1;
			System.out.println(num);
			set.add(num);
		}
//		/[11, 18, 22, 32, 35, 44]
		System.out.println(set);
//		16
//		9
//		29
//		37
//		41
//		41
//		14
//		[9, 14, 16, 29, 37, 41]		

	}

}
