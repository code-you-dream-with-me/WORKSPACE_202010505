package com.sist.eclass;
import java.util.Arrays;
public class ArraysEx01Main {

	public static void main(String[] args) {
//		Arrays: 배열을 다루는데 유용한 메서드								
//		
//		배열의 복사 : copyOf(),copyOfRange()							
//		배열 채우기:fill(),setAll()							
//		배열의 정렬과 검색: sort()							
//		문자열의 비교와 출력 : toString(),equals()							
//		배열을 List로 변환: asList(Object …)							

		int[] arr = {0,1,2,3,4};
		int[][] arr2D= {
						{11,12,13},
						{21,22,23}
					   };
		
		System.out.println("일차원 Arrays.toString:"+Arrays.toString(arr));//일차원 Arrays.toString:[0, 1, 2, 3, 4]
		System.out.println("다차원 Arrays.deepToString:"+Arrays.deepToString(arr2D));//다차원 Arrays.deepToString:[[11, 12, 13], [21, 22, 23]]
		
		//배열의 복사
		int[] arr2 = Arrays.copyOf(arr, arr.length);
		int[] arr3 = Arrays.copyOf(arr, 3);
		int[] arr4 = Arrays.copyOf(arr, 7);
		
		int[] arr5 = Arrays.copyOfRange(arr, 2, 4);
		int[] arr6 = Arrays.copyOfRange(arr, 0, 7);
		System.out.println("Arrays.copyOf:"+Arrays.toString(arr2));//Arrays.copyOf:[0, 1, 2, 3, 4]
		System.out.println("Arrays.copyOf:"+Arrays.toString(arr3));//Arrays.copyOf:[0, 1, 2, 3, 4]
		System.out.println("Arrays.copyOf:"+Arrays.toString(arr4));//Arrays.copyOf:[0, 1, 2, 3, 4, 0, 0]
		System.out.println("Arrays.copyOf:"+Arrays.toString(arr5));//Arrays.copyOf:[2, 3]
		System.out.println("Arrays.copyOf:"+Arrays.toString(arr6));
		
		//배열 채우기
		int[] arr7 = new int[5];
		Arrays.fill(arr7, 9);
		System.out.println("Arrays.fill:"+Arrays.toString(arr7));//Arrays.fill:[9, 9, 9, 9, 9]
		
		Arrays.setAll(arr7, i->(int)(Math.random()*6)+1);
		System.out.println("Arrays.setAll:"+Arrays.toString(arr7));
		
		//배열내 숫자 만큼 '*' 출력
		for(int i:arr7) {
			char[] graph=new char[i];
			Arrays.fill(graph, '*');
			System.out.println(new String(graph)+i);
		}
		
		//equals
		String[][] str2D = new String[][] { 
												{"aaa","bbb"},
												{"AAA","BBB"}  
										  };
										  
		String[][] str2D02 =new String[][]{ 
												{"aaa","bbb"},
												{"AAA","BBB"}  
										  };			
		//다차원은 비교 않됨								  
        System.out.println("Arrays.equals:"+Arrays.equals(str2D, str2D02));		
        System.out.println("Arrays.deepEquals:"+Arrays.deepEquals(str2D, str2D02));	
        
        char[] chArr = {'A','D','C','B','E'};
        System.out.println(Arrays.toString(chArr));
        Arrays.sort(chArr);
        System.out.println("Arrays.sort:ASC"+Arrays.toString(chArr));//[A, B, C, D, E]
        
	}

}
