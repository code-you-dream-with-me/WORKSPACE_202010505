package com.sist.eclass.set;
import java.util.HashSet;
import java.util.Set;

public class HashSetEx01Main {

	public static void main(String[] args) {
//		HashSet,TreeSet : 순서(x), 중복(x)						
//
//		HashSet													
//		set인터페이스를 구현한 대표적인 컬랙션											
//		순서를 우지하려면, LinkedHashSet 클래스 사용.											
//		객체를 저장 하기 전에 같은 객체가 있는지 확인, 같은 객체가 없으면 저장, 그렇치 않으면 저장하지 않는다.											
//		add() 저장할 객체의 equals, hashcode()가 오버라이딩 필요.											

		Object[] objArr= {"1","2","2","3","3","4","4","4"};

		Set  set =new HashSet();
		
		for(int i=0;i<objArr.length;i++) {
			System.out.println(i+"."+objArr[i]);
			set.add(objArr[i]);
		}
		
		//HashSet에 저장된 요소 출력.
		//[1, 2, 3, 4]
		System.out.println(set);
		
	}

}
