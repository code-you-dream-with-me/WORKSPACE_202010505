package com.sist.eclass.sort;
import java.util.Arrays;
public class ComparatorEx01Main {

	public static void main(String[] args) {
		String[] strArr = {"cat","Dog","lion","tiger"};
		System.out.println("soft before:"+Arrays.toString(strArr));//soft before:[cat, Dog, lion, tiger]
		Arrays.sort(strArr);
		System.out.println("soft :"+Arrays.toString(strArr));
		
		//대소문자 무시 sort
		Arrays.sort(strArr, String.CASE_INSENSITIVE_ORDER);
		System.out.println("대소문자 무시 sort :"+Arrays.toString(strArr));
		
		//Desc sort
		Arrays.sort(strArr,new Descending());
		System.out.println("Desc sort :"+Arrays.toString(strArr));
	}

}
