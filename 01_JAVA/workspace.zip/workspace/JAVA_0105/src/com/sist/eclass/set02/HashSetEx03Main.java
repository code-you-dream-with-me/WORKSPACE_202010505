package com.sist.eclass.set02;
import java.util.HashSet;
public class HashSetEx03Main {

	public static void main(String[] args) {
//		객체를 저장 하기 전에 같은 객체가 있는지 확인, 같은 객체가 없으면 저장, 그렇치 않으면 저장하지 않는다.							
//		add() 저장할 객체의 equals, hashcode()가 오버라이딩 필요.							

		HashSet  set=new HashSet();
		
		set.add("eclass");
		set.add("eclass");
		
		//equals, hashcode()가 오버라이딩 필요.	
		set.add(new Person("james", 10));
		set.add(new Person("james", 10));
		
		System.out.println(set);

	}

}
