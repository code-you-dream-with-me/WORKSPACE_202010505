package com.sist.eclass.sort;

import java.util.Comparator;

public class Descending implements Comparator {

	 public int compare(Object o1, Object o2) {
		 int flag = -1;
		 if(o1 instanceof  Comparable &&  o2 instanceof  Comparable) {
			 //두 객체가 같으면 0, 비교하는 값보다 작으면 음수,크면 양수
			 Comparable c01 = (Comparable) o1;
			 Comparable c02 = (Comparable) o2;
			 
			flag = c01.compareTo(c02)*-1;//DESC
			System.out.println("=flag:"+flag);
		 }
		 
		 return flag;
	 }
}
