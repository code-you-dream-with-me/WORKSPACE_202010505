package com.sist.eclass.operator;

public class Operator06BitShift {

	public static void main(String []args) {
//      <<,>>: 쉬프트 연산자
//		x<<n : x *2^n										
//		x>>n : x /2^n										
//      8 << 1 -> 16
//      8 >> 1 -> 4		
		
		int num = 8;
		//8 << 1=00000000000000000000000000010000
		System.out.printf("8 << 1=%s\n",toBinaryString(num<<1));
		System.out.printf("8 << 2=%s\n",toBinaryString(num<<2));
		//8 << 1=16
		System.out.printf("8 << 1=%d\n",(num<<1));
		
		//8 >> 1=00000000000000000000000000000100
		System.out.printf("8 >> 1=%s\n",toBinaryString(num>>1));
        //8 >> 1=4
		System.out.printf("8 >> 1=%d\n",(num>>1));
		//8 >> 2=2
		System.out.printf("8 >> 2=%d\n",(num>>2));
	}	

	/**
	 * Integer.toBinaryString()를 32bit 형식으로 변환
	 * @param x
	 * @return 32bit 문자열 
	 */
	public static String toBinaryString(int x) {//10101011
		String  retStr = "";
		String zero ="00000000000000000000000000000000";   //32 zero
		String tmp  = zero + Integer.toBinaryString(x);    //32+8
		retStr = tmp.substring(tmp.length()-zero.length());//40-32=8
		  
		return retStr;
	}

	
}
