package com.sist.eclass.operator;

public class Operator08Samhang {

	public static void main(String[] args) {
//		3항 연산자: 세 개의 피연산자를 필요로 하는 연산자.											
//							
//조건식?식1:식2;		
//		조건식 ==true -> 식1
//		조건식 ==false-> 식2					
//절대값 : 0으로부터 떨어져있는 거리입니다

		int x    = 0;
		int absX = 0;
		
		x = -5;
		
		absX = (x >= 0)?x:-x;
		
		System.out.printf("x=%d, absX=%d",x,absX);
		
	}

}
