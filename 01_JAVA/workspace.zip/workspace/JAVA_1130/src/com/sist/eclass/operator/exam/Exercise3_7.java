package com.sist.eclass.operator.exam;

public class Exercise3_7 {

	public static void main(String[] args) {
		int fahrenheit = 100;
		//공식: '5/9f * (fahrenheit - 32)
/*
		//올림
		float pi = 3.141592f;//3.141
		//1000/1000 
		
		float shotPi = (int)(pi*1000+0.5)/1000f;
		//(int)(3141.592f+0.5)
		//3142/1000f
		//3.142		
 */
		float celcius = (int)( (5/9f * (fahrenheit - 32) )*100+0.5)/100f;
		
		System.out.println("Fahrenheit:"+fahrenheit);
		System.out.println("celcius:"+celcius);//celcius:37.78
		
		
		   
	}

}
