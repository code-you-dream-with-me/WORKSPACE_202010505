package com.sist.eclass.operator;

public class Operator05Bit {

	public static void main(String[] args) {
		//~ : 비트 전환 연산자(0은 1로, 1은 0으로)							
//		X		~X	
//   ==================		
//		1		0	
//		0		1	

//      int x = 10;
//      ~x+1; //-10

		int p = 10;
		//p 32bit 이진 값:00000000000000000000000000001010
		//~p=           11111111111111111111111111110101
		//~p+1=         11111111111111111111111111110110
		System.out.println("p 32bit 이진 값:"+toBinaryString(p));
		System.out.printf("~p=%s\n",toBinaryString(~p));
		System.out.printf("~p+1=%s\n",toBinaryString(~p+1));
		
		//10 -> -10
		//     ~10+1
		System.out.printf("p=%d\n",p);
		System.out.printf("~p=%d\n",~p);
		System.out.printf("~p+1=%d\n",~p+1);

	}

	/**
	 * Integer.toBinaryString()를 32bit 형식으로 변환
	 * @param x
	 * @return 32bit 문자열
	 */
	public static String toBinaryString(int x) {//10101011
		String  retStr = "";
		String zero ="00000000000000000000000000000000";   //32 zero
		String tmp  = zero + Integer.toBinaryString(x);    //32+8
		retStr = tmp.substring(tmp.length()-zero.length());//40-32=8
		
		return retStr;
	}
	
	
	
}
