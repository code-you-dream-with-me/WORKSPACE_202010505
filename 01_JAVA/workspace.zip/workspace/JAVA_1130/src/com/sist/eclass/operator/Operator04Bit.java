package com.sist.eclass.operator;

public class Operator04Bit {

	public static void main(String[] args) {
//		|(OR) : 피연산자 중 한 쪽 값이 1이면, 1 그렇치 않으면 0													
//		&(AND) : 피연산자 양 쪽 값이 1이면, 1 그렇치 않으면 0													
//		^(XOR): 피연산자 양쪽 값이 서로 다르면, 1그렇치 않으면 0													

//		X		Y		X | Y		X & Y		X ^ Y
//  ====================================================		
//		1		1		1			1			0		
//		1		0		1			0			1		
//		0		1		1			0			1		
//		0		0		0			0			0		

		int x =0xAB;
		int y =0xF;
//		System.out.println(Integer.toBinaryString(x));//10101011
//		String zero ="00000000000000000000000000000000";
//		System.out.println("zero.length():"+zero.length());//32
//		String tmp  = zero + Integer.toBinaryString(x);//32+8
//		System.out.println("tmp.length():"+tmp.length());//32+8
//		
//		String retStr = tmp.substring(tmp.length()-zero.length());//40-32=8
//		System.out.println("retStr:"+retStr);//32
		System.out.println("0xAB:"+Integer.toBinaryString(x));//10101011
		System.out.println("0xAB:"+toBinaryString(x));//00000000000000000000000010101011
		
		System.out.println("0xF:"+Integer.toBinaryString(y));
		System.out.println("0xF:"+toBinaryString(y));	
		
		//x|y
		//0xAB|0xF=00000000000000000000000010101111
		System.out.printf("0xAB|0xF=%s\n", toBinaryString(x | y));

		//x&y
		//0xAB&0xF=00000000000000000000000000001011
		System.out.printf("0xAB&0xF=%s\n", toBinaryString(x & y));

		//x^y
		//0xAB^0xF=00000000000000000000000010100100
		System.out.printf("0xAB^0xF=%s\n",toBinaryString(x^y));
		
		//x^y^y
		//0xAB^0xF^0xF=00000000000000000000000010101011
		//             00000000000000000000000010101011
		System.out.printf("0xAB^0xF^0xF=%s\n",toBinaryString(x^y^y));
		
	}

	public static String toBinaryString(int x) {//10101011
		String  retStr = "";
		String zero ="00000000000000000000000000000000";   //32 zero
		String tmp  = zero + Integer.toBinaryString(x);    //32+8
		retStr = tmp.substring(tmp.length()-zero.length());//40-32=8
		
		return retStr;
	}
	

}
