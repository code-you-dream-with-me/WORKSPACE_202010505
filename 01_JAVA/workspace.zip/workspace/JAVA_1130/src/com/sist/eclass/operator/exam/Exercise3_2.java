package com.sist.eclass.operator.exam;

public class Exercise3_2 {

	public static void main(String[] args) {
		int numOfApples = 123;//사과의 총수
		int sizeOfBucket= 10; //바구니 크기
		//정수간에 나누기 연산은 버림! 나머지가 있으면 바구니가 1개더 필요.
		
		int numOfBucket = (numOfApples/sizeOfBucket +(numOfApples%sizeOfBucket>0 ? 1:0) );
		
		System.out.println("필요한 바구니의 수:"+numOfBucket);

	}

}
