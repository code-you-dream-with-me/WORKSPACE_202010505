package com.sist.eclass.operator;

import java.util.Scanner;

public class Operator02Scanner {

	public static void main(String[] args) {
		// 화면을 통한 데이터 입력
		Scanner  scanner=new Scanner(System.in);
		char ch = ' ';
		
		System.out.print("문자를 하나 입력 하세요>>");
		String input = scanner.nextLine();
		ch = input.charAt(0);
		System.out.println("ch="+ch);
		//숫자 여부 확인
		if('0' <=ch && ch <='9') {
			System.out.println("입력하신 문자는 숫자입니다.");
		}
		
		//영문자 확인
		if(('a' <=ch && ch <='z') || ('A' <=ch && ch <='Z')) {
			System.out.println("입력하신 문자는 영문자 입니다.");	
		}
		
		
	}

}
