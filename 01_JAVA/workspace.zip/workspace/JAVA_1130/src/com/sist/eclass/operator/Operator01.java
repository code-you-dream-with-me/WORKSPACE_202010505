package com.sist.eclass.operator;

public class Operator01 {

	public static void main(String[] args) {
//		||(OR) : 피연산자 중 어느 한 쪽만 true이면 true										
//		&&(AND):  피연산자 양쪽 모두 true이면 true										

//		X			Y			X || Y			X && Y		
//      ============================================		
//		true		true		true			true		
//		true		false		true			false		
//		false		true		true			false		
//		false		false		false			false		
		
		int  x = 0;
		//x>10 && x< 20
		x = 15;
		
		System.out.printf("x>10 && x< 20 = %b \n", x>10 && x< 20);
				
		//('i%2==0) || (i%3==0)
		int i = 6;
		System.out.printf("(i%%2==0) || (i%%3==0)=%b\n", (i%2==0) || (i%3==0));
				
		//문자 ch는 숫자('0' ~ '9')
		char ch =' ';
		ch = '9';
		
		System.out.printf("'0' <=ch && ch <='9'=%b\n", '0' <=ch && ch <='9');
		
		//입력된 문자는 영문자
        //('a' <=ch && ch <='z')  || ('A' <=ch && ch <='Z')
		ch = 'b';
		System.out.printf("('a' <=ch && ch <='z') || ('A' <=ch && ch <='Z')=%b\n ",
				                              ('a' <=ch && ch <='z') || ('A' <=ch && ch <='Z'));
	}

}
