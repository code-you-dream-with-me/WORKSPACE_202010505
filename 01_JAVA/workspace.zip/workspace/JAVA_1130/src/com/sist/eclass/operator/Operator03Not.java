package com.sist.eclass.operator;

public class Operator03Not {

	public static void main(String []args) {
		boolean b = true;
		
		System.out.printf("b=%b\n",b);
		
		System.out.printf("b=%b\n",!b);
		
		System.out.printf("b=%b\n",!!b);
	}
}
