package com.sist.eclass.operator.exam;

public class Exercise3_4 {

	public static void main(String[] args) {
		int num = 456;//400
		//정수간에 나누기 연산은 버림!
		System.out.println(num/100*100);

	}

}
