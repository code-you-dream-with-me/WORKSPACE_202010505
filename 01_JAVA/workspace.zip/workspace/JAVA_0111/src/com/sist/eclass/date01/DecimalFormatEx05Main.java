package com.sist.eclass.date01;
import java.text.*;

public class DecimalFormatEx05Main {

	public static void main(String[] args) {
		// 형식화 클래스 중에서 숫자를 형식화 하는데 사용.
		// 정수,실수,천단위 기호.
		
		double  number = 1234567.89;
		String[] pattern = {"0"
				           ,"#"
				           ,"0.0"		
				           ,"#.#"
				           ,"0000000000.0000"
				           ,"##########.####"
				           ,"#,###.##"
				           ,"#.#%"
		};
		
		for(int i=0;i<pattern.length;i++) {
			DecimalFormat  df=new DecimalFormat(pattern[i]);
			System.out.printf("%19s : %s\n",pattern[i],df.format(number));
		}

	}

}
