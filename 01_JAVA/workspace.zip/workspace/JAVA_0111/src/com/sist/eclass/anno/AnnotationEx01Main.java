package com.sist.eclass.anno;

import java.lang.annotation.Annotation;

@TestInfo(testedBy = "eClass",testDate = @DateTime(yymmdd = "210111",hhmmss = "093310"))
public class AnnotationEx01Main {

	public static void main(String[] args) {
        
		//AnnotationEx01Main의 Class객체 생성
		Class<AnnotationEx01Main>  cls = AnnotationEx01Main.class;
		
		TestInfo anno = cls.getAnnotation(TestInfo.class);
		System.out.println("anno.testedBy():"+anno.testedBy());
		System.out.println("anno.testDate().yymmdd():"+anno.testDate().yymmdd());
		System.out.println("anno.testDate().hhmmss():"+anno.testDate().hhmmss());

		
		Annotation[] annoArray = cls.getAnnotations();
		for(Annotation a  :annoArray) {
			System.out.println(a);
		}
		
	}

}
