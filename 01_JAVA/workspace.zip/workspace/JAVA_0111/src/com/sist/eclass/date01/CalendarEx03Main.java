package com.sist.eclass.date01;

import java.util.Calendar;

public class CalendarEx03Main {

	public static void main(String[] args) {
		// 2021 1
		
		if(args.length !=2) {
			System.out.println("입력: 2021 1");
			System.exit(0);
		}
		
		String yearString = args[0];
		String monthString= args[1];
		
		//System.out.println("yearString:"+yearString);
		//System.out.println("monthString:"+monthString);
		
		//년도,월을 숫자로 변환
		int year = Integer.parseInt(yearString);
		int month = Integer.parseInt(monthString);
		
		//시작요일(?), 시작일(1),그달의 마지막일(?)
		Calendar start = Calendar.getInstance();//시작일
		Calendar end = Calendar.getInstance();//종료일
		
		
		//시작일: year,month-1,1
		start.set(year, month-1, 1);
		
		//종료일:다음달 1일 -1
		end.set(year, month, 1);
		end.add(Calendar.DATE, -1);
		//
		int startDay = start.get(Calendar.DATE);
		int endDay   = end.get(Calendar.DATE);
		//시작요일
		int startWeek= start.get(Calendar.DAY_OF_WEEK);
		
		//System.out.println(startDay+" 시작일:"+toDateString(start));
		//System.out.println(endDay+" 종료일:"+toDateString(end));
		//System.out.println(" 시작요일:"+startWeek);
		
		System.out.println(" "+year+"년" +month+"월");
		System.out.println(" SU MO TU WE TH FR SA");
		
		//시작요일에 공백 추가
		for(int i=1;i<startWeek;i++) {
			System.out.print("   ");
		}
		
		//1~그 달의 마지막 일 출력
		//일%7==0 라인 스킵
		for(int i=1,n=startWeek;i<=endDay;i++,n++) {
			System.out.print(   (i<10)?"  "+i:" "+i  );
			if(n%7==0) {
				System.out.println();
			}
		}
		
		
		
	}
	public static String toDateString(Calendar cal) {
		return cal.get(Calendar.YEAR)+"-"+(cal.get(Calendar.MONTH)+1)+"-"+cal.get(Calendar.DATE);
	}
	
	
	
}
