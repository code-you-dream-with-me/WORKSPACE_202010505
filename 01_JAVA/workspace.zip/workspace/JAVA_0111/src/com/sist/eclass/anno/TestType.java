package com.sist.eclass.anno;

public enum TestType {
	FIRST,FINAL
}
