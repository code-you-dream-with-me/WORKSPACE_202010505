package com.sist.eclass.date01;
import java.text.SimpleDateFormat;
import java.util.*;
public class CalendarFormatterEx04Main {

	public static void main(String[] args) {
//		형식화 클래스													
//		
//		날짜를 형식에 맞게 출력!												
//		SimpleDateFormat												
//		y:년도												
//		M:월(1~12)												
//		d:일												
//		h:시												
//		m:분												
//		s:초												
//		S:천분의 1초												
//		a:오전/오후(AM,PM)												
		Date today=new Date();
		System.out.println("today:"+today);

		SimpleDateFormat  sdf=new SimpleDateFormat("yyyy/MM/dd a hh:mm:ss.SSS");
		//yyyy/MM/dd a hh:mm:ss.SSS	2021/01/11 오전 11:29:23.421
		System.out.println("yyyy/MM/dd a hh:mm:ss.SSS\t"+sdf.format(today));
		
		sdf=new SimpleDateFormat("yy년 MMM dd일 E요일");
		//yy년 MMM dd일 E요일 	21년 1월 11일 월요일
		System.out.println("yy년 MMM dd일 E요일 \t"+sdf.format(today));
		
		sdf=new SimpleDateFormat("yyyy-MM-dd a hh:mm:ss.SSS");
		//yyyy-MM-dd A hh:mm:ss.SSS 	2021-01-11 오전 11:32:24.086
		System.out.println("yyyy-MM-dd A hh:mm:ss.SSS \t"+sdf.format(today));
		
		//년
		sdf=new SimpleDateFormat("오늘은 올 해의 D번째 날입니다.");
		System.out.println("오늘은 올 해의 D번째 날입니다. \t"+sdf.format(today));
		
		//달
		sdf=new SimpleDateFormat("오늘은 이달의 d번째 날입니다.");
		System.out.println("오늘은 이달의 d번째 날입니다. \t"+sdf.format(today));
		
		
		//년기준 주
		sdf=new SimpleDateFormat("오늘은 올 해의 w번째 주입니다.");
		System.out.println("오늘은 올 해의 w번째 주입니다. \t"+sdf.format(today));		

		//달기준 주
		sdf=new SimpleDateFormat("오늘은 올 해의 W번째 주입니다.");
		System.out.println("오늘은 올 해의 W번째 주입니다. \t"+sdf.format(today));				
	}

}
