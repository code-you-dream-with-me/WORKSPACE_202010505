package com.sist.eclass.date01;
import java.util.*;
public class CalendarEx02Main {

	public static void main(String[] args) {
//		1. Calendar를 Date로 변환									
//		Calendar cal = Calendar.getInstance();								
//		Date  d =new Date( cal.getTimeMillis());//new Date(long)								
//	    2. Date를 Calendar로 변환									
//		Date  d =new Date();								
//		Calendar cal = Calendar.getInstance();								
//		cal.setTime(d);		
		
		Calendar cal = Calendar.getInstance();
		Date  d =new Date(cal.getTimeInMillis());
		System.out.println("date:"+d);
		
		Date d02=new Date();
		Calendar cal02 = Calendar.getInstance();			
		cal02.setTime(d02);
		System.out.println("cal02:"+cal02);

		System.out.println("=====================================");
		
		Calendar cal03 = Calendar.getInstance();
		cal03.set(2020, 10, 30);
		System.out.println(toDateString(cal03));
		
		//1일후
		cal03.add(Calendar.DATE,1);
		System.out.println("1일 이후:"+toDateString(cal03));
		
		//7일 전
		cal03.add(Calendar.DATE,-7);
		System.out.println("7일 전:"+toDateString(cal03));
		
		//6달전
		cal03.add(Calendar.MONTH,-6);
		System.out.println("6달전:"+toDateString(cal03));
	}
	
	public static String toDateString(Calendar cal) {
		return cal.get(Calendar.YEAR)+"-"+(cal.get(Calendar.MONTH)+1)+"-"+cal.get(Calendar.DATE);
	}
	
//	2020-11-30
//	1일 이후:2020-12-1
//	7일 전:2020-11-24
//	6달전:2020-5-24	
	
	
	
	
	

}
