package com.sist.eclass.date01;
import java.util.*;
public class CalendarEx01Main {

	public static void main(String[] args) {
//		날짜와 시간(Calendar와 Date)													
//		날짜와 시간을 다룰 목적으로 JDK 1.0부터 제공되어온 클래스												
//	    JDK1.8부터 java.time패키지로 기존 단전들을 개선한 클래스 제공.													
//		Calendar생성								
//		Calendar cal = Calendar.getInstance();							

//		Date와 Calendar간의 변환										
//		1. Calendar를 Date로 변환									
//			Calendar cal = Calendar.getInstance();								
//			Date  d =new Date( cal.getTimeMillis());//new Date(long)								
//		2. Date를 Calendar로 변환									
//			Date  d =new Date();								
//			Calendar cal = Calendar.getInstance();								
//			cal.setTime(d);			
		//현재 날짜와 시간
		Calendar today = Calendar.getInstance();
		
		System.out.println("Calendar.YEAR:"+today.get(Calendar.YEAR));
		//월(0~11): 1월 0
		System.out.println("Calendar.MONTH:"+today.get(Calendar.MONTH));
		System.out.println("Calendar.MONTH:"+ (today.get(Calendar.MONTH)+1));
		
		System.out.println("Calendar.DATE:"+ (today.get(Calendar.DATE)));
		
		//yyyy-MM-DD
		System.out.println(today.get(Calendar.YEAR)+"-"+(today.get(Calendar.MONTH)+1)+"-"+today.get(Calendar.DATE));
		
		System.out.println("Calendar.DAY_OF_MONTH:"+ (today.get(Calendar.DAY_OF_MONTH)));
		System.out.println("Calendar.DAY_OF_YEAR:"+ (today.get(Calendar.DAY_OF_YEAR)));
		
		//요일:(1~7)SUNDAY:1
		System.out.println("Calendar.DAY_OF_WEEK:"+ (today.get(Calendar.DAY_OF_WEEK)));
		
		//오전(0)/오후(1)
		System.out.println("Calendar.AM_PM:"+ (today.get(Calendar.AM_PM)));
		
		//시간(0~11)
		System.out.println("Calendar.HOUR:"+ (today.get(Calendar.HOUR)));
		//시간(0~23)
		System.out.println("Calendar.HOUR_OF_DAY:"+ (today.get(Calendar.HOUR_OF_DAY)));
		
		
		//분(0~59)
		System.out.println("Calendar.MINUTE:"+ (today.get(Calendar.MINUTE)));
		//초(0~59)
		System.out.println("Calendar.SECOND:"+ (today.get(Calendar.SECOND)));		
		//천분에 1초
		System.out.println("Calendar.MILLISECOND:"+ (today.get(Calendar.MILLISECOND)));
		
		//hh:mi:ss Sss
		
		System.out.println("Calendar.HOUR:"+ (today.get(Calendar.HOUR))+":"+(today.get(Calendar.MINUTE))+":"+(today.get(Calendar.SECOND))
				+" "+ (today.get(Calendar.MILLISECOND)));

	}

}
