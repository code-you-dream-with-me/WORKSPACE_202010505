package com.sist.eclass.anno;

import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
//실행시 까지 유지
@Retention(RUNTIME)
public @interface DateTime {
//	-요소의 타입은 기본형, String,enum,애너테이션,Class만 허용												
//	-()안에 매개변수를 선언할 수 없다.												
//	-예외를 선언 할수 없다.												
//	-요소를 타입 매개변수로 정의할 수 없다.												

	String yymmdd();
	String hhmmss();
	
}
