/**
 * 
 */
package com.sist.eclass;

/**
 * @author james
 *
 */
public class Float03Bin {

	/**
	 * eClass 메소드
	 * @param args
	 */
	public static void main(String[] args) {
		float f = 9.1234567f;
		
		//float -> 16진수로 변환
		int intHexa =Float.floatToIntBits(f);
		
		System.out.printf("%f\n",f);//9.123457
		System.out.printf("%X\n",intHexa);

		//int -> 2진수로 변환
		System.out.println("int -> 2진수로 변환:"+Integer.toBinaryString(intHexa));
		Integer.toBinaryString(intHexa);
	}

}
