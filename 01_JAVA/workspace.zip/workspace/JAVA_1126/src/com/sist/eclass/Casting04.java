/**
 * 
 */
package com.sist.eclass;

/**
 * @author james
 *
 */
public class Casting04 {

	/**
	 * 변수 또는 상수의 타입을 다른 타입으로 변환 서로 다른 타입간에 연산을 수행하는 경우 서로간에 타입을 일치 시키고 연산 수행, ex)
	 * 기본자료형들은 boolean을 빼고는 서로 형변환 가능.
	 */
	public static void main(String[] args) {
		double d = 85.4d;
		int score = (int)d;
		
		System.out.println("score="+score);
		System.out.println("d="+d);

	}

}
