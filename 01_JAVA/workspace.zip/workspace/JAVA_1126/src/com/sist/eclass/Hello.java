package com.sist.eclass;

public class Hello {

	public static void main(String []args) {
		System.out.println("Hello,world");
		//정수형 오버 플로우 : 쓰레기값 분석할 필요 없음.
		//int integerMax = 3000_000_000;
	}
}
