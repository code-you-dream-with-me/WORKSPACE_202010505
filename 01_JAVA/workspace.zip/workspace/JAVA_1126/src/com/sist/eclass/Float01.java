package com.sist.eclass;
/*
 * 실수의 정밀도
 * Type	크기(byte)	정밀도
 * ======================
   float	4	     7자리
   double	8	    15자리
   ----------------------
 */
public class Float01 {

	public static void main(String[] args) {
		float  f = 9.12345678901234567890f;
		float  f2= 1.2345678901234567890f;
		double d = 9.12345678901234567890d;
		System.out.printf("       12345678901234567890\n");
		System.out.printf("f   :  %f\n",f);//소숫점 이하 여섯자리 까지 출력
		System.out.printf("f   :%24.20f\n",f);
		System.out.printf("f2  :%24.20f\n",f2);
		System.out.printf("d   :%24.20f\n",d);
		/*
		       12345678901234567890
		f   :  9.123457
		f   :  9.12345695495605500000
		f2  :  1.23456788063049320000
		d   :  9.12345678901234600000
		 */
	}

}
 