package com.sist.eclass.jsoup;

import java.io.IOException;

import org.apache.log4j.Logger;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class HtmlParseJsoupMain {

	final static Logger LOG = Logger.getLogger(HtmlParseJsoupMain.class);
	//https://jsoup.org/
	//api
	public static void main(String[] args) {
		//LOG.debug("Jsoup html parse.");
        //http://www.cgv.co.kr/movies/
		
		String url = "http://www.cgv.co.kr/movies/";
		
		try {
			Document doc = Jsoup.connect(url).get();
			//LOG.debug(doc.toString());//html source 
			//<div class="box-contents"> <a href="/movies/detail-view/?midx=84049"> <strong class="title">조제</strong> </a> 
			//LOG.debug(doc.select("div.box-contents strong.title").toString());
			Elements titles = doc.select("div.box-contents strong.title");//제목
			
			//예매율
//			<div class="score">
//            <strong class="percent">예매율<span>2.1%</span></strong>
			Elements ratios = doc.select("div.score strong span");
			
			//이미지
			Elements images = doc.select("span.thumb-image img");
			
//<span class="thumb-image">
//            <img src="https://img.cgv.co.kr/Movie/Thumbnail/Poster/000084/84049/84049_320.jpg" alt="조제 포스터" onerror="errorImage(this)"/>
//            <span class="ico-grade grade-15">15세 이상</span>
//        </span>			
//			
			//순위
			Elements ranking = doc.select("div.box-image strong");
			
			
			
			//LOG.debug(titles.size());
			for(int i=0;i<7;i++) {
				//LOG.debug(titles.get(i));//<strong class="title">조제</strong>
				Element imageElement = images.get(i);
				String imageUrl      = imageElement.attr("src");
				
				//순위 : No.1
				String rank = ranking.get(i).text();
				int idx = rank.indexOf(".");
				String numRank = rank.substring(idx+1);
				LOG.debug(numRank+","+titles.get(i).text()+","+ratios.get(i).text()+","+imageUrl);//<strong class="title">조제</strong>
				
			}
			
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
