package com.sist.eclass.math06;

public class MathEx01Main {

	public static void main(String[] args) {
		// Math : 올림, 버림, 반올림
		
		//1.round():반올림, 소수 첫째 자리에서 반올림 
		//특정자리에 반올림 
		//1.1.원래 값에 100 곱하기
		//1.2.round 사용
		//1.3.위의 결과를 다시 100.0으로 나눈다.
		
		double val = 90.7552;
		
		System.out.println("Math.round():"+Math.round(val));//90.7552 -> 91
		
		//소수 세째자리에서 반올림
		val=val*100;
		System.out.println("val:"+val);//9075.52
		//round: return long
		System.out.println("Math.round():"+Math.round(val));//9076
		val = Math.round(val);
		val=val/100.0;
		System.out.println("val:"+val);

		
		//올림:ceil
		System.out.printf("ceil(%3.1f)=%3.1f\n",1.1,Math.ceil(1.1));
		
		//버림:floor
		System.out.printf("floor(%3.1f)=%3.1f\n",1.1,Math.floor(1.7));
		
		//반올림:rint : return값이 double
		System.out.println("Math.rint():"+Math.rint(1.5));//
		
		
		
	}

}
