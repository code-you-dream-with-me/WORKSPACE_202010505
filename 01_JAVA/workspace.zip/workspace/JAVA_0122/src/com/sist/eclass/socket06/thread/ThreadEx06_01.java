package com.sist.eclass.socket06.thread;

public class ThreadEx06_01 extends Thread {

	@Override
	public void run() {
		for(int i=0;i<500;i++) {
			System.out.print("-");
			
			for(int x=0;x<1_000_000;x++) {
//				for(int y=0;y<1_000_000;y++) {
//					
//				}
			}
		}
	}

	
	
}
