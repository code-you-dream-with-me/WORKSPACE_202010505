package com.sist.eclass.socket06.thread;

public class PriorityEx01Main {

	public static void main(String[] args) {
		
		ThreadEx06_01 th01=new ThreadEx06_01();
		ThreadEx06_02 th02=new ThreadEx06_02();
	
		
		th01.setPriority(Thread.NORM_PRIORITY);
		th02.setPriority(Thread.MIN_PRIORITY);
		
		System.out.println("th01:"+th01.getPriority());
		System.out.println("th02:"+th02.getPriority());
		
		th01.start();
		th02.start();
	}

}
