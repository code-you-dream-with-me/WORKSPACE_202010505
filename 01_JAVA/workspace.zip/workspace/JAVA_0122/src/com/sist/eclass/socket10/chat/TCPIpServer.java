package com.sist.eclass.socket10.chat;
import java.net.*;

import org.apache.log4j.Logger;

import java.io.*;
public class TCPIpServer {
	final static Logger LOG = Logger.getLogger(TCPIpServer.class);
	public static void main(String[] args) {
		ServerSocket  serverSocket = null;
		Socket        socket = null;
		int port = 8888;
		
		try {
			serverSocket = new ServerSocket(port);
			LOG.debug("서버 start....");
			
			socket = serverSocket.accept();
			LOG.debug("client:"+socket.getInetAddress()+":"+socket.getPort());
			
			Sender sender=new Sender(socket);
			Receiver receiver=new Receiver(socket);
			
			sender.start();
			receiver.start();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
		}
	}

}
