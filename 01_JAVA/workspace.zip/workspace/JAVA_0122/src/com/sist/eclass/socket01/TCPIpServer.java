package com.sist.eclass.socket01;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TCPIpServer {

	public static void main(String[] args) {
//		-클라이언트와 서버간 1:1소켓 통신																		
//		-서버가 먼저 실행되어 클라이언트의 연결 요청을 기다리고 있어야 한다.		  																
//																				
//		1. 서버는 서버소켓(ServerSocket)을 사용해서 서버의 특정포트에서 클라이언트의																		
//		요청을 처리할 준비를 한다.																		
//		2. 클라이언트는 서버의 IP주소 PORT정보를 소켓(Socket)을 생성해서 서버에 연결																		
//		3. ServerSocket으로 클라이언트 연결요청을 받는다. 새로운 소켓을 생성해서 클라이언트와																		
//		 통신한다.																		
//		4. 새로 생성된 서버의 소켓(Socket)은 클라이언트와 1:1통신을 한다.																		

		ServerSocket  serverSocket = null;
		
		//port: 0~65535
		//0~1024 : 기존 통신프로그램 들이 사용.(http,https,ftp,telnet,smtp)
		//1024~65535 포트 사용 가능.

		try {
			serverSocket = new ServerSocket(7778);
		} catch (IOException e) {
			System.out.println("=======================");
			System.out.println("=IOException="+e.getMessage());
			System.out.println("=======================");
			e.printStackTrace();
		}
		
		
		
		while(true) {
			System.out.println(getDate()+" 연결 요청을 기다립니다.");
			
			try {
				//서버 소켓은 클라이언트의 요청이 올때 까지 실행을 멈추고 대기
				//클라이언트의 요청이 들어 오면 새로운 소켓을 하나 만들고 통신.
				Socket socket = serverSocket.accept();
				
				System.out.println(socket.getInetAddress()+"로부터 연결요청이 들어 왔습니다.");
				//
				OutputStream out =socket.getOutputStream();
				DataOutputStream dos=new DataOutputStream(out);
				
				//client에 메시지 전송
				dos.writeUTF("[eClass] Test 메시지 from 서버");
				System.out.println(getDate()+" 메시지 전송");
				
				
				//스트림과 Socket close
				dos.close();
				socket.close();
				
			} catch (IOException e) {
				System.out.println("=======================");
				System.out.println("=IOException="+e.getMessage());
				System.out.println("=======================");
				e.printStackTrace();
			}
			
		}//--while
		
		

	}//--main
	
	public static String getDate() {
		SimpleDateFormat sdf=new SimpleDateFormat("[yyyy/MM/dd HH:mm:ss]");
		return sdf.format(new Date());
	}
	
	
	

}//--class
