package com.sist.eclass.socket09.thread;

public class SyncEx01Main {

	public static void main(String[] args) {
		RunnableEx08 rThread=new RunnableEx08();
		
		new Thread(rThread).start();
		new Thread(rThread).start();
	}

}
