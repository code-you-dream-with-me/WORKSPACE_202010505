package com.sist.eclass.socket05.thread;

import javax.swing.JOptionPane;

public class ThreadEx05Main {

	public static void main(String[] args) {
		ThreadEx05 th01=new ThreadEx05();
		th01.start();
		
		String input = JOptionPane.showInputDialog("값을 입력 하세요.");
		System.out.println("입력 값은 "+input+" 입니다.");	

	}

}
//10
//9
//8
//7
//6
//5
//입력 값은 9999 입니다.
//4
//3
//2
//1