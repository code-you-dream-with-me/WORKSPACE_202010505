package com.sist.eclass.socket10.chat;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;

import org.apache.log4j.Logger;

public class Receiver extends Thread {
	final Logger LOG = Logger.getLogger(Receiver.class);
	//------------------------------------------------
	//Data수신
	//------------------------------------------------
	Socket socket;
	DataInputStream in;
	
	
	public Receiver(Socket socket) {
		this.socket = socket;
		try {
			in = new DataInputStream(this.socket.getInputStream());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
	}

	@Override
	public void run() {
		while(null != in ) {
			try {
				LOG.debug(in.readUTF());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			} finally {
				System.out.println("\n종료");
			}
		}//--while

	}//--run
	
	
}
