package com.sist.eclass.socket10.chat;

import org.apache.log4j.Logger;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class Sender extends Thread {

	final Logger LOG = Logger.getLogger(Sender.class);
	//------------------------------------------------
	//Data전송
	//------------------------------------------------
	
	Socket socket;
	DataOutputStream  out;
	String name;
	
	
	public Sender(Socket socket) {
		this.socket = socket;
		
		try {
			out =new DataOutputStream(socket.getOutputStream());
			name="["+socket.getInetAddress()+":"+socket.getPort()+"]";
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
	}
	
	
	@Override
	public void run() {
		Scanner  scanner=new Scanner(System.in);
		
		while(null !=out) {
			
			try {
				out.writeUTF(name+">>"+scanner.nextLine());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				// e.printStackTrace();
			} finally {
				System.out.println("\n종료");
			}
		}//--while
		
		
	}//--run

}











