package com.sist.eclass.socket04.thread;

public class ThreadEx01 extends Thread {

	@Override
	public void run() {
		
		for(int i=0;i<500;i++) {
			System.out.printf("%s","-");
		}
		System.out.println();
	}

}
