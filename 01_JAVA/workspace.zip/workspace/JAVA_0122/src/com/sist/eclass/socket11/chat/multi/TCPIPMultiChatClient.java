package com.sist.eclass.socket11.chat.multi;

import org.apache.log4j.Logger;
import java.net.*;
import java.util.Scanner;
import java.io.*;


public class TCPIPMultiChatClient {

	final static Logger LOG = Logger.getLogger(TCPIPMultiChatClient.class);
	
	
	//static Sender extends   
	static class CleintSender extends Thread{
		Socket socket;
		DataOutputStream  out;
		String name;
		
		CleintSender(Socket socket,String name){
			this.socket=socket;
			this.name=name;
			
			try {
				out = new DataOutputStream(this.socket.getOutputStream());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}//--CleintSender constructor

		@Override
		public void run() {
			Scanner scanner =new Scanner(System.in);
			
			if(null !=out) {
				try {
					out.writeUTF(name);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			
			while(null !=out) {
				String msg = scanner.nextLine();
				try {
					out.writeUTF("["+name+"]"+msg);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			
		}//--run
		
		
		
		
	}//--CleintSender
	
	
	
	//static Receiver extends Thread 
	static class ClientReceiver extends Thread{
		Socket socket ;
		DataInputStream  in;
		
		ClientReceiver(Socket socket){
			this.socket = socket;
			try {
				in=new DataInputStream(this.socket.getInputStream());
			}catch(IOException e) {
				
			}
		}//--ClientReceiver constructor

		@Override
		public void run() {
			while(null !=in) {
				try {
					LOG.debug(in.readUTF());
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}//--run
		
	}//--ClientReceiver
	
	public static void main(String[] args) {
		if(args.length!=1) {
			LOG.debug("대화명 입력!");
			System.exit(0);
		}
		
		String serverIp = "211.238.142.124";
		int port = 8080;
		String name = args[0];
		
		try {
			Socket socket=new Socket(serverIp, port);
			
			Thread threadSender=new Thread(new CleintSender(socket,name));
			Thread threadReceiver=new Thread(new ClientReceiver(socket));
			threadSender.start();
			threadReceiver.start();
			
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
		
		

	}//--main

}//--class














