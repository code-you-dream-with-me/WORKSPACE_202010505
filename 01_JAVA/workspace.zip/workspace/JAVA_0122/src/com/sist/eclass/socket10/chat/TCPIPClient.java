package com.sist.eclass.socket10.chat;

import org.apache.log4j.Logger;

import java.io.IOException;
import java.net.*;
public class TCPIPClient {

	final static Logger LOG = Logger.getLogger(TCPIPClient.class);
	public static void main(String[] args) {
		
		String serverIp = "211.238.142.124";
		int port = 8888;
		
		try {
			Socket socket=new Socket(serverIp, port);
			
			LOG.debug("서버에 연결");
			Sender sender=new Sender(socket);
			Receiver receiver=new Receiver(socket);			
			
			sender.start();
			receiver.start();			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

}
