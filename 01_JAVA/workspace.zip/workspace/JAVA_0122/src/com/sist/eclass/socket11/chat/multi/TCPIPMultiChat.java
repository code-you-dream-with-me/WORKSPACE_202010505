package com.sist.eclass.socket11.chat.multi;
import java.net.*;
import java.io.*;
import java.util.*;

import org.apache.log4j.Logger;
public class TCPIPMultiChat {

	//------------------------------------------------
	//-Client정보를 Collection에 저장
	//------------------------------------------------
	
	final static Logger LOG = Logger.getLogger(TCPIPMultiChat.class);
	HashMap   clients;//client socket정보
	
	
	public TCPIPMultiChat() {
		clients = new HashMap();
		
		//thread safe한 HashMap
		Collections.synchronizedMap(clients);
	}

	//ServerSocket생성
	//Socket생성
	public void start() {
		ServerSocket serverSocket = null;
		Socket       socket       = null;
		int          port         = 8080;
		
		LOG.debug("Server start!!");
		try {
			serverSocket = new ServerSocket(port);
			while(true) {
				socket = serverSocket.accept();
				ServerReceiver serverReceiver=new ServerReceiver(socket);
				serverReceiver.start();
			}//--while
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
	}//--start
	
	
	
	
	//------------------------------------------------
	//-Send,Reciever inner class Thread
	//------------------------------------------------
	
	class ServerReceiver extends Thread
	{
		Socket socket;
		DataInputStream  in;
		DataOutputStream out;
		
		public ServerReceiver(Socket socket) {
			
			this.socket = socket;
			try {
				in = new DataInputStream(this.socket.getInputStream());
				out= new DataOutputStream(this.socket.getOutputStream());
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}

		@Override
		public void run() {
			String name = "";//사용자 이름: HashMap key
			
			try {
				name = in.readUTF();//client 로그인 사용자 이름
				sendToAll("#"+name+"님이 입장 하셨습니다.");
				clients.put(name, out);//이름,DataOutputStream
				
				//--접속 사용자
				LOG.debug("현재 접속자 수:"+clients.size()+" 입니다.");
				
				//------------------------------------------------
				// chatting msg
				//------------------------------------------------				
				while(null !=in) {
					sendToAll(in.readUTF());
				}
				
				
				
			} catch (IOException e) {
				//e.printStackTrace();
			} finally {
				sendToAll("#"+name+"님이 퇴장 하셨습니다.");
				clients.remove(name);//HashMap사용자 정보 삭제
				LOG.debug("["+socket.getInetAddress()+":"+socket.getPort()+"]");
				LOG.debug("현재 접속자 수:"+clients.size()+" 입니다.");
			}
			
			
			
		}//--ServerReceiver
		
		/**
		 * 접속된 모든 사용자에게 메시지 보내기!
		 * 
		 * @param msg
		 */
		public void sendToAll(String msg) {
			//접속된 모든 사용자 정보
			Iterator itor = clients.keySet().iterator();
			while(itor.hasNext()) {
				String key = (String) itor.next();//사용자 이름
				DataOutputStream  out = (DataOutputStream) clients.get(key);
				
				try {
					out.writeUTF(msg);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}//--while
			
		}//--sendToAll
		
	}
	

	public static void main(String[] args) {
			new TCPIPMultiChat().start();

	}

}
