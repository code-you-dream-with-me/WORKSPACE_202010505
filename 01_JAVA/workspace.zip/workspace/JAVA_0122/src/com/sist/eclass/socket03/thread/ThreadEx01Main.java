package com.sist.eclass.socket03.thread;

public class ThreadEx01Main {

	public static void main(String[] args) {
		//Thread상속
		ThreadEx01  th01=new ThreadEx01();
		th01.start();
		
		
		//Runnable interface상속
//		Runnable  r=new ThreadEx02();
//		Thread   th02=new Thread(r);
		
		Thread   th02=new Thread(new ThreadEx02());
		th02.start();

	}

}
