package com.sist.eclass.socket01;
import java.net.*;
import java.io.*;
import java.util.*;
import java.text.*;
public class TCPIpClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        //127.0.0.1 localhost
		//서버 IP,port: 127.0.0.1 port
		
		String serverIP = "211.238.142.124";
		int    port = 7778;
		
		Socket socket = null;
		
		try {
			socket =new Socket(serverIP, port);
			
			//input stream 생성
			InputStream inputstream = socket.getInputStream();
			DataInputStream dis=new DataInputStream(inputstream);
			
			//------------------------------------
			//-서버로 부터 데이터 수신
			//------------------------------------
			System.out.println(">>>서버로 부터 받은 메시지:"+dis.readUTF());
			
			
			//------------------------------------
			//-스트림과 Socket close
			//------------------------------------			
			dis.close();
			socket.close();
			System.out.println("연결을 종료 합니다.");
		} catch (UnknownHostException e) {
			System.out.println("=======================");
			System.out.println("=UnknownHostException="+e.getMessage());
			System.out.println("=======================");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("=======================");
			System.out.println("=IOException="+e.getMessage());
			System.out.println("=======================");
			e.printStackTrace();
		}
		
	}

}
