package com.sist.eclass.socket03.thread;

public class ThreadEx02 implements Runnable {

	@Override
	public void run() {
		for(int i=0;i<5;i++) {
			System.out.println(this.getClass().getName()+"_"+Thread.currentThread().getName());
		}
	}
//	쓰레드											
//	프로세서 내에서 실제 작업을 수행											
//	모든 프로세서는 하나 이상의 쓰레드를 가지고 있다.											
//	프로세서:쓰레드=공장:일꾼											
//												
//	멀티프로세서 vs. 멀티쓰레드											
//	하나의 새로운 프로세서를 생성하는 것 보다											
//	하나의 새로운 쓰레드를 생성하는 것이 더 적은 비용이 든다.											
//												
//	멀티쓰레드의 장단점											
//	장점											
//	CPU의 사용률을 향상시킨다.											
//	사용자의 응답성이 향상된다.											
//	작업이 분리되어 코드가 간결해 진다.											

	
	
	
}
