package com.sist.eclass.socket08.thread;

public class Account {

	//잔고
	private int balance = 1000;

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}
	
	//출금
	public void withDraw(int money) {
		//출금 금액이 잔고 보다 작거나 같은 경우만 출금
		if(balance>=money) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			balance=balance-money;
		}
	}
}
