public class Variable07SpecialChar
{
    public static void main(String []args)
    {
        //-------------------------------
        //Special  Char
        // tab      \t
        // new line \n
        // ��������(\) \\
        // ū����ǥ    \"
        //-------------------------------
        System.out.println("Good\tmorning");
        System.out.println("Good\ntmorning");
        //C:\20201123_eClass\01_JAVA\workspace
        System.out.println("C:\\20201123_eClass\\01_JAVA\\workspace");//C:\20201123_eClass\01_JAVA\workspace
        System.out.println("\"Hello\"");
    }
    
}