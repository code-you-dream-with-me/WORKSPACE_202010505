public class Param09Args{
    //
    public static void main(String []args){
        
        System.out.println("args.length="+args.length);
        if(args.length !=1){
            
            System.out.println("=======================");
            System.out.println("=���ڸ� �Է� �ϼ���.=");
            System.out.println("=======================");
            
            System.exit(0);
        }
        
        String param = args[0];
        System.out.println("param="+param);
        
        int currentYear = 2020;
        int num = Integer.parseInt(param);
        
        int age = currentYear - num;
        System.out.printf("�ڹ��� ���̴� %d�� �Դϴ�.\n",age);

    }//main
    
}//class