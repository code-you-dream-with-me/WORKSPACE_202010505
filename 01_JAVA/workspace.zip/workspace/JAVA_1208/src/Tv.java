public class Tv {
    String color;
    private int channel;
    private boolean power;

    public void power(){
    	
    }

    public void channelUp(){
    	
    }

    public void channelDown(){
    	
    }

}
