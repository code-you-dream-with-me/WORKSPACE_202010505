package com.sist.eclass.quiz;

import java.util.Scanner;

public class Exam02 {

	// 2. 년도월을 입력 받아 그달의 일수를 구하시오.
	public static void main(String[] args) {
		System.out.println("현재 년월을 입력하세요.(2020-12)>");
		Scanner scanner = new Scanner(System.in);
		
		String yearMonth = scanner.nextLine();
		if (yearMonth.indexOf("-") < 0) {
			System.out.println("입력형식을 확인하세요.(2020-12)>");
			return;
		}

		String[] tmpArr = yearMonth.split("-");
		String yearStr = tmpArr[0];
		String monthStr = tmpArr[1];
		
		int year  = Integer.parseInt(yearStr);// 2016,2020윤년
		int month = Integer.parseInt(monthStr);
		int day = 0;// 일수

		switch (month) {
		case 2:
			/**
			 * 1. 4의 배수인 해는 윤년으로 하고, 2. 100의 배수인 해는 윤년에서 뺀다, 그러나 400의 배수인 해는 도로 윤년으로 넣는다.
			 */
			if (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0)) {
				day = 29;
			} else {
				day = 28;
			}
			break;
		case 4:		case 6:		case 9:		case 11:
			day = 30;
			break;
		default:
			day = 31;
			break;
		}

		System.out.printf("%d월은 %d일 입니다.", month, day);
	}
}
