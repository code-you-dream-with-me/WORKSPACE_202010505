package com.sist.eclass.quiz;

import java.util.Scanner;

public class Exam03 {

	public static void main(String[] args) {
		// 3. 1 ~ 1000사이 숫자중 사용자가 입력한 숫자의 배수 개수와 배수들의 총합을 구하시오.
		int num = 0;
		int count = 0;
		long sum = 0;

		System.out.printf("1 ~ 1000사이의 숫자를 입력하세요.>");
		Scanner scanner = new Scanner(System.in);
		num = scanner.nextInt();

		for (int i = 1; i <= 1000; i++) {
			if (i % num == 0) {
				count++;
				sum += i;
			}
		}

		System.out.printf("1 ~ 1000숫자중 %d의 배수의 개수: %d 배수의 합:%d\n", num, count, sum);
	}
	// 1 ~ 1000사이의 숫자를 입력하세요.>10
	// 1 ~ 1000숫자중 10의 배수의 개수: 100 배수의 합:50500
}
