package com.sist.eclass.oop01;

public class Tv02Main {

	public static void main(String[] args) {
		Tv  tv01=new Tv();
		Tv  tv02=new Tv();
		
		System.out.println("tv01의 채널 값은 "+tv01.channel+"입니다.");
		System.out.println("tv02의 채널 값은 "+tv02.channel+"입니다.");
		
		tv01.channel = 15;
		System.out.println("tv01의 채널 값은 "+tv01.channel+"입니다.");
		System.out.println("tv02의 채널 값은 "+tv02.channel+"입니다.");
				
	}

}
