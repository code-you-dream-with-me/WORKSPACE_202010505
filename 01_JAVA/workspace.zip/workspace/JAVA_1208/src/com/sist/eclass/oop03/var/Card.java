package com.sist.eclass.oop03.var;

public class Card {

	/*인스턴스 변수 */
	String kind;//카드종류
	int number;//숫자
	
	/*클래스 변수(공유변수) */
	static int width =100;
	static int height =250;
	
}
