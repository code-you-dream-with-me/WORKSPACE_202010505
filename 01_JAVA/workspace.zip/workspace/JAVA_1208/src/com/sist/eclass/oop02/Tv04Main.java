package com.sist.eclass.oop02;

import com.sist.eclass.oop01.Tv;

public class Tv04Main {

	public static void main(String[] args) {
		Tv[]  tvArray=new Tv[3];//길이가 3일 TV 배열
		
		for(int i=0;i<tvArray.length;i++) {
			tvArray[i]=new Tv();
			tvArray[i].channel = 16;
			
		}
		
		
		for(int i=0;i<tvArray.length;i++) {
			tvArray[i].channelUp();
			System.out.printf("tvArray[%d].channel=%d\n",i,tvArray[i].channel);
		}

	}

}
