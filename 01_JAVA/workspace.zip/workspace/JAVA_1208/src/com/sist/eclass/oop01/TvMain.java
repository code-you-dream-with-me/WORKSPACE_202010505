package com.sist.eclass.oop01;

public class TvMain {

	public static void main(String[] args) {
		// 프로그램 진입
		
		//클래스 인스턴스화
		Tv tv;
		tv =new Tv(); //Tv tv=new Tv();

		tv.channel = 15;//Tv클래스에 channel멤버변수에 15할당
		System.out.println("현재 채널은 "+tv.channel+"입니다.");
		
		//메서드 호출
		tv.channelUp();
		System.out.println("현재 채널은 "+tv.channel+"입니다.");
	}

}
