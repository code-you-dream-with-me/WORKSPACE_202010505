package com.sist.eclass.oop01;

public class Tv2 {

	//속성: Tv상태 저장
	public String color; //색상
	public boolean power;//전원
	public int channel;  //채널
	
	public Tv2() {
		
	}
	
	//기능: 메서드(속성의 상태값을 변경)
	void power() {
		power = !power;
	}
	
	public void channelUp() {
		channel++;
	}
	
	public void channelDown() {
		channel--;
	}	
	
}
