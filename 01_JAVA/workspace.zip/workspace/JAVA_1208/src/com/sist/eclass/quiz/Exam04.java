package com.sist.eclass.quiz;

public class Exam04 {

	public static void main(String[] args) {
		// 4. 아래 배열에서 숫자의 빈도수를 구하시오.
		int[] answer = { 1, 4, 7, 3, 1, 4, 4, 2, 1, 3, 2, 9 };
		int[] counter = new int[10];

		for (int i = 0; i < answer.length; i++) {
			/* 알맞은 코드를 넣어 완성하시오. */
			counter[answer[i]]++;
		}

		for (int i = 0; i < counter.length; i++) {
			System.out.print(i);
			for (int j = 0; j < counter[i]; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}

}
