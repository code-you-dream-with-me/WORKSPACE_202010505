package com.sist.eclass.oop03.var;

public class CardMain {

	public static void main(String[] args) {
		/*클래스 변수(공유변수) */		
		System.out.println("카드넓이:"+Card.width);
		System.out.println("카드높이:"+Card.height);
		
		Card card01=new Card();
		card01.kind ="Heart";
		card01.number = 1;
		
		Card card02=new Card();
		card02.kind ="Spade";
		card02.number = 7;
		
		System.out.println("card01은"+card01.kind+","+card01.number);
		System.out.println("card01은"+card01.width+","+card01.height);
		
		System.out.println("card02은"+card02.kind+","+card02.number);
		System.out.println("card02은"+card02.width+","+card02.height);	
		
		//
		//클래스 변수(공유변수): 값 변경
		card01.width = 102;
		card01.height = 220;
		System.out.println("======================================");
		System.out.println("card01은"+card01.kind+","+card01.number);
		System.out.println("card01은"+card01.width+","+card01.height);
		
		System.out.println("card02은"+card02.kind+","+card02.number);
		System.out.println("card02은"+card02.width+","+card02.height);		

	}

}
