package com.sist.eclass.quiz;

public class Exam01 {

	public static void main(String[] args) {
		// 1. 파스칼 표기법(Pascal Notation), 카멜표기법(Camel Notation)을 예를 들어 설명 하세요.
//		카멜표기법(Camel Notation)
//		 -.맨처음 문자는 소문자로 표기함.
//		 -.띄어쓰기 대신 대문자로 단어를 구분하는 표기 방식
//		 -.java의 메소드,변수 표기방식, void myName(){ }
//
//		파스칼 표기법(Pascal Notation)
//		 -.첫 단어를 대문자로 시작하는 표기법, 다음 단어의 시작은 대문자로 시작.
//		 -.BackgroundColor
//		 -.java의 클래스 표기방식,class PostName{ }

		
	}

}
