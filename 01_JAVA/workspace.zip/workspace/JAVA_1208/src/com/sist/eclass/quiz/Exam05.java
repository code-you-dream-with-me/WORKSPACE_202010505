package com.sist.eclass.quiz;

public class Exam05 {
	// 5. 1~ 45까지의 숫자들 중 중복되지 않게 6개를 출력하고 오름차순(작은것 부터 큰것 순)으로 정열(버블소트 사용) 하세요.
	public static void main(String[] args) {
		int[] score   = new int[45];
		int[] results = new int[6];
		
		for (int i = 0; i < score.length; i++) {
			score[i] = i + 1;
		}

		System.out.println("값 할당:");
		printArr(score);
		// shuffle:38,9,12,17,4,40,
		for (int i = 0; i < 6; i++) {
			int n = (int) (Math.random() * 45);
			int tmp = score[i];
			score[i] = score[n];
			score[n] = tmp;
		}

		System.arraycopy(score, 0, results, 0, 6);
		// 오름차순
		for (int i = 0; i < results.length - 1; i++) {
			for (int j = 0; j < results.length - 1 - i; j++) {
				if (results[j] > results[j + 1]) {// asc
					int tmp = results[j];
					results[j] = results[j + 1];
					results[j + 1] = tmp;
				}
			}
		}

		printArr(results);

	}


	static void printArr(int[] arr) {
		// 출력
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + ",");
		}
		System.out.println();
	}

}
