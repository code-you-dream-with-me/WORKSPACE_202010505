package com.sist.eclass.oop01;

public class Tv03Main {

	public static void main(String[] args) {
		Tv tv01=new Tv();
		Tv tv02=new Tv();
		
		System.out.println("tv01 채널"+tv01.channel+"입니다.");
		System.out.println("tv02 채널"+tv02.channel+"입니다.");
		
		tv01.channel = 15;
		System.out.println("tv01 채널"+tv01.channel+"입니다.");
		System.out.println("tv02 채널"+tv02.channel+"입니다.");		
		
		tv02= tv01;
		System.out.println("tv01 채널"+tv01.channel+"입니다.");
		System.out.println("tv02 채널"+tv02.channel+"입니다.");		
	}

}
