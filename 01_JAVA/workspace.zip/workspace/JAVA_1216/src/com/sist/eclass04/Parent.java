package com.sist.eclass04;

public class Parent {
	int x=200;
	
	void method() {
		System.out.println("Parent method()");
	}
}
