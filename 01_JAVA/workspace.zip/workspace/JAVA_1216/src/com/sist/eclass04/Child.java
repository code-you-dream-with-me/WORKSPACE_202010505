package com.sist.eclass04;

public class Child extends Parent {
	int x=100;
	
	void method() {
		System.out.println("Child method()");
	}
}
