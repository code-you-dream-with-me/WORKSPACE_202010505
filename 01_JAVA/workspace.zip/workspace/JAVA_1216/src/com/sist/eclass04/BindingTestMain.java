package com.sist.eclass04;

public class BindingTestMain {

	public static void main(String[] args) {
		Parent p=new Child();
		Child c =new Child();
		//p.x:200
		System.out.println("p.x:"+p.x);
		
		//c.x:100
		System.out.println("c.x:"+c.x);
	}

}
