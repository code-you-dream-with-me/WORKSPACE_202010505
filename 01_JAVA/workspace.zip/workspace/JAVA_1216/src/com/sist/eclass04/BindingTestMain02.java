package com.sist.eclass04;

public class BindingTestMain02 {

	public static void main(String[] args) {
		//메서드는 참조변수의 타입에 관계없이 항상 실제 인스턴스의 타입인
		//child클래스에 정의된 메서드가 호출된다.
		Parent p=new Child();
		Child c =new Child();
		//p.x:200
		System.out.println("p.x:"+p.x);
		p.method();
		
		//c.x:100
		System.out.println("c.x:"+c.x);
		c.method();
	}

}
