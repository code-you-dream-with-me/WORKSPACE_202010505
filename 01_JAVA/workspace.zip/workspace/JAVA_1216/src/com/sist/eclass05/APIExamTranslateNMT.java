package com.sist.eclass05;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class APIExamTranslateNMT {

	public static void main(String[] args) {

	// ----------------------------------------------
	// Naver Blog Search
	// https://openapi.naver.com/v1/search/blog.json
	// ----------------------------------------------
		String jsonString = "";// JSON String
		//Items items = null;
		String clientId = "AN4Dh0pZE5RczHDudeMf";// Naver Application ID
		String clientSecret = "ffcupmt8VR";
		String apiUrl = "https://openapi.naver.com/v1/search/blog.json?display=20&query=";

		BufferedReader br = null;
		try {
			String text = URLEncoder.encode("홍대 날씨", "UTF-8");// UTF-8
			apiUrl += text;
			// apiUrl:https://openapi.naver.com/v1/search/blog.json?query=%ED%99%8D%EB%8C%80+%EB%A7%9B%EC%A7%91
			// System.out.println("apiUrl:"+apiUrl);

			URL url = new URL(apiUrl);// https://openapi.naver.com/v1/search/blog.json?query=%ED%99%8D%EB%8C%80%20%EB%A7%9B%EC%A7%91
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setRequestMethod("GET");
			con.setRequestProperty("X-Naver-Client-Id", clientId);// ID
			con.setRequestProperty("X-Naver-Client-Secret", clientSecret);// 비번
			// HTTP/1.0 200 OK
			// HTTP/1.0 401 Unauthorized
			int responseCode = con.getResponseCode();
			System.out.println("responseCode:" + responseCode);

			if (responseCode == 200) {
				br = new BufferedReader(new InputStreamReader(con.getInputStream()));
				String input = "";
				StringBuilder sb = new StringBuilder();
				while ((input = br.readLine()) != null) {
					sb.append(input);
					// System.out.println(input);
				}
				jsonString = sb.toString().trim();
				System.out.println(sb.toString().trim());
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (null != br) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

//		items = new Gson().fromJson(jsonString, Items.class);
//		System.out.println("getLastBuildDate:" + items.getLastBuildDate());
//		System.out.println("total:" + items.getTotal());
//		System.out.println("start:" + items.getStart());
//		System.out.println("display:" + items.getDisplay());
//		System.out.println(items.getItems());
//		for (Item item : items.getItems()) {
//			System.out.println(item.getTitle() + "," + item.getBloggername() + "," + item.getBloggerlink());
//		}
	}

}
