package com.sist.eclass07;

public class Audio extends Product {

	public Audio() {
		super(3000);
	}

	@Override
	public String toString() {
		return "Audio";
	}

	
}
