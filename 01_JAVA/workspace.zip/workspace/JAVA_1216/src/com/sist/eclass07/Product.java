package com.sist.eclass07;

public class Product {
	/**제품가격 */
	int price;
	/**보너스 포인트 */
	int bonusPoint;
	
	public Product(int price) {
		super();
		this.price = price;
		this.bonusPoint = (int)(price/10.0);//보너스 포인트는 제품가격의 10%
	}
	
   
	
	
}
