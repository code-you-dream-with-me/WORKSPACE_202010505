package com.sist.eclass07;

public class PolyAgrMain {
	public static void main(String[] args) {
		Buyer buyer=new Buyer();
		
		buyer.buy(new Computer());
		buyer.buy(new Audio());
		buyer.buy(new Tv());
		
		//System.out.println("잔액:"+buyer.money+" 입니다.");
		buyer.summary();
		System.out.println("보너스 포인트:"+buyer.bonusPoint+" 입니다.");
	}

}
