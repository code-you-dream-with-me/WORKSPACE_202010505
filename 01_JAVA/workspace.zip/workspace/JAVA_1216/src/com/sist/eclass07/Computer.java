package com.sist.eclass07;

public class Computer extends Product {

	public Computer() {
		super(2000);
	}

	public String toString() {
		return "Computer";
	}

	
}
