package com.sist.eclass07;
import java.util.Vector;
public class Buyer {
	int money      = 10_000;
	int bonusPoint = 0;
	//Product[] item=new Product[10];//구입 목록
	Vector item=new Vector();
	
    int i=0;//배열 인덱스
    
	public Buyer() {
		
	}
	
	void summary() {
		int sum = 0;//구매 총액
		String itemList = "";//구매목록
		
		for(int i=0;i<item.size() ;i++) {
			//if(null==item[i]) { break; }
			Product p = (Product) item.get(i);
			
			sum+=p.price;//구매 가격 누적
			itemList += p.toString()+",";
		}
		System.out.println("========================");
		System.out.println("구매총액:"+sum+"입니다.");
		System.out.println("구매목록:"+itemList+"입니다.");
		System.out.println("========================");
	}
	
	void buy(Product p) {
		if(money<p.price) {
			System.out.println("잔액이 부족 합니다.");
			return;
		}
		    
		money -=p.price;//가진 돈에서 제품 가격만큼 빼기
		bonusPoint += p.bonusPoint;//보너스 포인트
		//p == p.toString()
		//추가 vector
		item.add(p);
		
		System.out.println(p.toString() +"을/를 구매 했습니다.");
		
	}


}
