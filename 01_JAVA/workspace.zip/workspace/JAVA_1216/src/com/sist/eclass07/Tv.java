package com.sist.eclass07;

public class Tv extends Product {

	public Tv() {
		super(100);
	}


	public String toString() {
		return "Tv";
	}
	


}
