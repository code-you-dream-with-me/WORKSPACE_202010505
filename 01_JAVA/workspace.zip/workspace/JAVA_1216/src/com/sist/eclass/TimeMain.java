package com.sist.eclass;

public class TimeMain {

	public static void main(String[] args) {
		Time t=new Time();
		t.setHour(9);
		
		System.out.println(t.getHour());
		
		Time t01=new Time(9,42,20);
		System.out.println("시:"+t01.getHour());
		System.out.println("분:"+t01.getMinute());
		System.out.println("초:"+t01.getSecond());
		
		
	}

}
