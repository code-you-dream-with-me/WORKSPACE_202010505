package com.sist.eclass;

public class Time {
//	- 외부로 부터 데이터를 보호 하기 위해								
//	- 외부에는 불필요한 부분을 감추기 위해서								
	private int hour;
	private int minute;
	private int second;
	
	public Time() {
		
	}
	
	public Time(int hour, int minute, int second) {
		super();
		this.hour = hour;
		this.minute = minute;
		this.second = second;
	}
	public int getHour() {
		return hour;
	}
	public void setHour(int hour) {
		if(hour<0 || hour>23) {
			System.out.println("1~23입니다.");
			return;
		}
		this.hour = hour;
	}
	public int getMinute() {
		return minute;
	}
	public void setMinute(int minute) {
		this.minute = minute;
	}
	public int getSecond() {
		return second;
	}
	public void setSecond(int second) {
		this.second = second;
	}
	
	//setXX: 값을 외부에서 할당
	//getXX: 값을 전달.

	
	
	
}
