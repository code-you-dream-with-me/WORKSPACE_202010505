package com.sist.eclass08;

public abstract  class Player {


	/**
	 * play
	 * @param pos
	 */
	abstract void play(int pos);
	
	abstract void stop();

}
