package com.sist.eclass08;

public class AudioPlayer extends Player {
	void play(int pos) {}
	
	void stop() {}
	
}
