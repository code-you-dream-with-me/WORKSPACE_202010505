package com.sist.eclass08;

public class AbstractMain {

	public static void main(String[] args) {
		//Player p01=new Player();
		
		//추상 클래스 객체 생성 방법
		
		Player p01=new AudioPlayer();
		

	}

}
