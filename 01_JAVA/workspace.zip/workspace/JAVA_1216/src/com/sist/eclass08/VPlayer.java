package com.sist.eclass08;

public class VPlayer extends Player {

	@Override
	void play(int pos) {
		// TODO Auto-generated method stub

	}

	@Override
	void stop() {
		// TODO Auto-generated method stub
		
	}



}
