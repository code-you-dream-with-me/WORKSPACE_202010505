package com.sist.eclass02;

public class SingleTon {

	
	private static SingleTon s=new SingleTon();
	//생성자가 private인 클래스는 다른 클래스의 조상이 될수 없다.
	//class에 final
	//public final class Math {
    //  private Math() {}

  
	private SingleTon() {
		
	}
	
	public static SingleTon getInstance() {
		return s;
	}

	
	
}
