package com.sist.eclass02;

public class SingleTonMain {

	public static void main(String[] args) {
		//The constructor SingleTon() is not visible
		//SingleTon s=new SingleTon();
	
		SingleTon s = SingleTon.getInstance();
		System.out.println("SingleTon:"+s);

		SingleTon s01 = SingleTon.getInstance();
		System.out.println("SingleTon:"+s01);
//		SingleTon:com.sist.eclass02.SingleTon@15db9742
//		SingleTon:com.sist.eclass02.SingleTon@15db9742
			
		
	}

}
