package com.sist.eclass03;
public class CastingMain {
	public static void main(String[] args) {
		Car  car = null;
		FireEngine  fe=new FireEngine();
		FireEngine  fe02=null;
		
		fe.water();
		
		car = fe;//car = (Car)fe 형변환이 생략
//		자손->조상(Up-casting): 형변환 생략가능								
//		조상->자손(Down-casting): 형변화 생략불가								
		fe02 =  (FireEngine) car;
		fe02.water();
		
		FireEngine  f=new FireEngine();
		Ambulance a=new Ambulance();

//		f = (FireEngine)a; //상속관계가 아닌 클래스간의 형변환 불가
//		a = (Ambulance)f;//상속관계가 아닌 클래스간의 형변환 불가

	}

}
