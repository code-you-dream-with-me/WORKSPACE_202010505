package com.sist.eclass03;

public class Car {

	String color;
	int door;
	
	void drive() {
		System.out.println("부릉,부릉~~");
	}
	
	void stop() {
		System.out.println("stop.");
	}	
}
