package com.sist.eclass03;

public class InstanceOfMain {

	public static void main(String[] args) {
//		instanceof연산자																		
//		
//		- 참조변수가 참조하는 인스턴스의 실제 타입을 체크 하는데 사용.																	
//		- 이항연산자 왼쪽에는 참조변수를 오른쪽에는 타입클래스명,  연산결과는 true/false		
//        true이면 검사한 타입으로 형변환 가능.		
		FireEngine  fe=new FireEngine();
		
		if(fe instanceof FireEngine) {
			System.out.println("This is a fireengine instance:"+(fe instanceof FireEngine));
		}
		
		if(fe instanceof Car) {
			System.out.println("This is a car instance:"+(fe instanceof Car));
		}
		
		if(fe instanceof Object) {
			System.out.println("This is a Object instance:"+(fe instanceof Object));
		}
		
		System.out.println(fe.getClass().getName());
		
		
		
	}

}
