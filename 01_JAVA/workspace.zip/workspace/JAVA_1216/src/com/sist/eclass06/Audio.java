package com.sist.eclass06;

public class Audio extends Product {

	public Audio() {
		super(3000);
	}

	@Override
	public String toString() {
		return "Audio";
	}

	
}
