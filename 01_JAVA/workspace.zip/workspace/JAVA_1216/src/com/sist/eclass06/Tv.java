package com.sist.eclass06;

public class Tv extends Product {

	public Tv() {
		super(100);
	}


	public String toString() {
		return "Tv";
	}
	


}
