package com.sist.eclass;
import org.apache.log4j.Logger;
public class Log4JMain {

	static final Logger LOG = Logger.getLogger(Log4JMain.class);
	
	public static void main(String[] args) {
		LOG.debug("=======================");
		LOG.debug("Log4J");
		LOG.debug("=======================");

	}

}
